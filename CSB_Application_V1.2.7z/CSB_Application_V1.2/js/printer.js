function printPreview(fragment){

	var printwindow=window.open(fragment.title);
	
	var css = fragment.css;
	
	var doc ='<meta http-equiv="X-UA-Compatible" content="IE=EDGE,chrome=1">';
	var html = $("<html>");
	var head = $("<head>");
	$(head).append(doc); 
	$(head).append($("<title>").text(fragment.title));
	$(css).each(function() {
			var cssLink = $(this).clone();
			cssLink.attr('media','print,screen')
			head.append(cssLink);
	});
	
	$(html).append(head);
	
	
	var body = $("<body>",{dir:fragment.direction});
	
	
	var contentWrapper =$("<div>",{class:'content-wrapper'});
	var container =$("<div>",{class:'container'});
	var header =$("<div>",{class:'row-fluid centerText'});
	var printButton = $('<input>',{ onclick:"this.style.visibility='hidden';window.print();window.close();",type:'button',style:'background: url(/wps/images/printer_icon.png) no-repeat;width: 50px;height: 50px;border: none;'});


	printButton.text('Print');
	$(header).append(printButton);
	$(header).append($("<h3>").text(fragment.title));
	var rowfluid = $('<div>',{class: 'row-fluid'});
	var span12 = $('<div>',{class: 'span12'});
	
	
	if(fragment.content instanceof Array){
		$(fragment.content).each(function() {
			var content = $(this).clone();
			fragment.formatter(content);
			$(span12).append(content);
		});
	}else{
		var content = fragment.content.clone();
		fragment.formatter(content);
		$(span12).append(content);
	}
	$(rowfluid).append(span12);
	
	$(container).append(header);
	$(container).append(rowfluid);
	
	$(contentWrapper).append(container);
	$(body).append(contentWrapper);

	$(html).append(body);
	printwindow.document.write("<!DOCTYPE>");
	printwindow.document.write($(html).html());
	printwindow.document.close(); 
}








