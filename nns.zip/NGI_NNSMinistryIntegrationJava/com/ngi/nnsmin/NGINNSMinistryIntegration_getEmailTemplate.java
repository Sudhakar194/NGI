package com.ngi.nnsmin;

import java.io.File;
import java.io.StringWriter;
import java.util.Properties;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;


public class NGINNSMinistryIntegration_getEmailTemplate extends
		MbJavaComputeNode {

		private final static String s = File.separator;

		public void evaluate(MbMessageAssembly assembly) throws MbException {
			MbOutputTerminal out = getOutputTerminal("out");
			// MbOutputTerminal alt = getOutputTerminal("alternate");
			// MbMessage message = assembly.getMessage();

			MbElement envRoot = assembly.getGlobalEnvironment().getRootElement();
			String sTemplate = envRoot.getFirstElementByPath("/Variables/Template").getValueAsString();
			String sProjectName = envRoot.getFirstElementByPath("/Variables/ProjectName").getValueAsString();
			String sNotificationType = envRoot.getFirstElementByPath("/Variables/NotificationType").getValueAsString();

			String[] valueArray = new String[10];
	        MbElement rMailCnt = envRoot.getFirstElementByPath("/Variables/MailContent");
	        if (rMailCnt != null){
	              MbElement rChild = rMailCnt.getFirstChild();
	              
	              int i=0;
	              while (rChild != null) {
	                    valueArray[i] = rChild.getValueAsString();
	                    rChild = rChild.getNextSibling();
	                    i = i +1 ;
	            }
	        }
			
			String sMailBody;
			try {
				sMailBody = NGINNSMinistryIntegration_getEmailTemplate.getMailBodyFromArray(sNotificationType,sProjectName, sTemplate, valueArray);
			} catch (Exception e) {
				sMailBody = "Exception: " + e.getMessage();
			}
			//System.out.println("Value of MailBody::: "+envRoot.getFirstElementByPath("/MailBody"));
			if(envRoot.getFirstElementByPath("/MailBody") == null){
				envRoot.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "MailBody",sMailBody);
			}
			else{
				envRoot.getFirstElementByPath("/MailBody").setValue(sMailBody);
			}
			out.propagate(assembly);
		}

		public static String getMailBodyFromArray(String notType,String projectName, String templateName, String[] valueArray)
				throws Exception {
			StringWriter swOut = new StringWriter();
			try {
				/**
				 * Prepare context data
				 */
				Template template = init(notType, projectName, templateName);
				VelocityContext context = new VelocityContext();
				for (int i = 0; i < valueArray.length; i++) {
					context.put("param" + (i+1), valueArray[i]);
				}
				template.merge(context, swOut);
				//System.out.println(swOut.toString());
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				throw new Exception("Exception in getMailBodyFromArray(...) method::: " + e.getMessage(), e);
			}
			return swOut.toString();
		}

		private static Template init(String notType, String projectName,String templateName) throws Exception {
			Template template = new Template();
			try {
				Properties props = new Properties();
				props.put("resource.loader", "file");
				//props.put("file.resource.loader.path", s + "var" + s + "wmbadmin" + s + "NGINotifications" + s + "template");
				//IIB path
				props.put("file.resource.loader.path", s + "data" + s + "NGINotifications" + s + "template");

				VelocityEngine ve = new VelocityEngine();
				ve.init(props);
				if (notType.equalsIgnoreCase("sms"))
					template = ve.getTemplate(s + projectName + s + "sms" + s + templateName, "UTF-8");
				else if (notType.equalsIgnoreCase("email"))
					template = ve.getTemplate(s + projectName + s + "email" + s + templateName, "UTF-8");
				else
					throw new Exception("Invalid Notification type::: SMS or EMAIL only supported");
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				throw new Exception("Exception in init() method::: "+e.getMessage(), e);
			}
			return template;
		}

		public static void main(String[] args) {
			try {
				getMailBodyFromArray("sms", "projectname", "sample.vm",new String[] { "1", "2" });
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		}

}
