package bh.gov.cio.integration.crs.update.person.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.crs.model.person.EMS006Respose;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CreateCPRService", targetNamespace = "http://service.person.update.crs.integration.cio.gov.bh/")
public interface CreateCPRServiceInterface
{
	@WebResult(name = "CreateCPRResult")
	@WebMethod(operationName = "createCPR")
	EMS006Respose createCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security",
			// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
					header = true) SecurityTagObject security,
			@WebParam(name = "expatApplicationID") @XmlElement(required = true) String expatApplicationID,
			@WebParam(name = "cprNumber") @XmlElement(required = true) String cprNumber,
			@WebParam(name = "englishFirstName") @XmlElement(required = true) String englishFirstName,
			@WebParam(name = "englishMiddleName1") @XmlElement(required = true) String englishMiddleName1,
			@WebParam(name = "englishMiddleName2") @XmlElement(required = true) String englishMiddleName2,
			@WebParam(name = "englishMiddleName3") @XmlElement(required = true) String englishMiddleName3,
			@WebParam(name = "englishMiddleName4") @XmlElement(required = true) String englishMiddleName4,
			@WebParam(name = "englishFamilyName") @XmlElement(required = true) String englishFamilyName,
			@WebParam(name = "messageIdentifier") @XmlElement(required = true) String messageIdentifier,
			@WebParam(name = "phoneContact") @XmlElement(required = true) String phoneContact,
			@WebParam(name = "highestLevelAchievedCode") @XmlElement(required = true) String highestLevelAchievedCode,
			@WebParam(name = "labourParticipationTypeCode") @XmlElement(required = true) String labourParticipationTypeCode,
			@WebParam(name = "maritalStatusCode") @XmlElement(required = true) String maritalStatusCode,
			@WebParam(name = "religionCode") @XmlElement(required = true) String religionCode,
			@WebParam(name = "ioStatusCode") @XmlElement(required = true) String ioStatusCode,
			@WebParam(name = "gender") @XmlElement(required = true) String gender,
			@WebParam(name = "nationalityCode") @XmlElement(required = true) String nationalityCode,
			@WebParam(name = "occupationCode") @XmlElement(required = true) String occupationCode,
			@WebParam(name = "occupationTypeCode") @XmlElement(required = true) String occupationTypeCode,
			@WebParam(name = "employerNumber") @XmlElement(required = true) String employerNumber,
			//added 
			@WebParam(name = "employerCardCountryCode") @XmlElement(required = true) String employerCardCountryCode,
			@WebParam(name = "employerType") @XmlElement(required = true) String employerType,
			@WebParam(name = "employmentStatusCode") @XmlElement(required = true) String employmentStatusCode,
			@WebParam(name = "sponsorNumber") @XmlElement(required = true) String sponsorNumber,
			//added
			@WebParam(name = "sponsorCardCounryCode") @XmlElement(required = true) String sponsorCardCounryCode,
			@WebParam(name = "sponsorType") @XmlElement(required = true) String sponsorType,
			@WebParam(name = "countryOfBirth") @XmlElement(required = true) String countryOfBirth,
			@WebParam(name = "dateOfBirth") @XmlElement(required = true) String dateOfBirth,
			@WebParam(name = "block") @XmlElement(required = true) String block,
			@WebParam(name = "road") @XmlElement(required = true) String road,
			@WebParam(name = "building") @XmlElement(required = true) String building,
			@WebParam(name = "buildingAlpha") @XmlElement(required = true) String buildingAlpha,
			@WebParam(name = "flat") @XmlElement(required = true) String flat,
			@WebParam(name = "mailBox") @XmlElement(required = true) String mailBox,

			// Removed Per Aneesa Request @WebParam(name = "isHeadOfHousehold") @XmlElement(required = true) String isHeadOfHousehold,

			@WebParam(name = "headOfHouseholdCpr") @XmlElement(required = true) String headOfHouseholdCpr,
			@WebParam(name = "headOfHouseholdCardCountryCode") @XmlElement(required = true) String headOfHouseholdCardCountryCode,
			@WebParam(name = "houseHoldRelationCode") @XmlElement(required = true) String houseHoldRelationCode, @WebParam(
					name = "occupancyStatusCode") @XmlElement(required = true) String occupancyStatusCode,
			@WebParam(name = "residential") @XmlElement(required = true) String residential, @WebParam(name = "passportNumber") @XmlElement(
					required = true) String passportNumber,
			@WebParam(name = "passportTypeCode") @XmlElement(required = true) String passportTypeCode, @WebParam(name = "issueDate") @XmlElement(
					required = true) String issueDate, @WebParam(name = "expiryDate") @XmlElement(required = true) String expiryDate, @WebParam(
					name = "passportSequenceNumber") @XmlElement(required = true) String passportSequenceNumber,
			@WebParam(name = "arabicFirstName") @XmlElement(required = true) String arabicFirstName,
			@WebParam(name = "arabicMiddleName1") @XmlElement(required = true) String arabicMiddleName1,
			@WebParam(name = "arabicMiddleName2") @XmlElement(required = true) String arabicMiddleName2,
			@WebParam(name = "arabicMiddleName3") @XmlElement(required = true) String arabicMiddleName3,
			@WebParam(name = "arabicMiddleName4") @XmlElement(required = true) String arabicMiddleName4,
			@WebParam(name = "arabicFamilyName") @XmlElement(required = true) String arabicFamilyName,
			@WebParam(name = "placeOfBirthArabic") @XmlElement(required = true) String placeOfBirthArabic,
			@WebParam(name = "placeOfBirthEnglish") @XmlElement(required = true) String placeOfBirthEnglish,
			@WebParam(name = "specialisationCode") @XmlElement(required = true) String specialisationCode,
			@WebParam(name = "educationLevelCode") @XmlElement(required = true) String educationLevelCode,
			@WebParam(name = "unitNumber") @XmlElement(required = true) String unitNumber, @WebParam(name = "previousPassportNumber") @XmlElement(
					required = true) String previousPassportNumber,
			@WebParam(name = "passportImage") @XmlElement(required = true) String passportImage, @WebParam(name = "fatherCprNumber") @XmlElement(
					required = true) String fatherCprNumber, @WebParam(name = "motherCprNumber") @XmlElement(required = true) String motherCprNumber,
			@WebParam(name = "spouseCPRNumber") @XmlElement(required = true) String spouseCPRNumber, @WebParam(name = "photo") @XmlElement(
					required = true) String photo, @WebParam(name = "photoDate") @XmlElement(required = true) String photoDate, @WebParam(
					name = "signatureDate") @XmlElement(required = true) String signatureDate, @WebParam(name = "signature") @XmlElement(
					required = true) String signature,
			@WebParam(name = "IsDomestic") @XmlElement(required = true) Boolean isDomestic
			) throws ApplicationExceptionInfo;
	
	
	
	
//	@WebResult(name = "CreateIDResult")
//	@WebMethod(operationName = "createID")
//	EMS006Respose createID(
//			@WebParam(mode = WebParam.Mode.IN, name = "Security",
//			// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
//			header = true) SecurityTagObject security,
//			@WebParam(name = "expatApplicationID") @XmlElement(required = true) String expatApplicationID,
//			@WebParam(name = "cprNumber") @XmlElement(required = true) String cprNumber,
//			@WebParam(name = "englishFirstName") @XmlElement(required = true) String englishFirstName,
//			@WebParam(name = "englishMiddleName1") @XmlElement(required = true) String englishMiddleName1,
//			@WebParam(name = "englishMiddleName2") @XmlElement(required = true) String englishMiddleName2,
//			@WebParam(name = "englishMiddleName3") @XmlElement(required = true) String englishMiddleName3,
//			@WebParam(name = "englishMiddleName4") @XmlElement(required = true) String englishMiddleName4,
//			@WebParam(name = "englishFamilyName") @XmlElement(required = true) String englishFamilyName,
//			@WebParam(name = "messageIdentifier") @XmlElement(required = true) String messageIdentifier,
//			@WebParam(name = "phoneContact") @XmlElement(required = true) String phoneContact,
//			@WebParam(name = "highestLevelAchievedCode") @XmlElement(required = true) String highestLevelAchievedCode,
//			@WebParam(name = "labourParticipationTypeCode") @XmlElement(required = true) String labourParticipationTypeCode,
//			@WebParam(name = "maritalStatusCode") @XmlElement(required = true) String maritalStatusCode,
//			@WebParam(name = "religionCode") @XmlElement(required = true) String religionCode,
//			@WebParam(name = "ioStatusCode") @XmlElement(required = true) String ioStatusCode,
//			@WebParam(name = "gender") @XmlElement(required = true) String gender,
//			@WebParam(name = "nationalityCode") @XmlElement(required = true) String nationalityCode,
//			@WebParam(name = "occupationCode") @XmlElement(required = true) String occupationCode,
//			@WebParam(name = "occupationTypeCode") @XmlElement(required = true) String occupationTypeCode,
//			@WebParam(name = "employerNumber") @XmlElement(required = true) String employerNumber,
//			@WebParam(name = "employerCardCountryCode") @XmlElement(required = true) String employerCardCountryCode,
//			@WebParam(name = "employerType") @XmlElement(required = true) String employerType,
//			@WebParam(name = "employmentStatusCode") @XmlElement(required = true) String employmentStatusCode,
//			@WebParam(name = "sponsorNumber") @XmlElement(required = true) String sponsorNumber,
//			@WebParam(name = "sponsorCardCounryCode") @XmlElement(required = true) String sponsorCardCounryCode,
//			@WebParam(name = "sponsorType") @XmlElement(required = true) String sponsorType,
//			@WebParam(name = "countryOfBirth") @XmlElement(required = true) String countryOfBirth,
//			@WebParam(name = "dateOfBirth") @XmlElement(required = true) String dateOfBirth,
//			@WebParam(name = "block") @XmlElement(required = true) String block,
//			@WebParam(name = "road") @XmlElement(required = true) String road,
//			@WebParam(name = "building") @XmlElement(required = true) String building,
//			@WebParam(name = "buildingAlpha") @XmlElement(required = true) String buildingAlpha,
//			@WebParam(name = "flat") @XmlElement(required = true) String flat,
//			@WebParam(name = "mailBox") @XmlElement(required = true) String mailBox,
//			@WebParam(name = "headOfHouseholdCpr") @XmlElement(required = true) String headOfHouseholdCpr,
//			@WebParam(name = "houseHoldRelationCode") @XmlElement(required = true) String houseHoldRelationCode, @WebParam(
//					name = "occupancyStatusCode") @XmlElement(required = true) String occupancyStatusCode,
//			@WebParam(name = "residential") @XmlElement(required = true) String residential, @WebParam(name = "passportNumber") @XmlElement(
//					required = true) String passportNumber,
//			@WebParam(name = "passportTypeCode") @XmlElement(required = true) String passportTypeCode, @WebParam(name = "issueDate") @XmlElement(
//					required = true) String issueDate, @WebParam(name = "expiryDate") @XmlElement(required = true) String expiryDate, @WebParam(
//							name = "passportSequenceNumber") @XmlElement(required = true) String passportSequenceNumber,
//			@WebParam(name = "arabicFirstName") @XmlElement(required = true) String arabicFirstName,
//			@WebParam(name = "arabicMiddleName1") @XmlElement(required = true) String arabicMiddleName1,
//			@WebParam(name = "arabicMiddleName2") @XmlElement(required = true) String arabicMiddleName2,
//			@WebParam(name = "arabicMiddleName3") @XmlElement(required = true) String arabicMiddleName3,
//			@WebParam(name = "arabicMiddleName4") @XmlElement(required = true) String arabicMiddleName4,
//			@WebParam(name = "arabicFamilyName") @XmlElement(required = true) String arabicFamilyName,
//			@WebParam(name = "placeOfBirthArabic") @XmlElement(required = true) String placeOfBirthArabic,
//			@WebParam(name = "placeOfBirthEnglish") @XmlElement(required = true) String placeOfBirthEnglish,
//			@WebParam(name = "specialisationCode") @XmlElement(required = true) String specialisationCode,
//			@WebParam(name = "educationLevelCode") @XmlElement(required = true) String educationLevelCode,
//			@WebParam(name = "unitNumber") @XmlElement(required = true) String unitNumber, @WebParam(name = "previousPassportNumber") @XmlElement(
//					required = true) String previousPassportNumber,
//			@WebParam(name = "passportImage") @XmlElement(required = true) String passportImage, @WebParam(name = "fatherCprNumber") @XmlElement(
//					required = true) String fatherCprNumber, @WebParam(name = "motherCprNumber") @XmlElement(required = true) String motherCprNumber,
//			@WebParam(name = "spouseCPRNumber") @XmlElement(required = true) String spouseCPRNumber, @WebParam(name = "photo") @XmlElement(
//					required = true) String photo, @WebParam(name = "photoDate") @XmlElement(required = true) String photoDate, @WebParam(
//							name = "signatureDate") @XmlElement(required = true) String signatureDate, @WebParam(name = "signature") @XmlElement(
//									required = true) String signature) throws ApplicationExceptionInfo;
//
}
