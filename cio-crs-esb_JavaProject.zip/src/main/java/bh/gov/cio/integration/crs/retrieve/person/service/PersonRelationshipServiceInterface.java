package bh.gov.cio.integration.crs.retrieve.person.service;


import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonRelationshipServiceInterface", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface PersonRelationshipServiceInterface
{

//	@WebResult(name = "PersonRelationshipInformation")
//	@WebMethod(operationName = "getPersonRelationship")
//	String getPersonRelationship(@WebParam(mode = WebParam.Mode.IN, name = "Security",
//	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
//			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
//			@WebParam(name = "relatedCprNumber") @XmlElement(required = true) Integer relatedCprNumber)
//			throws ApplicationExceptionInfo;


	@WebResult(name = "isRelated")
	@WebMethod(operationName = "checkRelationshipForDeathCertificate")
	boolean checkRelationshipForDeathCertificate(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "relatedCprNumber") @XmlElement(required = true) Integer relatedCprNumber)
			throws ApplicationExceptionInfo;

	@WebResult(name = "isRelated")
	@WebMethod(operationName = "checkRelationship")
	boolean checkRelationship(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "relatedCprNumber") @XmlElement(required = true) Integer relatedCprNumber)
			throws ApplicationExceptionInfo;


	@WebResult(name = "isParents")
	@WebMethod(operationName = "checkParentsRelationship")
	boolean checkParentsRelationship(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "fatherCPRNumber") @XmlElement(required = true) Integer fatherCPRNumber,
			@WebParam(name = "motherCPRNumber") @XmlElement(required = true) Integer motherCPRNumber
			)
			throws ApplicationExceptionInfo;
}
