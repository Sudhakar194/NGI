package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder =
{ "cprNumber", "arabicName", "englishName", "maritalStatusCode",
		"employmentStatusCode", "dateOfBirth", "gender", "arab", "GCC",
		"bahraini" })
public class ChildrenDetailDTO
{
	private Integer	cprNumber;

	private String	arabicName;
	private String	englishName;
	private String	maritalStatusCode;
	private String	employmentStatusCode;
	private String	dateOfBirth;
	private String	gender;
	private boolean	isArab;
	private boolean	isGCC;
	private boolean	isBahraini;

	public ChildrenDetailDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public ChildrenDetailDTO(Integer cprNumber, String arabicName,
			String englishName, String maritalStatusCode,
			String employmentStatusCode, String dateOfBirth, String gender,
			boolean isArab, boolean isGCC, boolean isBahraini)
	{
		super();
		this.cprNumber = cprNumber != null ? cprNumber : 0;
		this.arabicName = arabicName != null ? arabicName : "";
		this.englishName = englishName != null ? englishName : "";
		this.maritalStatusCode = maritalStatusCode != null ? maritalStatusCode
				: "";
		this.employmentStatusCode = employmentStatusCode != null ? employmentStatusCode
				: "";
		this.dateOfBirth = dateOfBirth != null ? dateOfBirth : "";
		this.gender = gender != null ? gender : "";
		this.isArab = isArab;
		this.isGCC = isGCC;
		this.isBahraini = isBahraini;
	}

	@XmlElement(required = true)
	public String getArabicName()
	{
		return arabicName;
	}

	@XmlElement(required = true)
	public Integer getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(required = true)
	public String getDateOfBirth()
	{
		return dateOfBirth;
	}

	@XmlElement(required = true)
	public String getEmploymentStatusCode()
	{
		return employmentStatusCode;
	}

	@XmlElement(required = true)
	public String getEnglishName()
	{
		return englishName;
	}

	@XmlElement(required = true)
	public String getGender()
	{
		return gender;
	}

	@XmlElement(required = true)
	public String getMaritalStatusCode()
	{
		return maritalStatusCode;
	}

	@XmlElement(required = true)
	public boolean isArab()
	{
		return isArab;
	}

	@XmlElement(required = true)
	public boolean isBahraini()
	{
		return isBahraini;
	}

	@XmlElement(required = true)
	public boolean isGCC()
	{
		return isGCC;
	}

	public void setArab(boolean isArab)
	{
		this.isArab = isArab;
	}

	public void setArabicName(String arabicName)
	{
		this.arabicName = arabicName;
	}

	public void setBahraini(boolean isBahraini)
	{
		this.isBahraini = isBahraini;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDateOfBirth(String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public void setEmploymentStatusCode(String employmentStatusCode)
	{
		this.employmentStatusCode = employmentStatusCode;
	}

	public void setEnglishName(String englishName)
	{
		this.englishName = englishName;
	}

	public void setGCC(boolean isGCC)
	{
		this.isGCC = isGCC;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public void setMaritalStatusCode(String maritalStatusCode)
	{
		this.maritalStatusCode = maritalStatusCode;
	}

}
