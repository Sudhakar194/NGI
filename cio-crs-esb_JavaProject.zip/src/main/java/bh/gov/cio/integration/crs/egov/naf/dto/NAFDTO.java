package bh.gov.cio.integration.crs.egov.naf.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "NAF", propOrder = { "cprNumber","validated"})
public class NAFDTO {

	public NAFDTO() {
	}

	private String cprNumber;
	private boolean isValidated;

	public NAFDTO(String cprNumber, boolean isValidated) {
		super();
		this.cprNumber = cprNumber;
		this.isValidated = isValidated;
	}
	

	@XmlElement(name = "cprNumber")
	public String getCprNumber() {
		return cprNumber;
	}

	public void setCprNumber(String cprNumber) {
		this.cprNumber = cprNumber;
	}


	@XmlElement(name = "validated")
	public boolean isValidated() {
		return isValidated;
	}



	public void setValidated(boolean isValidated) {
		this.isValidated = isValidated;
	}

}
