package bh.gov.cio.integration.crs.retrieve.family.rco.service.dto;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.CommonTypes.Nationality;

@XmlType(name = "MotherInfoDTO", propOrder =
{ "arabicName", "englishName", "nationalityIndicator",
		"age", "maritalStatus","isEmployed","isAlive" })
public class MotherInfoDTO
{
	String arabicName,englishName;
	CommonTypes.Nationality nationalityIndicator;
	String age;
	String maritalStatus;
	boolean isEmployed;
	boolean isAlive;

	public MotherInfoDTO() {
		super();
	}

	public MotherInfoDTO(String arabicName, String englishName, Nationality nationalityIndicator, String age,
			String maritalStatus, boolean isEmployed, boolean isAlive) {
		super();
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.nationalityIndicator = nationalityIndicator;
		this.age = age;
		this.maritalStatus = maritalStatus;
		this.isEmployed = isEmployed;
		this.isAlive = isAlive;
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public CommonTypes.Nationality getNationalityIndicator() {
		return nationalityIndicator;
	}

	public void setNationalityIndicator(CommonTypes.Nationality nationalityIndicator) {
		this.nationalityIndicator = nationalityIndicator;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public boolean getIsAlive() {
		return isAlive;
	}

	public void setIsAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	public boolean getIsEmployed() {
		return isEmployed;
	}

	public void setIsEmployed(boolean isEmployed) {
		this.isEmployed = isEmployed;
	}
	

}
