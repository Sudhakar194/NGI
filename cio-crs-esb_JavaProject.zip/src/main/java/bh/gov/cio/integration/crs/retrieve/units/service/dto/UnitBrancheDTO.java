package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author cspomlh
 * 
 */
@XmlType(name = "UnitBranch", propOrder =
{ "branchArabicName", "branchEnglishName" })
public class UnitBrancheDTO
{
	private String branchArabicName;
	private String branchEnglishName;

	public UnitBrancheDTO()
	{
		super();

	}

	public UnitBrancheDTO(String activityArabicName, String activityEnglishName)
	{
		super();
		this.branchArabicName = activityArabicName;
		this.branchEnglishName = activityEnglishName;
	}

	@XmlElement(name = "branchArabicName", required = true)
	public String getBranchArabicName() {
		return branchArabicName;
	}

	public void setBranchArabicName(String branchArabicName) {
		this.branchArabicName = branchArabicName;
	}

	@XmlElement(name = "branchEnglishName", required = true)
	public String getBranchEnglishName() {
		return branchEnglishName;
	}

	public void setBranchEnglishName(String branchEnglishName) {
		this.branchEnglishName = branchEnglishName;
	}


}
