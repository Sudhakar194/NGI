package bh.gov.cio.integration.gosi.retrieve.employment.service.dto;

public class JobDetailsDTO implements java.io.Serializable
{
	/**
	 * 
	 */
	private Integer				cprNumber;
	private Integer				crEmployerNumber;
	private Integer				unitEmployerNumber;
	private String				crJobCode;
	private String				unitJobCode;
	private Integer				workStatus;

	private static final long	serialVersionUID	= 1L;

	public Integer getCprNumber()
	{
		return cprNumber;
	}

	public Integer getCrEmployerNumber()
	{
		return crEmployerNumber;
	}

	public String getCrJobCode()
	{
		return crJobCode;
	}

	public Integer getUnitEmployerNumber()
	{
		return unitEmployerNumber;
	}

	public String getUnitJobCode()
	{
		return unitJobCode;
	}

	public Integer getWorkStatus()
	{
		return workStatus;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setCrEmployerNumber(Integer crEmployerNumber)
	{
		this.crEmployerNumber = crEmployerNumber;
	}

	public void setCrJobCode(String crJobCode)
	{
		this.crJobCode = crJobCode;
	}

	public void setUnitEmployerNumber(Integer unitEmployerNumber)
	{
		this.unitEmployerNumber = unitEmployerNumber;
	}

	public void setUnitJobCode(String unitJobCode)
	{
		this.unitJobCode = unitJobCode;
	}

	public void setWorkStatus(Integer workStatus)
	{
		this.workStatus = workStatus;
	}

}
