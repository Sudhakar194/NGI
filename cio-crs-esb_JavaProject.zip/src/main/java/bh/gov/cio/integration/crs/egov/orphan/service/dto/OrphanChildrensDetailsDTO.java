package bh.gov.cio.integration.crs.egov.orphan.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "OrphanChildrensDetails", propOrder =
{ "cprNumber","arabicFullName", "englishFullName", "isLessThan18"})

public class OrphanChildrensDetailsDTO
{
	private java.lang.String	cprNumber;
	private java.lang.String	arabicFullName;
	private java.lang.String	englishFullName;
	private boolean isLessThan18;
	public OrphanChildrensDetailsDTO()
	{
		super();
	}
	public OrphanChildrensDetailsDTO(String cprNumber , String arabicFullName, String englishFullName, boolean isLessThan18) {
		super();
		this.cprNumber = cprNumber;
		this.arabicFullName = arabicFullName;
		this.englishFullName = englishFullName;
		this.isLessThan18 = isLessThan18;
	}
	@XmlElement(name = "ArabicFullName")
	public java.lang.String getArabicFullName()
	{
		return arabicFullName;
	}
	@XmlElement(name = "EnglishFullName")
	public java.lang.String getEnglishFullName()
	{
		return englishFullName;
	}
	@XmlElement(name = "CPRNumber")
	public java.lang.String getCprNumber() {
		return cprNumber;
	}
	public void setArabicFullName(java.lang.String arabicFullName)
	{
		this.arabicFullName = arabicFullName;
	}
	public void setEnglishFullName(java.lang.String englishFullName)
	{
		this.englishFullName = englishFullName;
	}
	public boolean getIsLessThan18() {
		return isLessThan18;
	}
	public void setIsLessThan18(boolean isLessThan18) {
		this.isLessThan18 = isLessThan18;
	}
	public void setCprNumber(java.lang.String cprNumber) {
		this.cprNumber = cprNumber;
	}
}
