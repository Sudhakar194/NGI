package bh.gov.cio.integration.crs.egov.gdt.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlType(name = "AddressVerification", propOrder = { "flatNumber", "buildingNumber", "buildingAlpha",
		"roadNumber", "blockNumber", "isValid"})
public class AddressVerificationDTO {

	
	Integer buildingNumber;
	Integer flatNumber;
	String buildingAlpha;
	Integer roadNumber;
	Integer blockNumber;
	String isValid;
	
	
	public AddressVerificationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AddressVerificationDTO(Integer flatNumber, Integer buildingNumber, String buildingAlpha,
			Integer roadNumber, Integer blockNumber, String isValid) {
		super();
		this.flatNumber = flatNumber;
		this.buildingNumber = buildingNumber;
		this.buildingAlpha = buildingAlpha;
		this.roadNumber = roadNumber;
		this.blockNumber = blockNumber;
		this.isValid = isValid;
	}

	
	
	@XmlElement(name = "flatNumber")
	public Integer getFlatNumber() {
		return flatNumber;
	}


	public void setFlatNumber(Integer flatNumber) {
		this.flatNumber = flatNumber;
	}


	@XmlElement(name = "buildingNumber")
	public Integer getBuildingNumber() {
		return buildingNumber;
	}


	public void setBuildingNumber(Integer buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	@XmlElement(name = "buildingAlpha")
	public String getBuildingAlpha() {
		return buildingAlpha;
	}


	public void setBuildingAlpha(String buildingAlpha) {
		this.buildingAlpha = buildingAlpha;
	}

	@XmlElement(name = "roadNumber")
	public Integer getRoadNumber() {
		return roadNumber;
	}


	public void setRoadNumber(Integer roadNumber) {
		this.roadNumber = roadNumber;
	}

	@XmlElement(name = "blockNumber")
	public Integer getBlockNumber() {
		return blockNumber;
	}


	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}

	@XmlElement(name = "isValid")
	public String getIsValid() {
		return isValid;
	}


	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}
	
	
	
	
	
	
	
	
	
}
