package bh.gov.cio.integration.crs.retrieve.family.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import bh.gov.cio.integration.crs.retrieve.family.service.dto.FamilyBasicSpecialInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(
		name = "FamilyBasicSpecialInfoService",
		targetNamespace = "http://service.family.retrieve.crs.integration.cio.gov.bh/")
public interface FamilyBasicSpecialInfoServiceInterface
{

	// military access service
	@WebMethod(operationName = "getFamilyBasicSpecialInfo")
	FamilyBasicSpecialInfoDTO getFamilyBasicSpecialInfo
	(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,@WebParam(name = "cprNumber") Integer cprNumber)
			throws ApplicationExceptionInfo;

}
