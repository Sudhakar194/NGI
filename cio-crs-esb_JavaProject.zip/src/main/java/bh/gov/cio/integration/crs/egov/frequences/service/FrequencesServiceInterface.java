package bh.gov.cio.integration.crs.egov.frequences.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.crs.egov.frequences.dto.FrequencesDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "frequencesSoapService", targetNamespace = "http://service.frequences.egov.crs.integration.cio.gov.bh/")
public interface FrequencesServiceInterface extends CommonTypes
{
	@WebResult(name = "EstablishmentInfo")
	@WebMethod(operationName = "getEstablishmentInfo")
	FrequencesDTO getEstablishmentInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "EstablishmentNumber") @XmlElement(required = true) Integer cr_unit_number,@WebParam(name = "EstablishmentType") @XmlElement(required = true) CommonTypes.EstablishmentType establishmentType) throws ApplicationExceptionInfo;
}
