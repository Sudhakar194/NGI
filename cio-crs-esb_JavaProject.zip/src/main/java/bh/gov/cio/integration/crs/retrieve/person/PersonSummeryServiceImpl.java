package bh.gov.cio.integration.crs.retrieve.person;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonSummeryServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServiceSummaryDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonSummeryService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonSummeryService"
public class PersonSummeryServiceImpl implements PersonSummeryServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonSummeryServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonSummery" })
	@WebMethod(operationName = "getPersonSummery")
	public PersonServiceSummaryDTO getPersonSummery(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonSummery(Integer, Integer, Date) - start");
			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ", blockNumber = " + blockNumber + ", cardExpiryDate = " + cardExpiryDate + ")");
		}
		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		if (validationUtil.isMilitaryCpr(cprNumber))
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));

		PersonServiceSummaryDTO personSummaryDTO = null;
		try
		{
			final PersonSummary personSummary = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final boolean isBahraini = (personSummary.getNationalityCountryCode().equals("499")||personSummary.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummary.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			personSummaryDTO = new PersonServiceSummaryDTO(personSummary.getCprNumber(), DateServiceImpl.formatDate(personSummary.getDateOfBirth()), personSummary.getDateOfBirthOld(), nationality,
					personSummary.getBirthCountryCode(), DateServiceImpl.formatDate(personSummary.getDateOfDeath()), personSummary.getDeathCountryCode(), personSummary.getArabicFullName(),
					personSummary.getArabicFirstName(), personSummary.getArabicMiddleName1(), personSummary.getArabicMiddleName2(), personSummary.getArabicMiddleName3(),
					personSummary.getArabicMiddleName4(), personSummary.getArabicFamilyName(), personSummary.getEnglishFullName(), personSummary.getEnglishFirstName(),
					personSummary.getEnglishMiddleName1(), personSummary.getEnglishMiddleName2(), personSummary.getArabicMiddleName3(), personSummary.getArabicMiddleName4(),
					personSummary.getEnglishFamilyName(), personSummary.getGender(), personSummary.getSponsorIndicator(), personSummary.getEmployerIndicator(), personSummary.getIsStudent(),
					personSummary.getIsClearingAgent(), personSummary.getIsWatchlisted(),/*
																						 * personSummary
																						 * .
																						 * getIsLostCard
																						 * (
																						 * )
																						 * ,
																						 * personSummary
																						 * .
																						 * getIsDeleted
																						 * (
																						 * )
																						 * ,
																						 */
					personSummary.getIsPrisoner(), personSummary.getIsSmartcard(),/*
																				 * personSummary
																				 * .
																				 * getIsNationalityConfirmed
																				 * (
																				 * )
																				 * ,
																				 */
					personSummary.getContactPhone(), personSummary.getBirthPlaceArabic(), personSummary.getBirthPlaceEnglish(), personSummary.getFatherCprNumber(), personSummary.getMotherCprNumber(),
					personSummary.getSpouseCpr(), personSummary.getReligionCode(), personSummary.getLabourParticipationTypeCode(), personSummary.getLabourParticipationTypeArabicName(),
					personSummary.getLabourParticipationTypeEnglishName(), personSummary.getHighestLevelAchievedCode(), personSummary.getMaritalStatusCode(), personSummary.getEmploymentStatusCode(),
					personSummary.getIoStatusCode());

			if (logger.isDebugEnabled())
				logger.debug("getPersonSummery() -  : personSummaryDTO = " + personSummaryDTO);

			if (logger.isDebugEnabled())
				logger.debug("getPersonSummery(Integer, Integer, Date) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonSummery(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Summary Details Not found", new ApplicationException(exception.getMessage()));
		}
		return personSummaryDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
