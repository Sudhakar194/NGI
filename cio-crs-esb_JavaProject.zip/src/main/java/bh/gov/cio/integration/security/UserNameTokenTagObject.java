package bh.gov.cio.integration.security;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

//@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UsernameToken", propOrder =
{ "username", "password" })
public final class UserNameTokenTagObject implements Serializable
{
	String	username;
	String	password;

	// String nonce;
	// String created;

	@XmlElement(name = "Username",
	// namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			required = true)
	public String getUsername()
	{
		return username;
	}

	public void setUsername(String username)
	{
		this.username = username;
	}

	@XmlElement(name = "Password",
	// namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			required = true)
	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	// @XmlElement(name = "Nonce",// namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
	// required = false)
	// public String getNonce()
	// {
	// return nonce;
	// }
	//
	// public void setNonce(String nonce)
	// {
	// this.nonce = nonce;
	// }

	// @XmlElement(name = "Created", // namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd",
	// required = false)
	// public String getCreated()
	// {
	// return created;
	// }
	//
	// public void setCreated(String created)
	// {
	// this.created = created;
	// }
}
