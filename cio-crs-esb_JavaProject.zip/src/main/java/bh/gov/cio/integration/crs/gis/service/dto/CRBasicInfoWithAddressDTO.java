package bh.gov.cio.integration.crs.gis.service.dto;

import javax.xml.bind.annotation.XmlType;



@XmlType(name = "CRBasicInfo", propOrder =
{ "crNumber","crArabicName", "crEnglishName", "crAddress" })

public class CRBasicInfoWithAddressDTO
{
	private Integer 					crNumber;
	private String						crArabicName;
	private String						crEnglishName;
	private CRAddressInfoDTO			crAddress;
	public CRBasicInfoWithAddressDTO()
	{
		super();

	}
	public Integer getCrNumber() {
		return crNumber;
	}
	public void setCrNumber(Integer crNumber) {
		this.crNumber = crNumber;
	}
	public String getCrArabicName() {
		return crArabicName;
	}
	public void setCrArabicName(String crArabicName) {
		this.crArabicName = crArabicName;
	}
	public String getCrEnglishName() {
		return crEnglishName;
	}
	public void setCrEnglishName(String crEnglishName) {
		this.crEnglishName = crEnglishName;
	}
	public CRAddressInfoDTO getCrAddress() {
		return crAddress;
	}
	public void setCrAddress(CRAddressInfoDTO crAddress) {
		this.crAddress = crAddress;
	}
	public CRBasicInfoWithAddressDTO(Integer crNumber, String crArabicName, String crEnglishName,
			CRAddressInfoDTO crAddress) {
		super();
		this.crNumber = crNumber;
		this.crArabicName = crArabicName;
		this.crEnglishName = crEnglishName;
		this.crAddress = crAddress;
	}
	


}