package bh.gov.cio.integration.crs.retrieve.disability;

import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Disability;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.disability.service.PersonDisabilityBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.disability.service.dto.DisabilityServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(
		name = "PersonDisabilityBasicInfoService",
		targetNamespace = "http://service.disability.retrieve.crs.integration.cio.gov.bh/")
//serviceName = "PersonDisabilityBasicInfoService",
public class PersonDisabilityBasicInfoServiceImpl implements
		PersonDisabilityBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger			= LoggerFactory.getLogger(PersonDisabilityBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationUtil	= new ValidationServiceImpl();
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@Override
	@Secured(
	{ "ROLE_getAllPersonDisabilityBasicInfo" })
	@WebMethod(operationName = "getAllPersonDisabilityBasicInfo")
	public DisabilityServiceBasicInfoDTO[] getAllPersonDisabilityBasicInfo(
			SecurityTagObject security, Integer cprNumber, Integer blockNumber,
			Date cardExpiryDate) throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
			logger.debug("getPersonDisabilityBasicInfo(Integer, Integer, Date) - start");

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number",
					new ApplicationException("Wrong Block Number"));
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
			throw new ApplicationExceptionInfo("Expiry Date",
					new ApplicationException("Wrong Expiry Date"));
		// if (validationUtil.isMilitaryCpr(cprNumber))
		// {
		// throw new ApplicationExceptionInfo("UNAUTHORIZED",
		// new ApplicationException("UNAUTHORIZED"));
		// }
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted"));
		DisabilityServiceBasicInfoDTO[] disabilityServiceBasicInfoDTO = null;
		try
		{
			final List<Disability> personDisabilities = getCrsService()
					.getDisabilityServiceRef().getDisabilityDetails(cprNumber);
			disabilityServiceBasicInfoDTO = new DisabilityServiceBasicInfoDTO[personDisabilities
					.size()];
			String disabilityCode, disabilityDate, disabilityArName, disabilityEnName;
			if (personDisabilities != null)
			{
				final Integer disCprNumber = personDisabilities.get(0)
						.getCprNumber();
				int i = 0;
				for (final Disability disability : personDisabilities)
				{
					disabilityCode = disability.getDisabilityCode();
					disabilityDate = DateServiceImpl.formatDate(disability
							.getDisabilityDate());
					disabilityArName = disability.getDisabilityNameArabic();
					disabilityEnName = disability.getDisabilityNameEnglish();
					disabilityServiceBasicInfoDTO[i] = new DisabilityServiceBasicInfoDTO(
							disCprNumber, disabilityCode, disabilityDate,
							disabilityArName, disabilityEnName);
					i++;
				}
			}

			if (logger.isDebugEnabled())
				logger.debug("getPersonDisabilityBasicInfo(Integer, Integer, Date) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonDisabilityBasicInfo(Integer, Integer, Date) Error: "
						+ exception.getMessage());
			throw new ApplicationExceptionInfo("Disability Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return disabilityServiceBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

//	@Override
//	@Secured(
//	{ "ROLE_getPersonDisabilityBasicInfo" })
//	@WebMethod(operationName = "getPersonDisabilityBasicInfo")
//	public DisabilityServiceBasicInfoDTO[] getPersonDisabilityBasicInfo(
//			SecurityTagObject security, Integer cprNumber, Integer blockNumber,
//			Date cardExpiryDate) throws ApplicationExceptionInfo
//	{
//		if (logger.isDebugEnabled())
//			logger.debug("getPersonDisabilityBasicInfo(Integer, Integer, Date) - start");
//
//		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
//			throw new ApplicationExceptionInfo("Block Number",
//					new ApplicationException("Wrong Block Number"));
//		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
//			throw new ApplicationExceptionInfo("Expiry Date",
//					new ApplicationException("Wrong Expiry Date"));
//		if (validationUtil.isMilitaryCpr(cprNumber))
//			throw new ApplicationExceptionInfo("UNAUTHORIZED",
//					new ApplicationException("UNAUTHORIZED"));
//		if (validationUtil.isDeletedCpr(cprNumber))
//			throw new ApplicationExceptionInfo("CPR Number Deleted",
//					new ApplicationException("CPR Number Deleted"));
//		DisabilityServiceBasicInfoDTO[] disabilityServiceBasicInfoDTO = null;
//		try
//		{
//			final List<Disability> personDisabilities = getCrsService()
//					.getDisabilityServiceRef().getDisabilityDetails(cprNumber);
//			disabilityServiceBasicInfoDTO = new DisabilityServiceBasicInfoDTO[personDisabilities
//					.size()];
//			String disabilityCode, disabilityDate, disabilityArName, disabilityEnName;
//			if (personDisabilities != null)
//			{
//				final Integer disCprNumber = personDisabilities.get(0)
//						.getCprNumber();
//				int i = 0;
//				for (final Disability disability : personDisabilities)
//				{
//					disabilityCode = disability.getDisabilityCode();
//					disabilityDate = DateServiceImpl.formatDate(disability
//							.getDisabilityDate());
//					disabilityArName = disability.getDisabilityNameArabic();
//					disabilityEnName = disability.getDisabilityNameEnglish();
//					disabilityServiceBasicInfoDTO[i] = new DisabilityServiceBasicInfoDTO(
//							disCprNumber, disabilityCode, disabilityDate,
//							disabilityArName, disabilityEnName);
//					i++;
//				}
//			}
//
//			if (logger.isDebugEnabled())
//				logger.debug("getPersonDisabilityBasicInfo(Integer, Integer, Date) - end");
//		}
//		catch (final Exception exception)
//		{
//			if (logger.isDebugEnabled())
//				logger.error("getPersonDisabilityBasicInfo(Integer, Integer, Date) Error: "
//						+ exception.getMessage());
//			throw new ApplicationExceptionInfo("Disability Details Not found",
//					new ApplicationException(exception.getMessage()));
//		}
//		return disabilityServiceBasicInfoDTO;
//	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
