package bh.gov.cio.integration.crs.update.family.service;

import java.net.UnknownHostException;

import bh.gov.cio.crs.util.exception.ApplicationException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

public interface UpdateDivorceServiceInterface
{
	String deleteDivorce(Integer husbandCPR, Integer wifeCPR, String divorceDate)
			throws ApplicationExceptionInfo, UnknownHostException,
			ApplicationException, BusinessException;

	String deleteDivorce(
			String husbandID,
			String husbandNationalityCode,
			String wifeID,
			String wifeNationalityCode,
			String divorceDate)
			throws ApplicationExceptionInfo,
			UnknownHostException,
			ApplicationException,
			BusinessException;

	String getDivorceDates(Integer CPRNumber) throws ApplicationExceptionInfo,
			UnknownHostException, ApplicationException, BusinessException;

	String getDivorceDates(
				String IDNumber,
				String nationalityCode)
				throws ApplicationExceptionInfo,
				UnknownHostException,
				ApplicationException,
				BusinessException;

	String updateDivorce(Integer cprNumber, Integer spouseCPR,
				String marriageDate) throws ApplicationExceptionInfo,
				UnknownHostException, ApplicationException, BusinessException;

	String updateDivorce(
			String husbandID,
			String husbandNationalityCode,
			String wifeID,
			String wifeNationalityCode,
			String marriageDate)
			throws ApplicationExceptionInfo,
			UnknownHostException,
			ApplicationException,
			BusinessException;
}
