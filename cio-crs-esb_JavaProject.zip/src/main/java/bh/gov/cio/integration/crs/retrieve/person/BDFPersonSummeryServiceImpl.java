package bh.gov.cio.integration.crs.retrieve.person;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.CRSEntity;
import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.BiometricService;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.BDFPersonSummeryServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.BDFPersonChildDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.BDFPersonChildDTO.Children;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.BDFPersonDivorceDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.BDFPersonDivorceDTO.BDFPersonDivorce;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.BDFPersonMarriageDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.BDFPersonMarriageDTO.BDFPersonMarriage;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.BDFPersonServiceSummaryDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "BDFEmployeeSummeryService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonSummeryService"
public class BDFPersonSummeryServiceImpl implements BDFPersonSummeryServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(BDFPersonSummeryServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getBDFEmployerDetails" })
	@WebMethod(operationName = "getBDFEmployerDetails")
	public BDFPersonServiceSummaryDTO getBDFEmployerDetails(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonSummery(Integer, Integer, Date) - start");
		}
		if (!validationUtil.isBDFEmployeeCpr(cprNumber))
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));

		BDFPersonServiceSummaryDTO bdfPersonServiceSummaryDTO = new BDFPersonServiceSummaryDTO();
		try {
			AddressService as = crsService.getAddressServiceRef();
			PersonService ps = crsService.getPersonServiceRef();
			BiometricService bs = crsService.getBiometricServiceRef();
			FamilyService fs = crsService.getFamilyServiceRef();
			PersonSummary personSummary = ps.getPersonSummary(cprNumber);

			// 4- Address
			Address address = new Address();
			List<Address> addresses = as.getPersonAddressByCpr(cprNumber);
			if (addresses != null && !addresses.isEmpty()) {
				address = addresses.get(0);
			}
			bdfPersonServiceSummaryDTO.setFlat(address.getFlatNumber());
			bdfPersonServiceSummaryDTO.setBldg(address.getBuildingNumber());
			bdfPersonServiceSummaryDTO.setBldgAlpha(address.getNameAlphaEnglish());
			bdfPersonServiceSummaryDTO.setRoad(address.getRoadNumber());
			bdfPersonServiceSummaryDTO.setBlock(address.getBlockNumber());
			// 3- Family
			// - 3.1 Father /Mother
			if (personSummary.getFatherCprNumber() != null && personSummary.getFatherCprNumber() > 0) {
				PersonBasicInfo father = ps.getPersonBasicInfo(personSummary.getFatherCprNumber());
				bdfPersonServiceSummaryDTO.setFatherCPRNumber(father.getCprNumber());
				bdfPersonServiceSummaryDTO.setFatherNameArabic(father.getArabicName());
				bdfPersonServiceSummaryDTO.setFatherNameEnglish(father.getEnglishName());

			}
			if (personSummary.getMotherCprNumber() != null && personSummary.getMotherCprNumber() > 0) {
				PersonBasicInfo mother = ps.getPersonBasicInfo(personSummary.getMotherCprNumber());
				bdfPersonServiceSummaryDTO.setMotherCPRNumber(mother.getCprNumber());
				bdfPersonServiceSummaryDTO.setMotherNameArabic(mother.getArabicName());
				bdfPersonServiceSummaryDTO.setMotherNameEnglish(mother.getEnglishName());
			}
			// - 3.2 spouses
			List<Marriage> temp = fs.getPersonMarriageDivorceList(cprNumber);
			List<Marriage> indMarriageDivorces = new ArrayList<Marriage>();

			BDFPersonMarriageDTO marriageList = new BDFPersonMarriageDTO();
			ArrayList<BDFPersonMarriage> marriages = new ArrayList<BDFPersonMarriage>();

			BDFPersonDivorceDTO divorcesList = new BDFPersonDivorceDTO();
			ArrayList<BDFPersonDivorce> divorces  = new ArrayList<BDFPersonDivorce>();

			if (null != temp && !temp.isEmpty()) {
				for (Marriage m : temp) {
					String gccId = ps.getGccIdByCPR(cprNumber);
					if (gccId == null) {
						String strCPR = ("" + (m.getPartnerCprNumber() + 1000000000)).substring(1);
						gccId = strCPR;
					}
					m.setPartnerGccId(gccId);

					PersonBasicInfo pbi = ps.getPersonBasicInfo(m.getPartnerCprNumber());
					String spouseEnglishName = pbi.getEnglishName();
					String spouseArabicName = pbi.getArabicName();
					if (m.getPartnerName() == null || m.getPartnerName().trim().equals("")) {
						m.setPartnerName(spouseEnglishName);
					}
					List<CRSEntity> ownedCRs =ps.getPersonOwnedCRs(m.getPartnerCprNumber());
					boolean hasCR = (ownedCRs != null &&  ownedCRs.size () > 0 ) ? true : false;

					if (m.getLastActionWithPartner().equals("DIVORCE")) {
						BDFPersonDivorce divorce = new BDFPersonDivorce(m.getPartnerCprNumber(), spouseArabicName,spouseEnglishName,null,m.getMarriageDivorceAsDate(),hasCR);
						divorces.add(divorce);
					} else if (m.getLastActionWithPartner().equals("MARRIAGE")) {
						BDFPersonMarriage marriage  = new BDFPersonMarriage( m.getPartnerCprNumber(), spouseArabicName,
								spouseEnglishName,null,m.getMarriageDivorceAsDate(),hasCR);
						marriages.add(marriage);
					} else {
						continue;
					}
				}
				divorcesList.setDivorce(divorces);
				marriageList.setMarriage(marriages);
				indMarriageDivorces.addAll(temp);
			}
			bdfPersonServiceSummaryDTO.setMarriageList(marriageList);
			bdfPersonServiceSummaryDTO.setDivorceList(divorcesList);

			try {
				Integer numberOfActiveMarriages = null;//fs.getPersonNumberOfActiveMarriages(cprNumber);
				bdfPersonServiceSummaryDTO.setNumberOfActiveMarriages(numberOfActiveMarriages);

			} catch (Exception ex) {
				logger.debug("Number Of Active Marriages <" + cprNumber + "> " + ex.getMessage());
			}

			// - 3.3 children
			HashMap childMap = new HashMap();
			List<PersonSummary> childrenSummary = new ArrayList<PersonSummary>();
			
			BDFPersonChildDTO childrenList = new BDFPersonChildDTO();
			ArrayList<Children> children = new ArrayList<BDFPersonChildDTO.Children>();
			
			try {
				childMap = fs.getPersonChildrenBySpouse(cprNumber);
			} catch (Exception ex) {
				logger.debug("No Children found for <" + cprNumber + "> " + ex.getMessage());
			}

			Collection coll = childMap.values();
			Iterator iterator = coll.iterator();
			while (iterator.hasNext()) {
				childrenSummary.addAll((List<PersonSummary>) iterator.next());
			}

			for (PersonSummary child : childrenSummary) {

				PersonBasicInfo childBasicInfo = ps.getPersonBasicInfo(child.getCprNumber());
				if (childBasicInfo.getArabicName() == null) {
					logger.debug("Arabic name is null for child");
					childBasicInfo.setArabicName("");
				}
				List<CRSEntity> ownedCRs =ps.getPersonOwnedCRs(child.getCprNumber());
				boolean hasCR = (ownedCRs != null &&  ownedCRs.size () > 0 ) ? true : false;
				children.add(new Children(childBasicInfo.getCprNumber(),
						childBasicInfo.getArabicName(), childBasicInfo.getEnglishName(),hasCR));
			}
			childrenList.setChildren(children);
			bdfPersonServiceSummaryDTO.setChildrenList(childrenList);
			// 3.4 photo
			byte[] photo = bs.getPersonPhoto(cprNumber);
			bdfPersonServiceSummaryDTO.setPhoto(photo);
			bdfPersonServiceSummaryDTO.setIoStatus(personSummary.getIoStatusCode());
			bdfPersonServiceSummaryDTO.setMaritalStatus(personSummary.getMaritalStatusCode());

		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getPersonSummery(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Summary Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return bdfPersonServiceSummaryDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

}
