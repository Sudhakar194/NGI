package bh.gov.cio.integration.crs.lmra.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.lmra.dto.IsBahrainiWifeDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsBahrainiWifeService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public interface IsBahrainiWifeServiceInterface
{
	@WebResult(name = "WifeFalgs")
	@WebMethod(operationName = "IsBahrainiWife")
	IsBahrainiWifeDTO IsBahrainiWife(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
