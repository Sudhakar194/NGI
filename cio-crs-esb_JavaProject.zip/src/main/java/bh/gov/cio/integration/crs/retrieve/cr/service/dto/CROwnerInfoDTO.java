package bh.gov.cio.integration.crs.retrieve.cr.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "CROwnerDetails", propOrder =
{ "ownerNumber", "ownerType", "ownerArabicName", "ownerEnglishName" })
public class CROwnerInfoDTO
{

	private int ownerNumber;
	private String ownerType;
	private String ownerArabicName;
	private String ownerEnglishName;

	public CROwnerInfoDTO()
	{
		super();

	}

	public CROwnerInfoDTO(int ownerNumber, String ownerType, String ownerArabicName, String ownerEnglishName)
	{
		super();
		this.ownerNumber = ownerNumber;
		this.ownerType = ownerType;
		this.ownerArabicName = ownerArabicName;
		this.ownerEnglishName = ownerEnglishName;
	}

	@XmlElement(name = "OwnerArabicName", required = true)
	public String getOwnerArabicName()
	{
		return ownerArabicName;
	}

	@XmlElement(name = "OwnerEnglishName", required = true)
	public String getOwnerEnglishName()
	{
		return ownerEnglishName;
	}

	@XmlElement(name = "OwnerNumber", required = true)
	public int getOwnerNumber()
	{
		return ownerNumber;
	}

	@XmlElement(name = "OwnerType", required = true)
	public String getOwnerType()
	{
		return ownerType;
	}

	public void setOwnerArabicName(String ownerArabicName)
	{
		this.ownerArabicName = ownerArabicName;
	}

	public void setOwnerEnglishName(String ownerEnglishName)
	{
		this.ownerEnglishName = ownerEnglishName;
	}

	public void setOwnerNumber(int ownerNumber)
	{
		this.ownerNumber = ownerNumber;
	}

	public void setOwnerType(String ownerType)
	{
		this.ownerType = ownerType;
	}

}
