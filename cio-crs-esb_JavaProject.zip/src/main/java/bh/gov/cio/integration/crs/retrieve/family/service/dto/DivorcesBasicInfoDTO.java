package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder =
{ "spouseDetail" })
public class DivorcesBasicInfoDTO
{
	private DivorcesDetailDTO[]	spouseDetail;

	public DivorcesBasicInfoDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public DivorcesBasicInfoDTO(DivorcesDetailDTO[] spouseDetail)
	{
		super();
		this.spouseDetail = spouseDetail;
	}

	@XmlElement(required = true)
	public DivorcesDetailDTO[] getSpouseDetail()
	{
		return spouseDetail;
	}

	public void setSpouseDetail(DivorcesDetailDTO[] spouseDetail)
	{
		this.spouseDetail = spouseDetail;
	}

}
