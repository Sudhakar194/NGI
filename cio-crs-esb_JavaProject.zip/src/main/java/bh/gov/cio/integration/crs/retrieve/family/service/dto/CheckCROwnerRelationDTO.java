package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder =
{ "isSonOrDaughter", "isSpouse", "isFather", "isMother" })
public class CheckCROwnerRelationDTO
{
	private boolean	isSonOrDaughter;
	private boolean	isSpouse;
	private boolean	isFather;
	private boolean	isMother;

	public CheckCROwnerRelationDTO(boolean isSonOrDaughter, boolean isSpouse, boolean isFather, boolean isMother)
	{
		super();
		this.isSonOrDaughter = isSonOrDaughter;
		this.isSpouse = isSpouse;
		this.isFather = isFather;
		this.isMother = isMother;
	}

	public CheckCROwnerRelationDTO()
	{
		super();
	}

	@XmlElement(required = true)
	public boolean getIsSonOrDaughter()
	{
		return isSonOrDaughter;
	}

	@XmlElement(required = true)
	public boolean getIsSpouse()
	{
		return isSpouse;
	}

	@XmlElement(required = true)
	public boolean getIsFather()
	{
		return isFather;
	}

	@XmlElement(required = true)
	public boolean getIsMother()
	{
		return isMother;
	}

	public void setIsSonOrDaughter(boolean isSonOrDaughter)
	{
		this.isSonOrDaughter = isSonOrDaughter;
	}

	public void setIsSpouse(boolean isSpouse)
	{
		this.isSpouse = isSpouse;
	}

	public void setIsFather(boolean isFather)
	{
		this.isFather = isFather;
	}

	public void setIsMother(boolean isMother)
	{
		this.isMother = isMother;
	}

}
