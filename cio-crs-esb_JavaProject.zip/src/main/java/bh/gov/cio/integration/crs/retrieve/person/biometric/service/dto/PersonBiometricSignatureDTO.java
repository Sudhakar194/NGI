package bh.gov.cio.integration.crs.retrieve.person.biometric.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonBiometricSignature", propOrder =
{ "cprNumber", "personSignature", "signatureDate" })
public class PersonBiometricSignatureDTO
{

	private Integer cprNumber;
	private byte[] personSignature;
	private String signatureDate;

	public PersonBiometricSignatureDTO()
	{
		super();

	}

	public PersonBiometricSignatureDTO(Integer cprNumber, byte[] personSignature, String signatureDate)
	{
		super();
		this.cprNumber = cprNumber;
		this.personSignature = personSignature;
		this.signatureDate = signatureDate;
	}

	@XmlElement(name = "CprNumber")
	public Integer getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(name = "PersonSignature")
	public byte[] getPersonSignature()
	{
		return personSignature;
	}

	@XmlElement(name = "SignatureDate")
	public String getSignatureDate()
	{
		return signatureDate;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setPersonSignature(byte[] personSignature)
	{
		this.personSignature = personSignature;
	}

	public void setSignatureDate(String signatureDate)
	{
		this.signatureDate = signatureDate;
	}

}
