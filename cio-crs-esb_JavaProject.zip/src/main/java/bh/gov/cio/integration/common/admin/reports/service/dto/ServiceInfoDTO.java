package bh.gov.cio.integration.common.admin.reports.service.dto;

import java.util.ArrayList;

public class ServiceInfoDTO {
	Integer numberOfServices;
	ArrayList<ServiceDetailsInfoDTO> serviceDetails;

}
