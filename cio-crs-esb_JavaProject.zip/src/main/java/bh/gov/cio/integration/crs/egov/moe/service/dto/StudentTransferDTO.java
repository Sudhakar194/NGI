package bh.gov.cio.integration.crs.egov.moe.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "StudentTransferInformation", propOrder = { "applicantIdNumber", "applicantEnglishName",
		"applicantArabicName", "studentIdNumber", "studentEnglishName", "studentArabicName", "studentBlockNumber" })
public class StudentTransferDTO {

	public StudentTransferDTO() {
	}

	private String	applicantIdNumber;
	private String	applicantEnglishName;
	private String	applicantArabicName;
	private String	studentIdNumber;
	private String	studentEnglishName;

	public StudentTransferDTO(String applicantIdNumber, String applicantEnglishName, String applicantArabicName,
			String studentIdNumber, String studentEnglishName, String studentArabicName, Integer studentBlockNumber) {
		super();
		this.applicantIdNumber = applicantIdNumber;
		this.applicantEnglishName = applicantEnglishName;
		this.applicantArabicName = applicantArabicName;
		this.studentIdNumber = studentIdNumber;
		this.studentEnglishName = studentEnglishName;
		this.studentArabicName = studentArabicName;
		this.studentBlockNumber = studentBlockNumber;
	}

	private String	studentArabicName;
	private Integer	studentBlockNumber;

	public String getApplicantIdNumber() {
		return applicantIdNumber;
	}

	public void setApplicantIdNumber(String applicantIdNumber) {
		this.applicantIdNumber = applicantIdNumber;
	}

	public String getApplicantEnglishName() {
		return applicantEnglishName;
	}

	public void setApplicantEnglishName(String applicantEnglishName) {
		this.applicantEnglishName = applicantEnglishName;
	}

	public String getApplicantArabicName() {
		return applicantArabicName;
	}

	public void setApplicantArabicName(String applicantArabicName) {
		this.applicantArabicName = applicantArabicName;
	}

	public String getStudentIdNumber() {
		return studentIdNumber;
	}

	public void setStudentIdNumber(String studentIdNumber) {
		this.studentIdNumber = studentIdNumber;
	}

	public String getStudentEnglishName() {
		return studentEnglishName;
	}

	public void setStudentEnglishName(String studentEnglishName) {
		this.studentEnglishName = studentEnglishName;
	}

	public String getStudentArabicName() {
		return studentArabicName;
	}

	public void setStudentArabicName(String studentArabicName) {
		this.studentArabicName = studentArabicName;
	}

	public Integer getStudentBlockNumber() {
		return studentBlockNumber;
	}

	public void setStudentBlockNumber(Integer studentBlockNumber) {
		this.studentBlockNumber = studentBlockNumber;
	}

}
