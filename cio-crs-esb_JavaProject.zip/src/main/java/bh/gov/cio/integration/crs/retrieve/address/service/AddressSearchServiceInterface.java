package bh.gov.cio.integration.crs.retrieve.address.service;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressSearchInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "AddressSearchService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
public interface AddressSearchServiceInterface
{
	@WebResult(name = "AddressesResult")
	@WebMethod(operationName = "getAddressesInfoByBlockAndRoad")
	List<AddressSearchInfoDTO> getAddressesInfoByBlockAndRoad(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "roadNumber") @XmlElement(required = true) Integer roadNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber) throws ApplicationExceptionInfo;

	@WebResult(name = "AddressResult")
	@WebMethod(operationName = "getAddressInfo")
	List<AddressSearchInfoDTO> getAddressInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "buildingNumber") @XmlElement(required = true) Integer buildingNumber,
			@WebParam(name = "roadNumber") @XmlElement(required = true) Integer roadNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber) throws ApplicationExceptionInfo;

}
