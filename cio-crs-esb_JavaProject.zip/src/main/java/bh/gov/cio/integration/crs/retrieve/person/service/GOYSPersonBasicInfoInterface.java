package bh.gov.cio.integration.crs.retrieve.person.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import org.apache.cxf.annotations.WSDLDocumentation;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.GOYSPersonBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GOYSPersonBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface GOYSPersonBasicInfoInterface
{
	@WebResult(name = "personBasicInformation")
	@WebMethod(operationName = "getGOYSPersonBasicInfo")
	@WSDLDocumentation("Service will allow applicants to online register for COURSES and VOLUNTEERING activities. Service will retreive applicant basic infomration  ")
	GOYSPersonBasicInfoDTO getGOYSPersonBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

	@WebResult(name = "personBasicInformation")
	@WebMethod(operationName = "getGOYSPersonBasicInfoWithEkey")
	@WSDLDocumentation("Service will allow applicants to online register for COURSES and VOLUNTEERING activities. Service will retreive applicant basic infomration ,using ekey ")
	GOYSPersonBasicInfoDTO getGOYSPersonBasicInfoWithEkey(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "eKeyCPRNumber") @XmlElement(required = true) String eKeyCPRNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp) throws ApplicationExceptionInfo;

	@WebResult(name = "isDependent")
	@WebMethod(operationName = "isDependent")
	@WSDLDocumentation("Service will allow guardians to register their dependents that are of range 9-14 years old and they are not yet eligible to register by themselves.  ")
	boolean isDependent(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "applicantCprNumber") @XmlElement(required = true) Integer applicantCprNumber,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
