package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonBasicDetails", propOrder =
{ "cprNumber", "arabicName", "englishName", "gender", "isBahraini", "dateOfBirth", "areaArabicName", "areaEnglishName", "governorateArabicName",
		"governorateEnglishName" })
public class GOYSPersonBasicInfoDTO
{
	private String cprNumber;
	private String arabicName;
	private String englishName;
	private String gender;
	private String isBahraini;
	private String dateOfBirth;
	private String areaArabicName;
	private String areaEnglishName;
	private String governorateArabicName;
	private String governorateEnglishName;

	public GOYSPersonBasicInfoDTO()
	{
		super();

	}

	public GOYSPersonBasicInfoDTO(String cprNumber, String arabicName, String englishName, String gender, String isBahraini, String dateOfBirth,
			String areaArabicName, String areaEnglishName, String governorateArabicName, String governorateEnglishName)
	{
		super();
		this.cprNumber = cprNumber;
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.gender = gender;
		this.isBahraini = isBahraini;
		this.dateOfBirth = dateOfBirth;
		this.areaArabicName = areaArabicName;
		this.areaEnglishName = areaEnglishName;
		this.governorateArabicName = governorateArabicName;
		this.governorateEnglishName = governorateEnglishName;
	}

	public String getArabicName()
	{
		return arabicName;
	}

	public String getAreaArabicName()
	{
		return areaArabicName;
	}

	public String getAreaEnglishName()
	{
		return areaEnglishName;
	}

	public String getCprNumber()
	{
		return cprNumber;
	}

	public String getDateOfBirth()
	{
		return dateOfBirth;
	}

	public String getEnglishName()
	{
		return englishName;
	}

	public String getGender()
	{
		return gender;
	}

	public String getGovernorateArabicName()
	{
		return governorateArabicName;
	}

	public String getGovernorateEnglishName()
	{
		return governorateEnglishName;
	}

	public String getIsBahraini()
	{
		return isBahraini;
	}

	public void setArabicName(String arabicName)
	{
		this.arabicName = arabicName;
	}

	public void setAreaArabicName(String areaArabicName)
	{
		this.areaArabicName = areaArabicName;
	}

	public void setAreaEnglishName(String areaEnglishName)
	{
		this.areaEnglishName = areaEnglishName;
	}

	public void setCprNumber(String cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDateOfBirth(String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public void setEnglishName(String englishName)
	{
		this.englishName = englishName;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public void setGovernorateArabicName(String governorateArabicName)
	{
		this.governorateArabicName = governorateArabicName;
	}

	public void setGovernorateEnglishName(String governorateEnglishName)
	{
		this.governorateEnglishName = governorateEnglishName;
	}

	public void setIsBahraini(String isBahraini)
	{
		this.isBahraini = isBahraini;
	}

}
