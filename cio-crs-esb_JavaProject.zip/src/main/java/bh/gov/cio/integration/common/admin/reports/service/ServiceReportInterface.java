package bh.gov.cio.integration.common.admin.reports.service;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.common.admin.reports.service.dto.ServiceDetailsInfoDTO;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "ServiceReportService", targetNamespace = "http://reports.admin.common.integration.cio.gov.bh/")
public interface ServiceReportInterface {

	@WebResult(name = "ServiceDetails")
	@WebMethod(operationName = "getServiceInformationByMinistry")
	ArrayList<ServiceDetailsInfoDTO> getServiceInformationByMinistry(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "Ministry") @XmlElement(required = true) String ministry);

	@WebResult(name = "NumberOfServices")
	@WebMethod(operationName = "getNumberOfServiceByMinistry")
	Integer getNumberOfServiceByMinistry(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "Ministry") @XmlElement(required = true) String ministry);

	
	@WebResult(name = "TotalNumberOfServices")
	@WebMethod(operationName = "getTotalNumberOfService")
	Integer getTotalNumberOfService(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security);

	@WebResult(name = "TotalNumberOfServicesByYear")
	@WebMethod(operationName = "getTotalNumberOfServiceByYear")
	Integer getTotalNumberOfServiceByYear(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "Year") @XmlElement(required = true) String year);

	@WebResult(name = "TotalNumberOfServicesByYearMonth")
	@WebMethod(operationName = "getTotalNumberOfServiceByYearMonth")
	Integer getTotalNumberOfServiceByYearMonth(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "Year") @XmlElement(required = true) String year,
			@WebParam(name = "Month") @XmlElement(required = true) String month
			);

	@WebResult(name = "NoOfHits")
	@WebMethod(operationName = "getNumberOfHits")
	Integer getNumberOfHits(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "ServiceName") @XmlElement(required = true) String serviceName
			);

	@WebResult(name = "ServiceDetails")
	@WebMethod(operationName = "getAllServicesInformation")
	ArrayList<ServiceDetailsInfoDTO> getAllServiceInformationByMinistry(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security);

	
	@WebResult(name = "MinistriesDetails")
	@WebMethod(operationName = "getMinstriesInformation")
	ArrayList<String> getMinstriesInformation(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security);

	@WebResult(name = "ServiceDetails")
	@WebMethod(operationName = "getServicesInformationByName")
	ArrayList<ServiceDetailsInfoDTO>  getServicesInformationByName(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "ServiceName") @XmlElement(required = true) String serviceName
			);


}
