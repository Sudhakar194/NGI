package bh.gov.cio.integration.crs.lmra.service;
	
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.lmra.dto.GetDomesticEmployeeRPDTO;
import bh.gov.cio.integration.crs.lmra.dto.GetForeignerEmployerDTO;
import bh.gov.cio.integration.crs.lmra.dto.IsRunAwayDomesticsEmployeeDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

	@WebService(name = "GetDomesticEmployeeInfoService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
	public interface GetDomesticEmployeeInfoServiceInterface {
		
		
		
		@WebResult(name = "ForeignerEmployer")
		@WebMethod(operationName = "getForeignerEmployer")
		GetForeignerEmployerDTO getForeignerEmployer(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
				@WebParam(name = "employeeCprNumber") @XmlElement(required = true) Integer employeeCprNumber) throws ApplicationExceptionInfo;

	
	
	
	
		@WebResult(name = "RunAwayDomesticsEmployee")
		@WebMethod(operationName = "isRunAwayDomesticsEmployee")
		IsRunAwayDomesticsEmployeeDTO isRunAwayDomesticsEmployee(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
				@WebParam(name = "employeeCprNumber") @XmlElement(required = true) Integer employeeCprNumber) throws ApplicationExceptionInfo;
	
	
	
		
		@WebResult(name = "DomesticEmployeeRP")
		@WebMethod(operationName = "getDomesticEmployeeRP")
		GetDomesticEmployeeRPDTO getDomesticEmployeeRP(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
				@WebParam(name = "employeeCprNumber") @XmlElement(required = true) Integer employeeCprNumber) throws ApplicationExceptionInfo;

	
	
	}

	
	
