package bh.gov.cio.integration.crs.update.mosd.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "UpdateDisabilityService", targetNamespace = "http://service.mosd.update.crs.integration.cio.gov.bh/")
public interface UpdateDisabilityService {
	@WebResult(name = "isUpdateSuccessful")
	@WebMethod(operationName = "UpdateDisability")
	boolean UpdateDisability(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "CPRNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "DisabilityCode") @XmlElement(required = true) String disabilityCode,
			@WebParam(name = "DisabilityDate") @XmlElement(required = true) Date disabilityDate) throws ApplicationExceptionInfo;

}
