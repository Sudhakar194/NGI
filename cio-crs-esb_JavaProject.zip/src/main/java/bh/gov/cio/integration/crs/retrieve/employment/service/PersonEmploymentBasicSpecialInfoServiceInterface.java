package bh.gov.cio.integration.crs.retrieve.employment.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.employment.service.dto.EmploymentServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonEmploymentBasicSpecialInfoService", targetNamespace = "http://service.employment.retrieve.crs.integration.cio.gov.bh/")
public interface PersonEmploymentBasicSpecialInfoServiceInterface
{

	// For Military - interior employers
	@WebResult(name = "EmploymentBasicInformatoin")
	@WebMethod(operationName = "getPersonEmploymentBasicSpecialInfo")
	EmploymentServiceBasicInfoDTO[] getPersonEmploymentBasicSpecialInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber)
			throws ApplicationExceptionInfo;

}
