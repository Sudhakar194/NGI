package bh.gov.cio.integration.crs.egov.gcc;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import org.joda.time.DateTime;
import org.joda.time.DateTimeComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.sc.GccPerson;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.gcc.service.GCCPersonVerificationServiceInterface;
import bh.gov.cio.integration.crs.egov.gcc.service.dto.GCCPersonVerificationDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "ValidateGCCPersonInfoService", targetNamespace = "http://service.gcc.egov.crs.integration.cio.gov.bh/")
public class GCCPersonVerificationServiceImpl implements GCCPersonVerificationServiceInterface {

	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	@Autowired
	private ValidationServiceImpl validationUtil;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_ValidateGCCPersonInfo" })
	@WebResult(name = "GCCPersonCPR")
	@WebMethod(operationName = "getGCCPersonCPR")
	public Integer getGCCPersonCPR(SecurityTagObject security, String idNumber, String countryCode)
			throws ApplicationExceptionInfo {
		Integer cprNumber = 0;

		try {
			cprNumber = validationUtil.getGCCCpr(idNumber, countryCode);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "001"));
		}

		return cprNumber;
	}

	@Override
	@Secured({ "ROLE_ValidateGCCPersonInfo" })
	@WebMethod(operationName = "ValidateGCCPersonInfo")
	public GCCPersonVerificationDTO ValidateGCCPersonInfo(SecurityTagObject security, String idNumber, String gender,
			String nationality, Date dob) throws ApplicationExceptionInfo {
		// TODO Auto-generated method stub

		GCCPersonVerificationDTO dto = new GCCPersonVerificationDTO();
		dto.setIdNumber(idNumber);

		try {
			GccPerson gccPerson = crsService.getPersonServiceRef().getGccPerson(idNumber, nationality);
			if (DateTimeComparator.getDateOnlyInstance().compare(gccPerson.getDateOfBirth(), dob) == 0
					&& gccPerson.getGender().equalsIgnoreCase(gender)) {
				dto.setGCC(true);
			} else {
				dto.setGCC(false);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			dto.setGCC(false);
		}
		return dto;
	}

}
