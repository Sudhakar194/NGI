package bh.gov.cio.integration.crs.retrieve.family;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Family;
import bh.gov.cio.crs.model.person.IndMarriageDivorce;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.family.service.FamilyBasicSpecialInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.FamilyBasicSpecialInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(
		name = "FamilyBasicSpecialInfoService",
		targetNamespace = "http://service.family.retrieve.crs.integration.cio.gov.bh/")
//serviceName = "FamilyBasicSpecialInfoService",
public class FamilyBasicSpecialInfoServiceImpl implements
		FamilyBasicSpecialInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(FamilyBasicSpecialInfoServiceImpl.class);
	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getFamilyBasicSpecialInfo" })
	@WebMethod(operationName = "getFamilyBasicSpecialInfo")
	public FamilyBasicSpecialInfoDTO getFamilyBasicSpecialInfo(SecurityTagObject security,Integer cprNumber)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
			logger.debug("getFamilyBasicSpecialInfo(Integer) - start");
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted"));
		FamilyBasicSpecialInfoDTO familyBasicSpecialInfoDTO = null;
		try
		{
			final Family maritalStatus = getCrsService().getFamilyServiceRef()
					.getPersonMaritalStatus(cprNumber);
			final IndMarriageDivorce indMarriageDivorce = getCrsService()
					.getFamilyServiceRef()
					.getPersonLastActionDetails(cprNumber);

			if (logger.isDebugEnabled())
				logger.debug("getFamilyBasicSpecialInfo() -  : maritalStatus = "
						+ maritalStatus
						+ ", indMarriageDivorce = "
						+ indMarriageDivorce);
			final String marriageDivorceIndicator = indMarriageDivorce
					.getActionType();
			final String marriageDivorceDate = DateServiceImpl
					.formatDate(indMarriageDivorce.getMarriageDivorceDate());
			final Integer partenerCprNumber = indMarriageDivorce
					.getPartnerCprNumber();
			final String partenerFullName = indMarriageDivorce
					.getPartnerFullName();
			final String maritalStatusCode = maritalStatus
					.getMaritalStatusCode();
			String partenerCprNumberStr = "";
			if (partenerCprNumber != null)
				partenerCprNumberStr = partenerCprNumber + "";
			familyBasicSpecialInfoDTO = new FamilyBasicSpecialInfoDTO(
					maritalStatusCode, partenerCprNumberStr,
					marriageDivorceIndicator, marriageDivorceDate,
					partenerFullName);

			if (logger.isDebugEnabled())
				logger.debug("getFamilyBasicSpecialInfo(Integer) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getFamilyBasicInfo(Integer, Integer, Date) Error: "
						+ exception.getMessage());
			throw new ApplicationExceptionInfo(
					"Family Basic Details Not found", new ApplicationException(
							exception.getMessage()));
		}
		return familyBasicSpecialInfoDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
