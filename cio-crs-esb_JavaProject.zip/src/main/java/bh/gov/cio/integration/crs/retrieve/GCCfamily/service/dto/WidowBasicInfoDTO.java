package bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder =
{ "spouseDetail" })
public class WidowBasicInfoDTO
{
	private WidowDetailDTO[]	spouseDetail;

	public WidowBasicInfoDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public WidowBasicInfoDTO(WidowDetailDTO[] spouseDetail)
	{
		super();
		this.spouseDetail = spouseDetail;
	}

	@XmlElement(required = true)
	public WidowDetailDTO[] getSpouseDetail()
	{
		return spouseDetail;
	}

	public void setSpouseDetail(WidowDetailDTO[] spouseDetail)
	{
		this.spouseDetail = spouseDetail;
	}

}
