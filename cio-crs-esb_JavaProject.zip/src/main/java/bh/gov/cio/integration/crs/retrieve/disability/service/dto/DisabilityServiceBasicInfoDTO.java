package bh.gov.cio.integration.crs.retrieve.disability.service.dto;

public class DisabilityServiceBasicInfoDTO
{
	private Integer	cprNumber;
	private String	disabilityCode;
	private String	disabilityDate;
	private String	disabilityArName;
	private String	disabilityEnName;

	public DisabilityServiceBasicInfoDTO()
	{
		super();
	}

	public DisabilityServiceBasicInfoDTO(Integer cprNumber,
			String disabilityCode, String disabilityDate,
			String disabilityArName, String disabilityEnName)
	{
		super();
		this.cprNumber = cprNumber;
		this.disabilityCode = disabilityCode;
		this.disabilityDate = disabilityDate;
		this.disabilityArName = disabilityArName;
		this.disabilityEnName = disabilityEnName;
	}

	public Integer getCprNumber()
	{
		return cprNumber;
	}

	public String getDisabilityArName()
	{
		return disabilityArName;
	}

	public String getDisabilityCode()
	{
		return disabilityCode;
	}

	public String getDisabilityDate()
	{
		return disabilityDate;
	}

	public String getDisabilityEnName()
	{
		return disabilityEnName;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDisabilityArName(String disabilityArName)
	{
		this.disabilityArName = disabilityArName;
	}

	public void setDisabilityCode(String disabilityCode)
	{
		this.disabilityCode = disabilityCode;
	}

	public void setDisabilityDate(String disabilityDate)
	{
		this.disabilityDate = disabilityDate;
	}

	public void setDisabilityEnName(String disabilityEnName)
	{
		this.disabilityEnName = disabilityEnName;
	}

}
