package bh.gov.cio.integration.crs.retrieve.person.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.SWDPersonServiceSummaryDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "SWDPersonSummeryService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface SWDPersonSummeryServiceInterface
{
	@WebResult(name = "SWDPersonSummeryInformation")
	@WebMethod(operationName = "getSWDPersonSummeryDetails")
	SWDPersonServiceSummaryDTO getSWDPersonSummeryDetails(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;
}
