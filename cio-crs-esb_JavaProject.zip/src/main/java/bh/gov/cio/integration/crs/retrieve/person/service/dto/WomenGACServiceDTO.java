package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.List;

import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressServiceBasicInfoDTO;

public class WomenGACServiceDTO
{
	private java.lang.Integer applicantCprNumber;
	private String applicantFullArabicName;
	private String applicantFullEnglishName;
	private String applicantGender;
	private String applicantMaritalStatus;
	private String applicantEmploymentStatusCode;
	private String applicantDateOfBirth;
	private Integer applicantNoOfChildren;
	private List<AddressServiceBasicInfoDTO> applicantAddresses;

	// private Integer noOfCRs;
	// private Integer noOfOwnedProperties;
	// private Integer municipalityFees;
	// private Integer MunicipalityPercentage;
}
