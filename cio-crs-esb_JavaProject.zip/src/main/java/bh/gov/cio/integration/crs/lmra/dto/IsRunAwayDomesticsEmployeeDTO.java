package bh.gov.cio.integration.crs.lmra.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "RunAwayDomesticsEmployee", propOrder =
{  "employeeCprNumber","isRunAway" })
public class IsRunAwayDomesticsEmployeeDTO
{

	private String isRunAway;
	private Integer employeeCprNumber;


	public IsRunAwayDomesticsEmployeeDTO()
	{
		super();

	}


	public IsRunAwayDomesticsEmployeeDTO(String isRunAway,
			Integer employeeCprNumber) {
		super();
		this.isRunAway = isRunAway;
		this.employeeCprNumber = employeeCprNumber;
	}





	@XmlElement(name = "employeeCprNumber", required = true)
	public Integer getEmployeeCprNumber() {
		return employeeCprNumber;
	}


	public void setEmployeeCprNumber(Integer employeeCprNumber) {
		this.employeeCprNumber = employeeCprNumber;
	}


	@XmlElement(name = "isRunAway", required = true)
	public String getIsRunAway() {
		return isRunAway;
	}








	public void setIsRunAway(String isRunAway) {
		this.isRunAway = isRunAway;
	}








	




	

	
}
