package bh.gov.cio.integration.common;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HTTPServiceImpl 
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(HTTPServiceImpl.class);

	/* (non-Javadoc)
	 * @see bh.gov.cio.integration.cio.basic.HTTPServiceInterface#invokeURL(java.lang.String)
	 */
	public static String invokeURL(String url)
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("invokeURL(String) - start");
		}

		String responseBody = "";
		HttpClient httpclient = new DefaultHttpClient();
		HttpGet httpget = new HttpGet(url);

		if (logger.isDebugEnabled())
		{
			logger.debug("invokeURL(url = " + url + ") -  : responseBody = " + responseBody);
		}
		ResponseHandler<String> responseHandler = new BasicResponseHandler();
		try
		{
			responseBody = httpclient.execute(httpget, responseHandler);
		} catch (ClientProtocolException e)
		{
			logger.error("invokeURL(String)", e);


			logger.error("invokeURL(String)", e);
		} catch (IOException e)
		{
			logger.error("invokeURL(String)", e);

			logger.error("invokeURL(String)", e);
		} finally
		{
			httpclient.getConnectionManager().shutdown();
		}

		if (logger.isDebugEnabled())
		{
			logger.debug("invokeURL(String) - end");
		}
		return responseBody;
	}
}
