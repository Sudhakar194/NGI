package bh.gov.cio.integration.crs.retrieve.family;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.family.service.ChildrenBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.ChildrenBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.ChildrenDetailDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "ChildrenBasicInfoService", serviceName = "ChildrenBasicInfoService", targetNamespace = "http://service.family.retrieve.crs.integration.cio.gov.bh/")
public class ChildrenBasicInfoServiceImpl implements ChildrenBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(FamilyBasicSpecialInfoServiceImpl.class);
	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Override
	@Secured({ "ROLE_getAllChildrenBasicInfo" })
	@WebMethod(operationName = "getAllChildrenBasicInfo")
	public ChildrenBasicInfoDTO getAllChildrenBasicInfo(SecurityTagObject security, Integer cprNumber,
			Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("getFamilyBasicInfo(Integer, Integer, Date) - start");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber)) {
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate)) {
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		// if (validationUtil.isMilitaryCpr(cprNumber))
		// {
		// throw new ApplicationExceptionInfo("UNAUTHORIZED",
		// new ApplicationException("UNAUTHORIZED"));
		// }
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		ChildrenBasicInfoDTO childrenServiceBasicInfoDTO = null;
		ArrayList<ChildrenDetailDTO> childrenDetailDTO = null;
		try {
			final PersonService personService = getCrsService().getPersonServiceRef();
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final HashMap<Integer, List<PersonSummary>> hm = familyService.getPersonChildrenBySpouse(cprNumber);
			if (logger.isDebugEnabled()) {
				logger.debug("getPersonDetails() -  No Of Wives = " + hm);
			}
			final Collection<List<PersonSummary>> wivesList = hm.values();
			childrenDetailDTO = new ArrayList<ChildrenDetailDTO>();
			int currentChild = 0;
			for (final List<PersonSummary> list : wivesList) {
				final List<PersonSummary> childrenList = list;
				for (final PersonSummary personSummary : childrenList) {
					final PersonSummary childrenSummary = personSummary;

					final PersonBasicInfo childrenPersonBasicInfo = personService
							.getPersonBasicInfo(childrenSummary.getCprNumber());
					final PersonSummary childrenPersonSummary = personService
							.getPersonSummary(childrenSummary.getCprNumber());
					if (logger.isDebugEnabled()) {
						logger.debug("getPersonDetails() -  : childrenPersonSummary = " + childrenPersonSummary);
					}
					final boolean isBahraini = (childrenPersonSummary.getNationalityCountryCode().equals("499")
							|| childrenPersonSummary.getNationalityCountryCode().equals("900")) ? true : false;
					final boolean isNotDead = (childrenPersonSummary.getIoStatusCode().equals("1")) ? false : true;

					if (isNotDead) {
						childrenDetailDTO.add( new ChildrenDetailDTO(childrenPersonSummary.getCprNumber(),
								childrenPersonBasicInfo.getArabicName(), childrenPersonBasicInfo.getEnglishName(),
								childrenPersonSummary.getMaritalStatusCode(),
								childrenPersonSummary.getEmploymentStatusCode(),
								DateServiceImpl.formatDate(childrenPersonBasicInfo.getDateOfBirth()),
								childrenPersonBasicInfo.getGender(), childrenPersonSummary.isArab(),
								childrenPersonSummary.isGcc(), isBahraini));
					}

					currentChild++;

				}
			}
			childrenServiceBasicInfoDTO = new ChildrenBasicInfoDTO(childrenDetailDTO);

			if (logger.isDebugEnabled()) {
				logger.debug("getChildrenBasicInfo(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getChildrenBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Children Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return childrenServiceBasicInfoDTO;
	}

	@Override
	@Secured({ "ROLE_getAllChildrenBasicInfoByCPR" })
	@WebMethod(operationName = "getAllChildrenBasicInfoByCPR")
	public ChildrenBasicInfoDTO getAllChildrenBasicInfoByCPR(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {

		if (logger.isDebugEnabled()) {
			logger.debug("getAllChildrenBasicInfoByCPR(Integer) - start");
		}
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		ChildrenBasicInfoDTO childrenServiceBasicInfoDTO = null;
		ArrayList<ChildrenDetailDTO> childrenDetailDTO = null;
		try {
			final PersonService personService = getCrsService().getPersonServiceRef();
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final HashMap<Integer, List<PersonSummary>> hm = familyService.getPersonChildrenBySpouse(cprNumber);
			if (logger.isDebugEnabled()) {
				logger.debug("getPersonDetails() -  No Of Wives = " + hm);
			}
			final Collection<List<PersonSummary>> wivesList = hm.values();
			childrenDetailDTO = new ArrayList<ChildrenDetailDTO>();
			int currentChild = 0;
			for (final List<PersonSummary> list : wivesList) {
				final List<PersonSummary> childrenList = list;
				for (final PersonSummary personSummary : childrenList) {
					final PersonSummary childrenSummary = personSummary;

					final PersonBasicInfo childrenPersonBasicInfo = personService
							.getPersonBasicInfo(childrenSummary.getCprNumber());
					final PersonSummary childrenPersonSummary = personService
							.getPersonSummary(childrenSummary.getCprNumber());
					if (logger.isDebugEnabled()) {
						logger.debug("getPersonDetails() -  : childrenPersonSummary = " + childrenPersonSummary);
					}
					final boolean isBahraini = (childrenPersonSummary.getNationalityCountryCode().equals("499")
							|| childrenPersonSummary.getNationalityCountryCode().equals("900")) ? true : false;
					final boolean isNotDead = (childrenPersonSummary.getIoStatusCode().equals("1")) ? false : true;

					if (isNotDead) {
						childrenDetailDTO.add(new ChildrenDetailDTO(childrenPersonSummary.getCprNumber(),
								childrenPersonBasicInfo.getArabicName(), childrenPersonBasicInfo.getEnglishName(),
								childrenPersonSummary.getMaritalStatusCode(),
								childrenPersonSummary.getEmploymentStatusCode(),
								DateServiceImpl.formatDate(childrenPersonBasicInfo.getDateOfBirth()),
								childrenPersonBasicInfo.getGender(), childrenPersonSummary.isArab(),
								childrenPersonSummary.isGcc(), isBahraini));
					}

					currentChild++;

				}
			}
			childrenServiceBasicInfoDTO = new ChildrenBasicInfoDTO(childrenDetailDTO);

			if (logger.isDebugEnabled()) {
				logger.debug("getAllChildrenBasicInfoByCPR(Integer) - end");
			}
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getAllChildrenBasicInfoByCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Children Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return childrenServiceBasicInfoDTO;

	}

	@Override
	@Secured({ "ROLE_getChildrenBasicInfo" })
	@WebMethod(operationName = "getChildrenBasicInfo")
	public ChildrenBasicInfoDTO getChildrenBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber,
			Date cardExpiryDate) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("getFamilyBasicInfo(Integer, Integer, Date) - start");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber)) {
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate)) {
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		if (validationUtil.isMilitaryCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		}
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		ChildrenBasicInfoDTO childrenServiceBasicInfoDTO = null;
		ArrayList<ChildrenDetailDTO> childrenDetailDTO = null;
		try {
			final PersonService personService = getCrsService().getPersonServiceRef();
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final HashMap<Integer, List<PersonSummary>> hm = familyService.getPersonChildrenBySpouse(cprNumber);
			if (logger.isDebugEnabled()) {
				logger.debug("getPersonDetails() -  No Of Wives = " + hm);
			}
			final Collection<List<PersonSummary>> wivesList = hm.values();
			childrenDetailDTO = new ArrayList<ChildrenDetailDTO>();
			int currentChild = 0;
			for (final List<PersonSummary> list : wivesList) {
				final List<PersonSummary> childrenList = list;
				for (final PersonSummary personSummary : childrenList) {
					final PersonSummary childrenSummary = personSummary;

					final PersonBasicInfo childrenPersonBasicInfo = personService
							.getPersonBasicInfo(childrenSummary.getCprNumber());
					final PersonSummary childrenPersonSummary = personService
							.getPersonSummary(childrenSummary.getCprNumber());
					if (logger.isDebugEnabled()) {
						logger.debug("getPersonDetails() -  : childrenPersonSummary = " + childrenPersonSummary);
					}
					final boolean isBahraini = (childrenPersonSummary.getNationalityCountryCode().equals("499")
							|| childrenPersonSummary.getNationalityCountryCode().equals("900")) ? true : false;
					final boolean isNotDead = (childrenPersonSummary.getIoStatusCode().equals("1")) ? false : true;

					if (isNotDead) {
						childrenDetailDTO.add( new ChildrenDetailDTO(childrenPersonSummary.getCprNumber(),
								childrenPersonBasicInfo.getArabicName(), childrenPersonBasicInfo.getEnglishName(),
								childrenPersonSummary.getMaritalStatusCode(),
								childrenPersonSummary.getEmploymentStatusCode(),
								DateServiceImpl.formatDate(childrenPersonBasicInfo.getDateOfBirth()),
								childrenPersonBasicInfo.getGender(), childrenPersonSummary.isArab(),
								childrenPersonSummary.isGcc(), isBahraini));
					}

					currentChild++;

				}
			}
			childrenServiceBasicInfoDTO = new ChildrenBasicInfoDTO(childrenDetailDTO);

			if (logger.isDebugEnabled()) {
				logger.debug("getChildrenBasicInfo(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getChildrenBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Children Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return childrenServiceBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

}
