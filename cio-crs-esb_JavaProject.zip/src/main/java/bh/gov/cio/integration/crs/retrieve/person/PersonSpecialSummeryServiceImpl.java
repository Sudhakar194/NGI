package bh.gov.cio.integration.crs.retrieve.person;

import java.text.SimpleDateFormat;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.person.Smartcard;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonSpecialSummeryServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServiceSpecialSummaryDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(
		name = "PersonSpecialSummeryService",
		targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//serviceName = "PersonSpecialSummeryService",
public class PersonSpecialSummeryServiceImpl implements
		PersonSpecialSummeryServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(PersonSpecialSummeryServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonSpecialSummery" })
	@WebMethod(operationName = "ROLE_getPersonSpecialSummery")
	public PersonServiceSpecialSummaryDTO getPersonSpecialSummery(
			SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
			logger.debug("getPersonSpecialSummery(Integer) - start");
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted"));

		PersonServiceSpecialSummaryDTO personSpecialSummaryDTO = null;
		try
		{
			final PersonSummary personSummary = getCrsService()
					.getPersonServiceRef().getPersonSummary(cprNumber);
			final Smartcard smartcard = getCrsService()
					.getPersonServiceRef().getPersonLastSmartcard(cprNumber);
			
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String smartcardExpDate = "";
			if(smartcard !=null){
				
				
				logger.debug(""+smartcard.getExpiryDate());
				smartcardExpDate = 	sdf.format(smartcard.getExpiryDate());
				
			}
				
			personSpecialSummaryDTO = new PersonServiceSpecialSummaryDTO(
					personSummary.getCprNumber(),
					DateServiceImpl.formatDate(personSummary.getDateOfBirth()),
					personSummary.getDateOfBirthOld(),
					personSummary.getNationalityCountryCode(),
					personSummary.getBirthCountryCode(),
					DateServiceImpl.formatDate(personSummary.getDateOfDeath()),
					personSummary.getDeathCountryCode(),
					personSummary.getArabicFullName(),
					personSummary.getArabicFirstName(),
					personSummary.getArabicMiddleName1(),
					personSummary.getArabicMiddleName2(),
					personSummary.getArabicMiddleName3(),
					personSummary.getArabicMiddleName4(),
					personSummary.getArabicFamilyName(),
					personSummary.getEnglishFullName(),
					personSummary.getEnglishFirstName(),
					personSummary.getEnglishMiddleName1(),
					personSummary.getEnglishMiddleName2(),
					personSummary.getEnglishMiddleName3(),
					personSummary.getEnglishMiddleName4(),
					personSummary.getEnglishFamilyName(),
					personSummary.getGender(),
					personSummary.getSponsorIndicator(),
					personSummary.getEmployerIndicator(),
					personSummary.getIsStudent(),
					personSummary.getIsClearingAgent(),
					personSummary.getIsWatchlisted(),
					personSummary.getIsLostCard(),
					personSummary.getIsDeleted(),
					personSummary.getIsPrisoner(),
					personSummary.getIsSmartcard(),
					personSummary.getIsNationalityConfirmed(),
					personSummary.getContactPhone(),
					personSummary.getBirthPlaceArabic(),
					personSummary.getBirthPlaceEnglish(),
					personSummary.getFatherCprNumber(),
					personSummary.getMotherCprNumber(),
					personSummary.getSpouseCpr(),
					personSummary.getReligionCode(),
					personSummary.getLabourParticipationTypeCode(),
					personSummary.getLabourParticipationTypeArabicName(),
					personSummary.getLabourParticipationTypeEnglishName(),
					personSummary.getHighestLevelAchievedCode(),
					personSummary.getMaritalStatusCode(),
					personSummary.getEmploymentStatusCode(),
					personSummary.getIoStatusCode(),
					smartcardExpDate);

			if (logger.isDebugEnabled())
				logger.debug("getPersonSpecialSummery() -  : personSummaryDTO = "
						+ personSpecialSummaryDTO);
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonSpecialSummery(Integer, Integer, Date) Error: "
						+ exception.getMessage());
			throw new ApplicationExceptionInfo(
					"Person Special Details Not found",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isDebugEnabled())
			logger.debug("getPersonSpecialSummery(Integer) - end");
		return personSpecialSummaryDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
