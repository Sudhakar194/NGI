package bh.gov.cio.integration.gosi.update.employment.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "JobUpdateService", targetNamespace = "http://service.employment.update.gosi.integration.cio.gov.bh/")
public interface JobUpdateServiceInterface
{
	@WebResult(name = "isSuccessfullyUpdated")
	@WebMethod(operationName = "updateJobDetails")
	boolean updateJobDetails(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,

	@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "employerNumber") @XmlElement(required = true) Integer employerNumber, @WebParam(name = "occupationCode") @XmlElement(
					required = true) String occupationCode, @WebParam(name = "occupationType") @XmlElement(required = true) String occupationType,
			@WebParam(name = "jobStartDate") @XmlElement(required = true) Date jobStartDate, @WebParam(name = "jobEndDate") @XmlElement(
					required = false) Date jobEndDate, @WebParam(name = "employmentStatus") @XmlElement(required = true) String employmentStatus

	) throws ApplicationExceptionInfo;

}
