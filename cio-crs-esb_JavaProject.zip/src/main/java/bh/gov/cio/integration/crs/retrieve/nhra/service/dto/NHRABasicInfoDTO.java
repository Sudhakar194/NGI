package bh.gov.cio.integration.crs.retrieve.nhra.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "NHRABasicInfo", propOrder =
{		"personFullNameArabic","personFullNameEnglish"})
public class NHRABasicInfoDTO
{
	private String personFullNameArabic;
	private String personFullNameEnglish;


	public NHRABasicInfoDTO(String personFullNameArabic, String personFullNameEnglish) {
		super();
		this.personFullNameArabic = personFullNameArabic;
		this.personFullNameEnglish = personFullNameEnglish;
	}


	public NHRABasicInfoDTO()
	{
		super();
	}


	@XmlElement(name = "PersonFullNameArabic")
	public String getPersonFullNameArabic() {
		return personFullNameArabic;
	}

	public void setPersonFullNameArabic(String personFullNameArabic) {
		this.personFullNameArabic = personFullNameArabic;
	}



	@XmlElement(name = "PersonFullNameEnglish")
	public String getPersonFullNameEnglish() {
		return personFullNameEnglish;
	}



	public void setPersonFullNameEnglish(String personFullNameEnglish) {
		this.personFullNameEnglish = personFullNameEnglish;
	}


	@Override
	public String toString() {
		return "NHRABasicInfoDTO [personFullNameArabic=" + personFullNameArabic + ", personFullNameEnglish="
				+ personFullNameEnglish + "]";
	}
}
