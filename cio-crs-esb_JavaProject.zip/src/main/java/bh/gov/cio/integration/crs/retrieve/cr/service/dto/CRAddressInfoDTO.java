package bh.gov.cio.integration.crs.retrieve.cr.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "CRAddressDetails", propOrder =
{ "flatNumber", "buildingNumber", "nameAlphaEnglish", "roadNumber",
		"blockNumber"})

public class CRAddressInfoDTO {
	
	
	private String	flatNumber;
	private String	buildingNumber;
	private String	nameAlphaEnglish;
	private String	roadNumber;
	private String	blockNumber;
	
	
	
	
	public CRAddressInfoDTO() {
		super();
		
	}
	
	public CRAddressInfoDTO(String flatNumber, String buildingNumber,
			String nameAlphaEnglish, String roadNumber, String blockNumber) {
		super();

		if (flatNumber != null)
			setFlatNumber(flatNumber);
		else
			setFlatNumber("");
		
	
		if (buildingNumber != null)
			setBuildingNumber(buildingNumber);
		else
			setBuildingNumber("");
		
		if (nameAlphaEnglish != null)
			setNameAlphaEnglish(nameAlphaEnglish);
		else
			setNameAlphaEnglish("");
		
		if (roadNumber != null)
			setRoadNumber(roadNumber);
		else
			setRoadNumber("");

		if (blockNumber != null)
			setBlockNumber(blockNumber);
		else
			setBlockNumber("");
		

	}
	
	@XmlElement(name = "FlatNumber", required = true)
	public String getFlatNumber() {
		return flatNumber;
	}
	public void setFlatNumber(String flatNumber) {
		this.flatNumber = flatNumber;
	}
	@XmlElement(name = "BuildingNumber", required = true)
	public String getBuildingNumber() {
		return buildingNumber;
	}
	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}
	@XmlElement(name = "Alpha", required = true)
	public String getNameAlphaEnglish() {
		return nameAlphaEnglish;
	}
	public void setNameAlphaEnglish(String nameAlphaEnglish) {
		this.nameAlphaEnglish = nameAlphaEnglish;
	}
	
	@XmlElement(name = "RoadNumber", required = true)
	public String getRoadNumber() {
		return roadNumber;
	}
	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	
	@XmlElement(name = "BlockNumber", required = true)
	public String getBlockNumber() {
		return blockNumber;
	}
	public void setBlockNumber(String blockNumber) {
		this.blockNumber = blockNumber;
	}

	@Override
	public String toString() {
		return "CRAddressInfoDTO [flatNumber=" + flatNumber + ", buildingNumber=" + buildingNumber
				+ ", nameAlphaEnglish=" + nameAlphaEnglish + ", roadNumber=" + roadNumber + ", blockNumber="
				+ blockNumber + "]";
	}


	

}
