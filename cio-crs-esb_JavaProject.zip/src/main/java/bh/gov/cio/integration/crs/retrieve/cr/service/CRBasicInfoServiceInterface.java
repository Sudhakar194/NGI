package bh.gov.cio.integration.crs.retrieve.cr.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.gis.service.dto.CRBasicInfoWithAddressDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRAddressInfoDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CRBasicInfoService", targetNamespace = "http://service.cr.retrieve.crs.integration.cio.gov.bh/")
public interface CRBasicInfoServiceInterface
{
//for gis
	
	@WebResult(name = "CRInformation")
	@WebMethod(operationName = "getCRBasicInfo")
	CRServiceBasicInfoDTO getCRBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "crNumber") @XmlElement(required = true) Integer crNumber)
			throws ApplicationExceptionInfo;

	@WebResult(name = "CRAddressInformation")
	@WebMethod(operationName = "getCRAddressInfo")
	CRAddressInfoDTO getCRAddressInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security, @WebParam(
			name = "crNumber") @XmlElement(required = true) Integer crNumber) throws ApplicationExceptionInfo;

}
