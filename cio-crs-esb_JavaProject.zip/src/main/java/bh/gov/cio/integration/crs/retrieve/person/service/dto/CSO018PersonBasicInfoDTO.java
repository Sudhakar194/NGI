package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlType(name = "PersonServiceBasicInfo", propOrder = { "returnCode", "arabicFirstName", "arabicMiddleName1",
		"arabicMiddleName2", "arabicMiddleName3", "arabicMiddleName4", "arabicFamilyName", "englishFirstName",
		"englishMiddleName1", "englishMiddleName2", "englishMiddleName3", "englishMiddleName4", "englishFamilyName",
		"cprNumber", "gender", "passportNumber", "jobCode", "jobDescriptionAr", "jobDescriptionEn", "employerType",
		"ioStatus", "scIssueDate", "scExpiryDate", "employerNumber", "employerNameAr", "employerNameEn",
		"fullArabicName", "fullEnglishName" })

public class CSO018PersonBasicInfoDTO {
	private String returnCode;
	private String fullArabicName = "";
	private String arabicFirstName;
	private String arabicMiddleName1;
	private String arabicMiddleName2;
	private String arabicMiddleName3;
	private String arabicMiddleName4;
	private String arabicFamilyName;
	private String fullEnglishName = "";
	private String englishFirstName;
	private String englishMiddleName1;
	private String englishMiddleName2;
	private String englishMiddleName3;
	private String englishMiddleName4;
	private String englishFamilyName;
	private String cprNumber;
	private String gender;
	private String passportNumber;
	private String jobCode;
	private String jobDescriptionAr;
	private String jobDescriptionEn;
	private String employerType;
	private String employerNumber;
	private String employerNameAr;
	private String employerNameEn;
	private String ioStatus;
	private String scIssueDate;
	private String scExpiryDate;

	public CSO018PersonBasicInfoDTO() {
		super();
	}

	@XmlElement(name = "FullArabicName", required = true)
	public String getFullArabicName() {

		fullArabicName = "";

		String temp = "";

		if (arabicFirstName != null && !arabicFirstName.trim().equals("")) {
			temp = temp + arabicFirstName.trim() + " ";
		}
		if (arabicMiddleName1 != null && !arabicMiddleName1.trim().equals("")) {
			temp = temp + arabicMiddleName1.trim() + " ";
		}
		if (arabicMiddleName2 != null && !arabicMiddleName2.trim().equals("")) {
			temp = temp + arabicMiddleName2.trim() + " ";
		}
		if (arabicMiddleName3 != null && !arabicMiddleName3.trim().equals("")) {
			temp = temp + arabicMiddleName3.trim() + " ";
		}
		if (arabicMiddleName4 != null && !arabicMiddleName4.trim().equals("")) {
			temp = temp + arabicMiddleName4.trim() + " ";
		}
		if (arabicFamilyName != null && !arabicFamilyName.trim().equals("")) {
			temp = temp + arabicFamilyName.trim();
		}

		fullArabicName = temp;
		return fullArabicName;
	}

	public void setFullArabicName(String fullArabicName) {
		this.fullArabicName = fullArabicName;
	}

	@XmlElement(name = "FullEnglishName", required = true)
	public String getFullEnglishName() {

		fullEnglishName = "";

		if (englishFirstName != null && !englishFirstName.trim().equals("")) {
			fullEnglishName = fullEnglishName + englishFirstName.trim() + " ";
		}
		if (englishMiddleName1 != null && !englishMiddleName1.trim().equals("")) {
			fullEnglishName = fullEnglishName + englishMiddleName1.trim() + " ";
		}
		if (englishMiddleName2 != null && !englishMiddleName2.trim().equals("")) {
			fullEnglishName = fullEnglishName + englishMiddleName2.trim() + " ";
		}
		if (englishMiddleName3 != null && !englishMiddleName3.trim().equals("")) {
			fullEnglishName = fullEnglishName + englishMiddleName3.trim() + " ";
		}
		if (englishMiddleName4 != null && !englishMiddleName4.trim().equals("")) {
			fullEnglishName = fullEnglishName + englishMiddleName4.trim() + " ";
		}
		if (englishFamilyName != null && !englishFamilyName.equals("")) {
			fullEnglishName = fullEnglishName + englishFamilyName.trim();
		}

		return fullEnglishName;
	}

	public void setFullEnglishName(String fullEnglishName) {
		this.fullEnglishName = fullEnglishName;
	}

	@XmlElement(name = "CprNumber", required = true)
	public String getCprNumber() {
		if (cprNumber == null || cprNumber.equals(""))
			cprNumber = "";
		return cprNumber;
	}

	@XmlElement(name = "returnCode", required = true)
	public String getReturnCode() {

		if (returnCode == null || returnCode.equals(""))
			returnCode = "";
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	@XmlElement(name = "arabicFirstName", required = true)
	public String getArabicFirstName() {

		if (arabicFirstName == null || arabicFirstName.equals(""))
			arabicFirstName = "";
		return arabicFirstName;
	}

	public void setArabicFirstName(String arabicFirstName) {
		this.arabicFirstName = arabicFirstName;
	}

	@XmlElement(name = "arabicMiddleName1", required = true)
	public String getArabicMiddleName1() {
		if (arabicMiddleName1 == null || arabicMiddleName1.equals(""))
			arabicMiddleName1 = "";
		return arabicMiddleName1;
	}

	public void setArabicMiddleName1(String arabicMiddleName1) {
		this.arabicMiddleName1 = arabicMiddleName1;
	}

	@XmlElement(name = "arabicMiddleName2", required = true)
	public String getArabicMiddleName2() {
		if (arabicMiddleName2 == null || arabicMiddleName2.equals(""))
			arabicMiddleName2 = "";
		return arabicMiddleName2;
	}

	public void setArabicMiddleName2(String arabicMiddleName2) {
		if (arabicMiddleName2 == null || arabicMiddleName2.equals(""))
			arabicMiddleName2 = "";
		this.arabicMiddleName2 = arabicMiddleName2;
	}

	@XmlElement(name = "arabicMiddleName3", required = true)
	public String getArabicMiddleName3() {
		if (arabicMiddleName3 == null || arabicMiddleName3.equals(""))
			arabicMiddleName3 = "";
		return arabicMiddleName3;
	}

	public void setArabicMiddleName3(String arabicMiddleName3) {
		this.arabicMiddleName3 = arabicMiddleName3;
	}

	@XmlElement(name = "arabicMiddleName4", required = true)
	public String getArabicMiddleName4() {
		if (arabicMiddleName4 == null || arabicMiddleName4.equals(""))
			arabicMiddleName4 = "";
		return arabicMiddleName4;
	}

	public void setArabicMiddleName4(String arabicMiddleName4) {
		this.arabicMiddleName4 = arabicMiddleName4;
	}

	@XmlElement(name = "arabicFamilyName", required = true)
	public String getArabicFamilyName() {
		if (arabicFamilyName == null || arabicFamilyName.equals(""))
			arabicFamilyName = "";
		return arabicFamilyName;
	}

	public void setArabicFamilyName(String arabicFamilyName) {
		this.arabicFamilyName = arabicFamilyName;
	}

	@XmlElement(name = "englishFirstName", required = true)
	public String getEnglishFirstName() {
		if (englishFirstName == null || englishFirstName.equals(""))
			englishFirstName = "";
		return englishFirstName;
	}

	public void setEnglishFirstName(String englishFirstName) {
		this.englishFirstName = englishFirstName;
	}

	@XmlElement(name = "englishMiddleName1", required = true)
	public String getEnglishMiddleName1() {
		if (englishMiddleName1 == null || englishMiddleName1.equals(""))
			englishMiddleName1 = "";
		return englishMiddleName1;
	}

	public void setEnglishMiddleName1(String englishMiddleName1) {
		this.englishMiddleName1 = englishMiddleName1;
	}

	@XmlElement(name = "englishMiddleName2", required = true)
	public String getEnglishMiddleName2() {
		if (englishMiddleName2 == null || englishMiddleName2.equals(""))
			englishMiddleName2 = "";
		return englishMiddleName2;
	}

	public void setEnglishMiddleName2(String englishMiddleName2) {
		this.englishMiddleName2 = englishMiddleName2;
	}

	@XmlElement(name = "englishMiddleName3", required = true)
	public String getEnglishMiddleName3() {
		if (englishMiddleName3 == null || englishMiddleName3.equals(""))
			englishMiddleName3 = "";
		return englishMiddleName3;
	}

	public void setEnglishMiddleName3(String englishMiddleName3) {
		this.englishMiddleName3 = englishMiddleName3;
	}

	@XmlElement(name = "englishMiddleName4", required = true)
	public String getEnglishMiddleName4() {
		if (englishMiddleName4 == null || englishMiddleName4.equals(""))
			englishMiddleName4 = "";
		return englishMiddleName4;
	}

	public void setEnglishMiddleName4(String englishMiddleName4) {
		this.englishMiddleName4 = englishMiddleName4;
	}

	@XmlElement(name = "englishFamilyName", required = true)
	public String getEnglishFamilyName() {
		if (englishFamilyName == null || englishFamilyName.equals(""))
			englishFamilyName = "";
		return englishFamilyName;
	}

	public void setEnglishFamilyName(String englishFamilyName) {
		this.englishFamilyName = englishFamilyName;
	}

	@XmlElement(name = "gender", required = true)
	public String getGender() {
		if (gender == null || gender.equals(""))
			gender = "";
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@XmlElement(name = "passportNumber", required = true)
	public String getPassportNumber() {
		if (passportNumber == null || passportNumber.equals(""))
			passportNumber = "";
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	@XmlElement(name = "jobCode", required = true)
	public String getJobCode() {
		if (jobCode == null || jobCode.equals(""))
			jobCode = "";
		return jobCode;
	}

	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}

	@XmlElement(name = "jobDescriptionAr", required = true)
	public String getJobDescriptionAr() {
		if (jobDescriptionAr == null || jobDescriptionAr.equals(""))
			jobDescriptionAr = "";
		return jobDescriptionAr;
	}

	public void setJobDescriptionAr(String jobDescriptionAr) {
		this.jobDescriptionAr = jobDescriptionAr;
	}

	@XmlElement(name = "jobDescriptionEn", required = true)
	public String getJobDescriptionEn() {
		if (jobDescriptionEn == null || jobDescriptionEn.equals(""))
			jobDescriptionEn = "";
		return jobDescriptionEn;
	}

	public void setJobDescriptionEn(String jobDescriptionEn) {
		this.jobDescriptionEn = jobDescriptionEn;
	}

	@XmlElement(name = "employerType", required = true)
	public String getEmployerType() {
		if (employerType == null || employerType.equals(""))
			employerType = "";
		return employerType;
	}

	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	@XmlElement(name = "ioStatus", required = true)
	public String getIoStatus() {
		if (ioStatus == null || ioStatus.equals(""))
			ioStatus = "";
		return ioStatus;
	}

	public void setIoStatus(String ioStatus) {
		this.ioStatus = ioStatus;
	}

	@XmlElement(name = "scIssueDate", required = true)
	public String getScIssueDate() {
		if (scIssueDate == null || scIssueDate.equals(""))
			scIssueDate = "";
		return scIssueDate;
	}

	public void setScIssueDate(String scIssueDate) {
		this.scIssueDate = scIssueDate;
	}

	@XmlElement(name = "scExpiryDate", required = true)
	public String getScExpiryDate() {
		if (scExpiryDate == null || scExpiryDate.equals(""))
			scExpiryDate = "";
		return scExpiryDate;
	}

	@XmlElement(name = "employerNameAr", required = true)
	public String getEmployerNameAr() {
		if (employerNameAr == null || employerNameAr.equals(""))
			employerNameAr = "";
		return employerNameAr;
	}

	public void setEmployerNameAr(String employerNameAr) {
		this.employerNameAr = employerNameAr;
	}

	public void setScExpiryDate(String scExpiryDate) {
		this.scExpiryDate = scExpiryDate;
	}

	@XmlElement(name = "employerNameEn", required = true)
	public String getEmployerNameEn() {
		if (employerNameEn == null || employerNameEn.equals(""))
			employerNameEn = "";
		return employerNameEn;
	}

	public void setEmployerNameEn(String employerNameEn) {
		this.employerNameEn = employerNameEn;
	}

	public void setCprNumber(String cprNumber) {
		this.cprNumber = cprNumber;
	}

	@XmlElement(name = "employerNumber", required = true)
	public String getEmployerNumber() {
		return employerNumber;
	}

	public void setEmployerNumber(String employerNumber) {
		this.employerNumber = employerNumber;
	}

}
