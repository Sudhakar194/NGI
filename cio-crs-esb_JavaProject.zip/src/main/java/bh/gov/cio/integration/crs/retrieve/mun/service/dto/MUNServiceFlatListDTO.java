package bh.gov.cio.integration.crs.retrieve.mun.service.dto;

import java.io.Serializable;
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;

@XmlType(name = "MUNFlatInformatoin", propOrder = { "flatsNumber" })
public class MUNServiceFlatListDTO implements Serializable, CommonTypes {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3364963642739242914L;

	private ArrayList<Integer> flatsNumber;

	public MUNServiceFlatListDTO() {
		super();
	}

	public MUNServiceFlatListDTO(ArrayList<Integer> flatsNumber) {
		super();
		this.flatsNumber = flatsNumber;
	}

	public ArrayList<Integer> getFlatsNumber() {
		return flatsNumber;
	}

	public void setFlatsNumber(ArrayList<Integer> flatsNumber) {
		this.flatsNumber = flatsNumber;
	}

}
