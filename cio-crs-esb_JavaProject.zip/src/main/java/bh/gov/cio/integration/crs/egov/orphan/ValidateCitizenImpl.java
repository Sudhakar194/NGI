package bh.gov.cio.integration.crs.egov.orphan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.orphan.service.ValidateCitizen;
import bh.gov.cio.integration.crs.egov.orphan.service.dto.OrphanChildrensDetailsDTO;
import bh.gov.cio.integration.crs.egov.orphan.service.dto.OrphanServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "ValidateCitizenService", targetNamespace = "http://service.orphan.egov.crs.integration.cio.gov.bh/")
public class ValidateCitizenImpl implements ValidateCitizen {

	private static final Logger logger = LoggerFactory.getLogger(ValidateCitizenImpl.class);

	@Autowired
	private ValidationServiceImpl			validationService;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@Override
	@Secured({ "ROLE_checkCPRBlockExpiry" })
	@WebMethod(operationName = "checkCPRBlockExpiry")
	public boolean checkCPRBlockExpiry(SecurityTagObject security, String idNumber, String cardCountry,
			Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo {
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "001"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "002"));
		}
		if (!validationService.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number", "003"));

		// Validate Card Expiry Only For Bahraini
		if (cardCountry == null || "".equals(cardCountry.trim()) || cardCountry.equalsIgnoreCase("499")) {
			if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date", "004"));
		}
		PersonService ps = crsService.getPersonServiceRef();
		PersonBasicInfo pbi;
		boolean isExpired = false;
		boolean isDead = false;
		try {

			pbi = ps.getPersonBasicInfo(cprNumber);

		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("RetrieveEmploymentBasicDetails(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Retrieving Data",
					new ApplicationException("Error Retrieving Data From Backend", "005"));
		}

		if (!pbi.getIsActive().equalsIgnoreCase("T")) {
			throw new ApplicationExceptionInfo("CPR Number Not Active",
					new ApplicationException("CPR Number Not Active", "006"));
		}

		if (isDead) {
			throw new ApplicationExceptionInfo("Person is Dead", new ApplicationException("Person is Dead", "007"));
		}

		try {
			Date cardExpiry = validationService.getCPRNumberExpiry(cprNumber);
			isExpired = cardExpiry.before(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (isExpired) {
			throw new ApplicationExceptionInfo("Person Smartcard Expired",
					new ApplicationException("Person Smartcard Expired", "008"));
		}
		return true;
	}

	@Override
	@Secured({ "ROLE_checkCPR" })
	@WebMethod(operationName = "checkCPR")
	public boolean checkCPR(SecurityTagObject security, String idNumber, String cardCountry)
			throws ApplicationExceptionInfo {
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "001"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "002"));
		}
		PersonService ps = crsService.getPersonServiceRef();
		PersonBasicInfo pbi;
		boolean isExpired = false;
		boolean isDead = false;
		try {

			pbi = ps.getPersonBasicInfo(cprNumber);

		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("RetrieveEmploymentBasicDetails(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Retrieving Data",
					new ApplicationException("Error Retrieving Data From Backend", "003"));
		}

		if (!pbi.getIsActive().equalsIgnoreCase("T")) {
			throw new ApplicationExceptionInfo("CPR Number Not Active",
					new ApplicationException("CPR Number Not Active", "004"));
		}

		if (isDead) {
			throw new ApplicationExceptionInfo("Person is Dead", new ApplicationException("Person is Dead", "005"));
		}

		try {
			Date cardExpiry = validationService.getCPRNumberExpiry(cprNumber);
			isExpired = cardExpiry.before(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (isExpired) {
			throw new ApplicationExceptionInfo("Person Smartcard Expired",
					new ApplicationException("Person Smartcard Expired", "007"));
		}
		return true;
	}

	@Override
	@Secured({ "ROLE_getOrphanBasicInfoByMotherCPR" })
	@WebMethod(operationName = "getOrphanBasicInfoByMotherCPR")
	public OrphanServiceBasicInfoDTO getOrphanBasicInfoByMotherCPR(SecurityTagObject security,
			String eKeyMotherIDNumber, String motherCardCountry, String fatherIDNumber, String fatherCardCountry,
			String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp) throws ApplicationExceptionInfo {
//make optional eKey for testing only
		if (!eKeyServiceID.equalsIgnoreCase("test")) {
			if (!validationService.checkeKeyResponse(eKeyMotherIDNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp)) {
				throw new ApplicationExceptionInfo("Error in retrieving data...",
						new ApplicationException("Authentication Failed.", "010"));
			}
		}

		OrphanServiceBasicInfoDTO orphanServiceBasicInfoDTO = null;

		ArrayList<OrphanChildrensDetailsDTO> orphanChildrensDetailsDTO = new ArrayList<OrphanChildrensDetailsDTO>();

		Integer fatherCPRNumber = 0;
		try {
			fatherCPRNumber = validationService.getGCCCpr(fatherIDNumber, fatherCardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Father Details Not found",
					new ApplicationException("Father Details Not found", "001"));
		}
		Integer motherCPRNumber = 0;
		try {
			motherCPRNumber = validationService.getGCCCpr(eKeyMotherIDNumber, motherCardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Mother  Details Not found",
					new ApplicationException("Mother  Details Not found", "002"));
		}
		if (validationService.isDeletedCpr(fatherCPRNumber)) {
			throw new ApplicationExceptionInfo("Father Details Not found",
					new ApplicationException("Father Details Not found", "001"));
		}
		if (validationService.isDeletedCpr(motherCPRNumber)) {
			throw new ApplicationExceptionInfo("Mother  Details Not found",
					new ApplicationException("Mother  Details Not found", "002"));
		}

		final PersonService personService = crsService.getPersonServiceRef();
		final FamilyService familyService = crsService.getFamilyServiceRef();
		PersonBasicInfo pbiFa = null;
		PersonSummary psiFa = null;
		PersonBasicInfo pbiMo = null;
		List<PersonSummary> children = null;
		List<Marriage> marrieges = null;
		try {

			pbiFa = personService.getPersonBasicInfo(fatherCPRNumber);
			psiFa = personService.getPersonSummary(fatherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getOrphanBasicInfoByMotherCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Father Details Not found",
					new ApplicationException("Father Details Not found", "001"));
		}
		if (pbiFa.getGender() != null && !pbiFa.getGender().equalsIgnoreCase("M"))
			throw new ApplicationExceptionInfo("Fault Occurred While Retrieving Father Details",
					new ApplicationException("Fault Occurred While Retrieving Father Details", "003"));
		try {

			pbiMo = personService.getPersonBasicInfo(motherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getOrphanBasicInfoByMotherCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Mother Details Not found",
					new ApplicationException("Mother Details Not found", "002"));
		}
		if (pbiMo.getGender() != null && !pbiMo.getGender().equalsIgnoreCase("F"))
			throw new ApplicationExceptionInfo("Fault Occurred While Retrieving mother Details",
					new ApplicationException("Fault Occurred While Retrieving mother Details", "004"));
		try {
			children = familyService.getCoupleChildren(fatherCPRNumber, motherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getOrphanBasicInfoByMotherCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Fault Occured While Retreiving Children Details",
					new ApplicationException("Fault occurred While Retrieving Children Details", "006"));
		}
		try {
			marrieges = familyService.getPersonMarriageDivorceList(fatherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getOrphanBasicInfoByMotherCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Fault Occured While Retreiving Marriage Details",
					new ApplicationException("Fault occurred While Retrieving Marriage Details", "007"));
		}

		boolean isFatherNotDead = psiFa.getDateOfDeath() != null ? false : true;

		if (isFatherNotDead) {
			throw new ApplicationExceptionInfo("Fault Occurred While Retrieving Father Details",
					new ApplicationException("Fault Occurred While Retrieving Father Details", "008"));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getOrphanBasicInfoByMotherCPR() -  No Of children = " + children);
		}
		orphanChildrensDetailsDTO = new ArrayList<OrphanChildrensDetailsDTO>();
		boolean isLastActionMarried = false;
		boolean isWifeMarriedAfter = true;
		boolean relationFound = false;
		ArrayList<Date> marriageDates = new ArrayList<Date>();
		Date currentPartenerMarriageDate = null;
		if (marrieges != null) {
			for (Marriage marriage : marrieges) {
				marriageDates.add(marriage.getMarriageDivorceAsDate());
				if (marriage.getPartnerCprNumber().equals(motherCPRNumber)) {
					relationFound = true;
					currentPartenerMarriageDate = marriage.getMarriageDivorceAsDate();
					if (marriage.getLastActionWithPartner().equalsIgnoreCase("MARRIAGE")) {

						isLastActionMarried = true;
					}
				}
			}
		} else {
			throw new ApplicationExceptionInfo("Fault occurred While Retrieving Marriage Details",
					new ApplicationException("Fault occurred While Retrieving Marriage Details", "007"));
		}
		Date lastMarriageDate = Collections.max(marriageDates);
		if ((lastMarriageDate != null) && (currentPartenerMarriageDate != null)
				&& (lastMarriageDate.equals(currentPartenerMarriageDate))) {
			isWifeMarriedAfter = false;
		}
		if (!relationFound)
			throw new ApplicationExceptionInfo("Fault occurred While Retrieving Marriage Details",
					new ApplicationException("Fault occurred While Retrieving Marriage Details", "007"));

		for (PersonSummary personSummary : children) {
			PersonSummary childrenSummary = personSummary;
			PersonBasicInfo childrenPersonBasicInfo = null;
			PersonSummary childrenPersonSummary = null;
			try {
				childrenPersonBasicInfo = personService.getPersonBasicInfo(childrenSummary.getCprNumber());
				childrenPersonSummary = personService.getPersonSummary(childrenSummary.getCprNumber());
			} catch (final Exception exception) {
				exception.printStackTrace();
				if (logger.isDebugEnabled()) {
					logger.error("getOrphanBasicInfoByMotherCPR(Integer) Error: " + exception.getMessage());
				}
				throw new ApplicationExceptionInfo("Fault occurred While Retrieving Marriage Details",
						new ApplicationException("Fault occurred While Retrieving Children Details", "009"));
			}

			if (logger.isDebugEnabled()) {
				logger.debug("getOrphanBasicInfoByMotherCPR() -  : childrenPersonSummary = " + childrenPersonSummary);
			}
			final boolean isNotDead = (childrenPersonSummary.getIoStatusCode().equals("1")) ? false : true;
			final boolean isAgeLess24 = (childrenPersonSummary.getAge() < 24);
			final boolean isNotMarried = (!childrenPersonSummary.getMaritalStatusCode().equalsIgnoreCase("002"));
			if (isNotDead && isAgeLess24 && isNotMarried) {
				orphanChildrensDetailsDTO.add(new OrphanChildrensDetailsDTO(childrenPersonSummary.getCprNumber() + "",
						childrenPersonBasicInfo.getArabicName(), childrenPersonBasicInfo.getEnglishName(),
						childrenPersonBasicInfo.getAge() <= 18));
			}
		}
		orphanServiceBasicInfoDTO = new OrphanServiceBasicInfoDTO(pbiMo.getArabicName(), pbiMo.getEnglishName(),
				orphanChildrensDetailsDTO, isLastActionMarried, isWifeMarriedAfter);
		if (logger.isDebugEnabled()) {
			logger.debug("getOrphanBasicInfoByMotherCPR(Integer) - end");
		}

		return orphanServiceBasicInfoDTO;
	}

}
