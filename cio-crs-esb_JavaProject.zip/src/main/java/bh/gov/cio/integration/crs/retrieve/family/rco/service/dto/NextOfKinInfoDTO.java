package bh.gov.cio.integration.crs.retrieve.family.rco.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "NextOfKinInfoDTO", propOrder = { "arabicName", "englishName", "isAlive", "flatNumber", "roadNumber",
		"blockNumber", "areaName", "bldgNumber","bldgAlphaArabic","bldgAlphaEnglish" })
public class NextOfKinInfoDTO {
	String arabicName, englishName;
	boolean isAlive;
	String flatNumber, roadNumber, blockNumber, areaName, bldgNumber,bldgAlphaArabic,bldgAlphaEnglish;

	public NextOfKinInfoDTO() {
		super();
	}


	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public boolean getIsAlive() {
		return isAlive;
	}

	public void setIsAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	public String getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(String flatNumber) {
		this.flatNumber = flatNumber;
	}

	public String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public String getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(String blockNumber) {
		this.blockNumber = blockNumber;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getBldgNumber() {
		return bldgNumber;
	}

	public void setBldgNumber(String bldgNumber) {
		this.bldgNumber = bldgNumber;
	}


	public NextOfKinInfoDTO(String arabicName, String englishName, boolean isAlive, String flatNumber,
			String roadNumber, String blockNumber, String areaName, String bldgNumber, String bldgAlphaArabic,
			String bldgAlphaEnglish) {
		super();
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.isAlive = isAlive;
		this.flatNumber = flatNumber;
		this.roadNumber = roadNumber;
		this.blockNumber = blockNumber;
		this.areaName = areaName;
		this.bldgNumber = bldgNumber;
		this.bldgAlphaArabic = bldgAlphaArabic;
		this.bldgAlphaEnglish = bldgAlphaEnglish;
	}


	public String getBldgAlphaArabic() {
		return bldgAlphaArabic;
	}


	public void setBldgAlphaArabic(String bldgAlphaArabic) {
		this.bldgAlphaArabic = bldgAlphaArabic;
	}


	public String getBldgAlphaEnglish() {
		return bldgAlphaEnglish;
	}


	public void setBldgAlphaEnglish(String bldgAlphaEnglish) {
		this.bldgAlphaEnglish = bldgAlphaEnglish;
	}
}
