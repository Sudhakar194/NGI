package bh.gov.cio.integration.crs.update.family;

import java.io.IOException;
import java.io.Writer;
import java.net.UnknownHostException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import bh.gov.cio.crs.model.person.IndMarriageDivorce;
import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.util.exception.ApplicationException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.update.family.service.UpdateDivorceServiceInterface;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

@Controller
public class UpdateDivorceServiceImpl implements UpdateDivorceServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(UpdateDivorceServiceImpl.class);

	private final String userLastUpdate = "MOJ";
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	@Autowired
	private ValidationServiceImpl validationUtil;

	@Override
	@RequestMapping("/service/deleteDivorce.service")
	@ResponseBody
	@Secured({ "ROLE_deleteDivorce" })
	public String deleteDivorce(@RequestParam(value = "husbandCPR", required = true) Integer husbandCPR,
			@RequestParam(value = "wifeCPR", required = true) Integer wifeCPR,
			@RequestParam(value = "divorceDate", required = true) String divorceDate)
			throws ApplicationExceptionInfo, UnknownHostException, ApplicationException, BusinessException {
		int isSuccess = -1;
		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorce(Integer husbandCPR = " + husbandCPR + ", Integer wifeCPR = " + wifeCPR
					+ ", String divorceDate = " + divorceDate + ")");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorce(Integer, Integer, String) - start");
		}

		if (((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0)))
				&& ((validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0)))) {
			isSuccess = 3;
		}

		if (((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0))) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if (((validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0))) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if (((validationUtil.isValidCpr(husbandCPR) == true) || (husbandCPR.equals(0)))
				&& ((validationUtil.isValidCpr(wifeCPR) == true) || (wifeCPR.equals(0)))) {
			getCrsService().getFamilyServiceRef().deleteDivorce(husbandCPR, wifeCPR,
					DateServiceImpl.formatDate(divorceDate));
			isSuccess = 0;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorce(Integer, Integer, String) - end");
			logger.debug("deleteDivorce() -  : isSuccess = " + isSuccess);
		}
		return isSuccess + "";

	}

	@Override
	@RequestMapping("/service/deleteDivorceByID.service")
	@ResponseBody
	@Secured({ "ROLE_deleteDivorce" })
	public String deleteDivorce(@RequestParam(value = "husbandID", required = true) String husbandID,
			@RequestParam(value = "husbandNationalityCode", required = true) String husbandNationalityCode,
			@RequestParam(value = "wifeID", required = true) String wifeID,
			@RequestParam(value = "wifeNationalityCode", required = true) String wifeNationalityCode,
			@RequestParam(value = "divorceDate", required = true) String divorceDate)
			throws ApplicationExceptionInfo, UnknownHostException, ApplicationException, BusinessException {
		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorceByID(String, String, String, String, String) - start");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorce(String husbandID = " + husbandID + ", String husbandNationalityCode = "
					+ husbandNationalityCode + ", String wifeID = " + wifeID + ", String wifeNationalityCode = "
					+ wifeNationalityCode + ", String divorceDate = " + divorceDate + ")");
		}

		int isSuccess = -1;

		// 411 UNITED ARAB EMIRATES
		// 430 KUWAIT
		// 436 OMAN
		// 440 QATAR
		// 441 SAUDI ARABIA
		// 499 KINGDOM OF BAHRAIN
		// 900 NO NATIONALITY
		// 930 RESIDENT OF KUWAIT
		// 940 RESIDENT OF QATAR

		Integer husbandCPR = -1, wifeCPR = -1;
		// retrieve the CPR
		// if (husbandNationalityCode.equalsIgnoreCase("411") ||
		// husbandNationalityCode.equalsIgnoreCase("430")
		// || husbandNationalityCode.equalsIgnoreCase("436") ||
		// husbandNationalityCode.equalsIgnoreCase("440")
		// || husbandNationalityCode.equalsIgnoreCase("930") ||
		// husbandNationalityCode.equalsIgnoreCase("441")
		// || husbandNationalityCode.equalsIgnoreCase("940"))
		// {
		husbandCPR = validationUtil.getGCCCpr(husbandID, husbandNationalityCode);
		// }
		// else
		// {
		// try
		// {
		// husbandCPR = Integer.parseInt(husbandID);
		// }
		// catch (Exception exception)
		// {
		// exception.printStackTrace();
		// }
		// }
		// if (wifeNationalityCode.equalsIgnoreCase("411") ||
		// wifeNationalityCode.equalsIgnoreCase("430") ||
		// wifeNationalityCode.equalsIgnoreCase("436")
		// || wifeNationalityCode.equalsIgnoreCase("440") ||
		// wifeNationalityCode.equalsIgnoreCase("930")
		// || wifeNationalityCode.equalsIgnoreCase("441") ||
		// wifeNationalityCode.equalsIgnoreCase("940"))
		// {
		wifeCPR = validationUtil.getGCCCpr(wifeID, wifeNationalityCode);
		// }
		// else
		// {
		// try
		// {
		// wifeCPR = Integer.parseInt(wifeID);
		// }
		// catch (Exception exception)
		// {
		// exception.printStackTrace();
		// }
		// }

		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorceByID() -  : " + " validationUtil.isValidCpr(husbandCPR) = "
					+ validationUtil.isValidCpr(husbandCPR) + ",validationUtil.isValidCpr(wifeCPR) = "
					+ validationUtil.isValidCpr(wifeCPR));
		}

		if (((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0)))
				&& ((validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0)))) {
			isSuccess = 3;
		}

		if (((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0))) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if (((validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0))) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if (((validationUtil.isValidCpr(husbandCPR) == true) || (husbandCPR.equals(0)))
				&& ((validationUtil.isValidCpr(wifeCPR) == true) || (wifeCPR.equals(0)))) {
			getCrsService().getFamilyServiceRef().deleteDivorce(husbandCPR, wifeCPR,
					DateServiceImpl.formatDate(divorceDate));
			isSuccess = 0;
		}
		String returnString = isSuccess + "";
		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorce() -  : returnString = " + returnString);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("deleteDivorce(String, String, String, String, String) - end");
		}
		return returnString;
	}

	public CRSServicesProviderServiceImpl getCrsService() {
		if (logger.isDebugEnabled()) {
			logger.debug("getCrsService() - start");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getCrsService() - end");
		}
		return crsService;
	}

	@Override
	@RequestMapping("/service/getDivorceDates.service")
	@ResponseBody
	@Secured({ "ROLE_getDivorceDates" })
	public String getDivorceDates(@RequestParam(value = "CPRNumber", required = true) Integer CPRNumber)
			throws ApplicationExceptionInfo, UnknownHostException, ApplicationException, BusinessException {
		int isSuccess = -1;
		String dates = "";
		if (logger.isDebugEnabled()) {
			logger.debug("getDivorceDates(Integer CPRNumber = " + CPRNumber);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getDivorceDates(Integer, Integer) - start");
		}

		if ((validationUtil.isValidCpr(CPRNumber) != true) && (!CPRNumber.equals(0))) {
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(CPRNumber) == true) || CPRNumber.equals(0)) {
			FamilyService familyService = getCrsService().getFamilyServiceRef();
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(CPRNumber);
			if (hm != null) {
				for (final Marriage marriageDivorce : hm) {
					final Marriage spouse = marriageDivorce;
					List<IndMarriageDivorce> ind = spouse.getIndMarriageDivorceList();

					if (ind != null) {
						for (final IndMarriageDivorce indMarriageDivorce : ind) {
							if (indMarriageDivorce.getActionType().equalsIgnoreCase("DIVORCE")) {
								if (dates == "") {
									dates = indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								} else {
									dates = dates + ";" + indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								}

							}
						}

					}
				}
			} else {
				logger.debug("hm = null ");

			}
			isSuccess = 0;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getDivorceDates(Integer, Integer) - end");
			logger.debug("getDivorceDates() -  : isSuccess = " + isSuccess);
		}
		return isSuccess != 0 ? isSuccess + "" : (dates != "" ? dates : "0");

	}

	@Override
	@RequestMapping("/service/getDivorceDatesByID.service")
	@ResponseBody
	@Secured({ "ROLE_getDivorceDates" })
	public String getDivorceDates(@RequestParam(value = "IDNumber", required = true) String IDNumber,
			@RequestParam(value = "nationalityCode", required = true) String nationalityCode)
			throws ApplicationExceptionInfo, UnknownHostException, ApplicationException, BusinessException {
		if (logger.isDebugEnabled()) {
			logger.debug("getDivorceDates(IDNumber = " + IDNumber + ", nationalityCode = " + nationalityCode + ")");

			logger.debug("getDivorceDates(String, String) - start");
		}

		int isSuccess = -1;
		String dates = "";

		// 411 UNITED ARAB EMIRATES
		// 430 KUWAIT
		// 436 OMAN
		// 440 QATAR
		// 441 SAUDI ARABIA
		// 499 KINGDOM OF BAHRAIN
		// 900 NO NATIONALITY
		// 930 RESIDENT OF KUWAIT
		// 940 RESIDENT OF QATAR

		Integer CPRNumber = -1;
		// retrieve the CPR
		// if (nationalityCode.equalsIgnoreCase("411") ||
		// nationalityCode.equalsIgnoreCase("430") ||
		// nationalityCode.equalsIgnoreCase("436")
		// || nationalityCode.equalsIgnoreCase("440") ||
		// nationalityCode.equalsIgnoreCase("930") ||
		// nationalityCode.equalsIgnoreCase("441")
		// || nationalityCode.equalsIgnoreCase("940"))
		// {
		CPRNumber = validationUtil.getGCCCpr(IDNumber, nationalityCode);
		// }
		// else
		// {
		// try
		// {
		// CPRNumber = Integer.parseInt(IDNumber);
		// }
		// catch (Exception exception)
		// {
		// exception.printStackTrace();
		// }
		// }
		if ((validationUtil.isValidCpr(CPRNumber) != true) && (!CPRNumber.equals(0))) {
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(CPRNumber) == true) || CPRNumber.equals(0)) {
			FamilyService familyService = getCrsService().getFamilyServiceRef();
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(CPRNumber);
			if (hm != null) {
				for (final Marriage marriageDivorce : hm) {
					final Marriage spouse = marriageDivorce;
					List<IndMarriageDivorce> ind = spouse.getIndMarriageDivorceList();

					if (ind != null) {
						for (final IndMarriageDivorce indMarriageDivorce : ind) {
							if (indMarriageDivorce.getActionType().equalsIgnoreCase("DIVORCE")) {
								if (dates == "") {
									dates = indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								} else {
									dates = dates + ";" + indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								}

							}
						}

					}
				}
			} else {
				logger.debug("hm = null ");

			}
			isSuccess = 0;
		}

		String returnString = isSuccess != 0 ? isSuccess + "" : (dates != "" ? dates : "0");
		if (logger.isDebugEnabled()) {
			logger.debug("getDivorceDates()ByID -  : returnString = " + returnString);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getDivorceDatesByID(String, String) - end");
		}
		return returnString;

	}

	public String getUserLastUpdate() {
		if (logger.isDebugEnabled()) {
			logger.debug("getUserLastUpdate() - start");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getUserLastUpdate() - end");
		}
		return userLastUpdate;
	}

	public ValidationServiceImpl getValidationUtil() {
		if (logger.isDebugEnabled()) {
			logger.debug("getValidationUtil() - start");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getValidationUtil() - end");
		}
		return validationUtil;
	}

	@ExceptionHandler(Exception.class)
	// @ResponseStatus(value = HttpStatus.OK, reason = "Contact not found")
	@ResponseBody
	public void handleException(final Exception e, final HttpServletRequest request, Writer writer) throws IOException {
		logger.error("updateDivorce(Integer, Integer, String)", e);
		if (e.getMessage().equals("COUPLE_ALREADY_MARRIED")) {
			writer.write("0");
		} else {
			writer.write("9 " + e.getMessage());
		}
	}

	@Override
	@RequestMapping("/service/updateDivorce.service")
	@ResponseBody
	@Secured({ "ROLE_updateDivorce" })
	public String updateDivorce(@RequestParam(value = "husbandCPR", required = true) Integer husbandCPR,
			@RequestParam(value = "wifeCPR", required = true) Integer wifeCPR,
			@RequestParam(value = "divorceDate", required = true) String divorceDate)
			throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException {
		int isSuccess = -1;
		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce(Integer husbandCPR = " + husbandCPR + ", Integer wifeCPR = " + wifeCPR
					+ ", String divorceDate = " + divorceDate + ")");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce(Integer, Integer, String) - start");
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && (validationUtil.isValidCpr(wifeCPR) != true)) {
			isSuccess = 3;
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(wifeCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if ((validationUtil.isValidCpr(husbandCPR) == true) && (validationUtil.isValidCpr(wifeCPR) == true)) {
			getCrsService().getFamilyServiceRef().registerDivorce(husbandCPR, wifeCPR,
					DateServiceImpl.getDateTimeFormatString(divorceDate), userLastUpdate);
			isSuccess = 0;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce(Integer, Integer, String) - end");
			logger.debug("updateDivorce() -  : isSuccess = " + isSuccess);
		}
		return isSuccess + "";

	}

	@Override
	@RequestMapping("/service/updateDivorceByID.service")
	@ResponseBody
	@Secured({ "ROLE_updateDivorce" })
	public String updateDivorce(@RequestParam(value = "husbandID", required = true) String husbandID,
			@RequestParam(value = "husbandNationalityCode", required = true) String husbandNationalityCode,
			@RequestParam(value = "wifeID", required = true) String wifeID,
			@RequestParam(value = "wifeNationalityCode", required = true) String wifeNationalityCode,
			@RequestParam(value = "divorceDate", required = true) String divorceDate)
			throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException {
		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce(String, String, String, String, String) - start");
		}

		int isSuccess = -1;

		// 411 UNITED ARAB EMIRATES
		// 430 KUWAIT
		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce(husbandID = " + husbandID + ", husbandNationalityCode = "
					+ husbandNationalityCode + ", wifeID = " + wifeID + ", wifeNationalityCode = " + wifeNationalityCode
					+ ", divorceDate = " + divorceDate + ")");
		}

		// 436 OMAN
		// 440 QATAR
		// 441 SAUDI ARABIA
		// 499 KINGDOM OF BAHRAIN
		// 900 NO NATIONALITY
		// 930 RESIDENT OF KUWAIT
		// 940 RESIDENT OF QATAR

		Integer husbandCPR = -1, wifeCPR = -1;
		// retrieve the CPR
		// if (husbandNationalityCode.equalsIgnoreCase("411") ||
		// husbandNationalityCode.equalsIgnoreCase("430")
		// || husbandNationalityCode.equalsIgnoreCase("436") ||
		// husbandNationalityCode.equalsIgnoreCase("440")
		// || husbandNationalityCode.equalsIgnoreCase("930") ||
		// husbandNationalityCode.equalsIgnoreCase("441")
		// || husbandNationalityCode.equalsIgnoreCase("940")) {
		husbandCPR = validationUtil.getGCCCpr(husbandID, husbandNationalityCode);
		// } else {
		// try {
		// husbandCPR = Integer.parseInt(husbandID);
		// } catch (Exception exception) {
		// exception.printStackTrace();
		// }
		// }
		// if (wifeNationalityCode.equalsIgnoreCase("411") ||
		// wifeNationalityCode.equalsIgnoreCase("430")
		// || wifeNationalityCode.equalsIgnoreCase("436") ||
		// wifeNationalityCode.equalsIgnoreCase("440")
		// || wifeNationalityCode.equalsIgnoreCase("930") ||
		// wifeNationalityCode.equalsIgnoreCase("441")
		// || wifeNationalityCode.equalsIgnoreCase("940")) {
		wifeCPR = validationUtil.getGCCCpr(wifeID, wifeNationalityCode);
		// } else {
		// try {
		// wifeCPR = Integer.parseInt(wifeID);
		// } catch (Exception exception) {
		// exception.printStackTrace();
		// }
		// }

		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce() -  : isSuccess = " + isSuccess + ", husbandCPR = " + husbandCPR
					+ ", wifeCPR = " + wifeCPR + ",validationUtil.isValidCpr(husbandCPR) = "
					+ validationUtil.isValidCpr(husbandCPR) + ",validationUtil.isValidCpr(wifeCPR) = "
					+ validationUtil.isValidCpr(wifeCPR));
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && (validationUtil.isValidCpr(wifeCPR) != true)) {
			isSuccess = 3;
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(wifeCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if ((validationUtil.isValidCpr(husbandCPR) == true) && (validationUtil.isValidCpr(wifeCPR) == true)) {
			getCrsService().getFamilyServiceRef().registerDivorce(husbandCPR, wifeCPR,
					DateServiceImpl.getDateTimeFormatString(divorceDate), userLastUpdate);
			isSuccess = 0;
		}

		String returnString = isSuccess + "";
		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce(String, String, String, String, String) - end");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("updateDivorce() -  : returnString = " + returnString);
		}

		return returnString;

	}
}
