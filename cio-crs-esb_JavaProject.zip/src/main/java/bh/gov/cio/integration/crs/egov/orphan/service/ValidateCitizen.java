package bh.gov.cio.integration.crs.egov.orphan.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.orphan.service.dto.OrphanServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "ValidateCitizenService", targetNamespace = "http://service.orphan.egov.crs.integration.cio.gov.bh/")
public interface ValidateCitizen {
	@WebResult(name = "isValid")
	@WebMethod(operationName = "checkCPRBlockExpiry")
	boolean checkCPRBlockExpiry(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate)
			throws ApplicationExceptionInfo;

	@WebResult(name = "isValid")
	@WebMethod(operationName = "checkCPR")
	boolean checkCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry)
			throws ApplicationExceptionInfo;

	@WebResult(name = "OrphanBasicInformation")
	@WebMethod(operationName = "getOrphanBasicInfoByMotherCPR")
	OrphanServiceBasicInfoDTO getOrphanBasicInfoByMotherCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "eKeyMotherIDNumber") @XmlElement(required = true) String eKeyMotherIDNumber,
			@WebParam(name = "motherCardCountry") @XmlElement(required = true) String motherCardCountry,
			@WebParam(name = "FatherIDNumber") @XmlElement(required = true) String fatherIDNumber,
			@WebParam(name = "fatherCardCountry") @XmlElement(required = true) String fatherCardCountry,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp)
			throws ApplicationExceptionInfo;

}
