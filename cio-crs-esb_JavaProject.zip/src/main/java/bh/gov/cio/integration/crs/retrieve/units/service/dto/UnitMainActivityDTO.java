package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import javax.xml.bind.annotation.XmlType;

/**
 * @author cspomlh
 * 
 */
@XmlType(name = "UnitMainActivity", propOrder = { "mainActivityArabicName", "mainActivityEnglishName",
		"detailedActivityArabicName", "detailedActivityEnglishName" })
public class UnitMainActivityDTO {
	private String mainActivityArabicName;
	private String mainActivityEnglishName;
	private String detailedActivityArabicName;
	private String detailedActivityEnglishName;

	public UnitMainActivityDTO(String mainActivityArabicName, String mainActivityEnglishName,
			String detailedActivityArabicName, String detailedActivityEnglishName) {
		super();
		this.mainActivityArabicName = mainActivityArabicName;
		this.mainActivityEnglishName = mainActivityEnglishName;
		this.detailedActivityArabicName = detailedActivityArabicName;
		this.detailedActivityEnglishName = detailedActivityEnglishName;
	}

	public UnitMainActivityDTO() {
		super();

	}

	public String getMainActivityArabicName() {
		return mainActivityArabicName;
	}

	public void setMainActivityArabicName(String mainActivityArabicName) {
		this.mainActivityArabicName = mainActivityArabicName;
	}

	public String getMainActivityEnglishName() {
		return mainActivityEnglishName;
	}

	public void setMainActivityEnglishName(String mainActivityEnglishName) {
		this.mainActivityEnglishName = mainActivityEnglishName;
	}

	public String getDetailedActivityArabicName() {
		return detailedActivityArabicName;
	}

	public void setDetailedActivityArabicName(String detailedActivityArabicName) {
		this.detailedActivityArabicName = detailedActivityArabicName;
	}

	public String getDetailedActivityEnglishName() {
		return detailedActivityEnglishName;
	}

	public void setDetailedActivityEnglishName(String detailedActivityEnglishName) {
		this.detailedActivityEnglishName = detailedActivityEnglishName;
	}
}
