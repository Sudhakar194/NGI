package bh.gov.cio.integration.crs.nns.dto;

public class StatusResponseDTO {

	private String statusCode;
	private String statusMessage;
	public StatusResponseDTO() {
		super();
	}
	public StatusResponseDTO(String statusCode, String statusMessage) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
}
