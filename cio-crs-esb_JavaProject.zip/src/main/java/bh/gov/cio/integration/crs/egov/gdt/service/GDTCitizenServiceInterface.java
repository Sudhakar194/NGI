package bh.gov.cio.integration.crs.egov.gdt.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.gdt.service.dto.CitizenStatusDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GDTCitizenService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public interface GDTCitizenServiceInterface
{
	@WebResult(name = "CitizenStatus")
	@WebMethod(operationName = "CheckCitizenStatus")
	CitizenStatusDTO CheckCitizenStatus(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "IDNumber") @XmlElement(required = true) Integer idNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp) throws ApplicationExceptionInfo;
}
