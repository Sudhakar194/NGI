package bh.gov.cio.integration.common;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

public class DateServiceImpl // implements DateServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger		logger						= LoggerFactory.getLogger(DateServiceImpl.class);

	private static SimpleDateFormat	dateFormatter				= new SimpleDateFormat("yyyyMMdd");
	private static SimpleDateFormat	dateDashFormatter			= new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat	dateDashFormatterDateFirst	= new SimpleDateFormat("dd-MM-yyyy");
	private static SimpleDateFormat	dateTimeFormatter			= new SimpleDateFormat("yyyyMMddHHmmss");
	private static SimpleDateFormat	dateTimeMilliSocondFormat	= new SimpleDateFormat("yyyyMMddHHmmssss");
	private static String			currentDate					= dateFormatter.format(new Date());
	private static String			currentDateDash				= dateDashFormatter.format(new Date());
	private static String			currentDateTime				= dateTimeFormatter.format(new Date());
	private static String			currentDateTimeMilliSocond	= dateTimeMilliSocondFormat.format(new Date());

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#formatDate(java .sql.Timestamp)
	 */
	public static String formatDateDayFirstAsString(Date date) throws ApplicationExceptionInfo
	{
		String formattedDate = null;
		try
		{
			if (date == null)
				formattedDate = "";
			else
				formattedDate = dateDashFormatterDateFirst.format(date.getTime());
			logger.debug("formattedDate : " + formattedDate);
		}
		catch (Exception e)
		{
//			e.printStackTrace();
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
			throw new ApplicationExceptionInfo("Date Format Error", new ApplicationException("Date Format must be dd-MM-yyyy " + date
					+ " is not following that format"));
		}

		return formattedDate;
	}

	public static Date formatDateDayFirstAsString(String date) throws ApplicationExceptionInfo
	{
		Date formattedDate = null;
		try
		{
				formattedDate = dateDashFormatterDateFirst.parse(date);
			logger.debug("formattedDate : " + formattedDate);
		}
		catch (Exception e)
		{
//			e.printStackTrace();
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
			throw new ApplicationExceptionInfo("Date Format Error", new ApplicationException("Date Format must be dd-MM-yyyy " + date
					+ " is not following that format"));
		}

		return formattedDate;
	}

	public static Date formatDateYYYMMDD(String date) throws ApplicationExceptionInfo
	{
		Date formattedDate = null;
		try
		{
			formattedDate = dateFormatter.parse(date);
		}
		catch (Exception e)
		{
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
			throw new ApplicationExceptionInfo("Date Format Error: "+date, new ApplicationException("Date Format must be yyyyMMdd " + date
					+ " is not following that format"));
		}

		return formattedDate;
	}
	
	public static Date formatDate(String date) throws ApplicationExceptionInfo
	{
		Date formattedDate = null;
		try
		{
			formattedDate = dateTimeMilliSocondFormat.parse(date);
		}
		catch (Exception e)
		{
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
			throw new ApplicationExceptionInfo("Date Format Error", new ApplicationException("Date Format must be dd-MM-yyyy " + date
					+ " is not following that format"));
		}

		return formattedDate;
	}

	public static Date formatDashDate(String date) throws ApplicationExceptionInfo
	{
		Date formattedDate = null;
		try
		{
			formattedDate = dateDashFormatterDateFirst.parse(date);
		}
		catch (Exception e)
		{
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
			throw new ApplicationExceptionInfo("Date Format Error", new ApplicationException("Date Format must be dd-MM-yyyy " + date
					+ " is not following that format"));
		}

		return formattedDate;
	}

	public static String formatDate(Timestamp date)
	{
		String formattedDate = null;
		// String formattedDateStr = null;
		try
		{
			formattedDate = dateDashFormatter.format(date);
		}
		catch (Exception e)
		{
			// TODO: handle exception
			// e.printStackTrace();
		}

		return formattedDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#formatDate(java .util.Date)
	 */
	public static Date formatDate(Date date)
	{
		Date formattedDate = null;
		try
		{
			formattedDate = dateDashFormatter.parse(date + "");
		}
		catch (Exception e)
		{
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
		}

		return formattedDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#formatDate(java .util.Date)
	 */
	public static String formatDateAsString(Timestamp date)
	{
		String formattedDate = null;
		try
		{
			if (date == null)
				formattedDate = "";
			else
				formattedDate = dateDashFormatter.format(date.getTime());
			logger.debug("formattedDate : " + formattedDate);
		}
		catch (Exception e)
		{
//			e.printStackTrace();
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
		}

		return formattedDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#formatDate(java .util.Date)
	 */
	public static String formatDateAsString(Date date)
	{
		String formattedDate = null;
		try
		{
			formattedDate = dateDashFormatter.format(date);

		}
		catch (Exception e)
		{
			// TODO: handle exception
			logger.error("formatDate(Date)", e);
		}

		return formattedDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#getDateTimeFormatString (java.lang.String)
	 */
	public static Timestamp getDateTimeFormatString(String Datetime)
	{
		Timestamp returnedDate = null;
		try
		{
			returnedDate = new Timestamp(dateTimeFormatter.parse(Datetime).getTime());
		}
		catch (ParseException e)
		{

			logger.error("getDateTimeFormatString(String)", e);
		}
		return returnedDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface# getCurrentDateTimeMilliSocond()
	 */
	public static String getCurrentDateTimeMilliSocond()
	{
		currentDateTimeMilliSocond = dateTimeMilliSocondFormat.format(new Date());
		return currentDateTimeMilliSocond;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#getCurrentDate()
	 */
	public static String getCurrentDate()
	{
		currentDate = dateFormatter.format(new Date());
		return currentDate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#getCurrentDateTime ()
	 */
	public static String getCurrentDateTime()
	{
		currentDateTime = dateTimeFormatter.format(new Date());
		return currentDateTime;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.DateServiceInterface#getCurrentDateDash ()
	 */
	public static String getCurrentDateDash()
	{
		currentDateDash = dateDashFormatter.format(new Date());
		return currentDateDash;
	}

	public static void main(String[] args)
	{
//		logger.debug(DateServiceImpl.getDateTimeFormatString("19991208112230"));
		// logger.debug(DateServiceImpl.formatDate("19991208112230"));
	}

}
