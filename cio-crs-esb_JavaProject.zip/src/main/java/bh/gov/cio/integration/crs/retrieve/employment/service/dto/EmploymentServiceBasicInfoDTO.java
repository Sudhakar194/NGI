package bh.gov.cio.integration.crs.retrieve.employment.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "EmploymentServiceBasicInformation", propOrder =
{ "employerNumber", "employerArabicName", "employerEnglishName",
		"employerType", "employmentStatus", "occupationCode" })
public class EmploymentServiceBasicInfoDTO
{
	private static final long	serialVersionUID	= 1L;
	private String				employerNumber, employerArabicName,
			employerEnglishName, employerType, employmentStatus,
			occupationCode;

	public EmploymentServiceBasicInfoDTO()
	{
		super();
	}

	public EmploymentServiceBasicInfoDTO(String employerNumber,
			String employerAN, String employerEN, String employerType,
			String employmentStatus, String occupationCode)
	{
		super();
		this.employerNumber = employerNumber;
		this.employerArabicName = employerAN;
		this.employerEnglishName = employerEN;
		this.employerType = employerType;
		this.employmentStatus = employmentStatus;
		this.occupationCode = occupationCode;
	}

	@XmlElement(name = "EmployerArabicName")
	public String getEmployerArabicName()
	{
		return employerArabicName;
	}

	@XmlElement(name = "EmployerEnglishName")
	public String getEmployerEnglishName()
	{
		return employerEnglishName;
	}

	@XmlElement(name = "EmployerNumber")
	public String getEmployerNumber()
	{
		return employerNumber;
	}

	@XmlElement(name = "EmployerType")
	public String getEmployerType()
	{
		return employerType;
	}

	@XmlElement(name = "EmploymentStatus")
	public String getEmploymentStatus()
	{
		return employmentStatus;
	}

	public void setEmployerArabicName(String employerAN)
	{
		this.employerArabicName = employerAN;
	}

	public void setEmployerEnglishName(String employerEN)
	{
		this.employerEnglishName = employerEN;
	}

	public void setEmployerNumber(String employerNumber)
	{
		this.employerNumber = employerNumber;
	}

	public void setEmployerType(String employerType)
	{
		this.employerType = employerType;
	}

	public void setEmploymentStatus(String employmentStatus)
	{
		this.employmentStatus = employmentStatus;
	}

	public void setOccupationCode(String occupationCode)
	{
		this.occupationCode = occupationCode;
	}

	@XmlElement(name = "OccupationCode")
	public String getOccupationCode()
	{
		return occupationCode;
	}

}
