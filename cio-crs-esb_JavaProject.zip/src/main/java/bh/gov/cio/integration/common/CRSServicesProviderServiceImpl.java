package bh.gov.cio.integration.common;

import java.net.MalformedURLException;

import org.bh.cio.hs.client.HousingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.bnaf.validate.token.ws.ValidateToken;
import com.caucho.hessian.client.HessianProxyFactory;

import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.BiometricService;
import bh.gov.cio.crs.service.DisabilityService;
import bh.gov.cio.crs.service.EmploymentService;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.GDNPRService;
import bh.gov.cio.crs.service.LookupService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.service.PersonWatchListService;
import bh.gov.cio.crs.service.UnitService;

@Configuration(value = "CRSServicesProviderService")
public class CRSServicesProviderServiceImpl
{
	/**
	 * Logger for this class
	 */
	private static final Logger	logger	= LoggerFactory.getLogger(CRSServicesProviderServiceImpl.class);

	@Autowired
	private PropertyServiceImpl	propImpl;

	@Autowired
	private AddressService		addressServiceRef;

//	@Autowired
//	private bh.gov.cio.crs.esb.service.AddressService		newAddressServiceRef;
//
	@Autowired
	private PersonService		personServiceRef;

	
	@Autowired
	private PersonWatchListService		watchlistServiceRef;

//	@Autowired
//	private bh.gov.cio.crs.esb.service.PersonService		newPersonServiceRef;

	@Autowired
	private DisabilityService	disabilityServiceRef;

	@Autowired
	private EmploymentService	employmentServiceRef;

	@Autowired
	private FamilyService		familyServiceRef;

	@Autowired
	private UnitService			unitServiceRef;

	@Autowired
	private LookupService		lookupServiceRef;

	@Autowired
	private BiometricService	biometricServiceRef;

	@Autowired
	private GDNPRService		gdnprServiceRef;

	@Autowired
	private HousingService		housingServiceRef;

	@Autowired
	private ValidateToken		eKeyServiceRef;

	HessianProxyFactory			proxy	= new HessianProxyFactory();
	{
		proxy.setHessian2Request(false);
		proxy.setHessian2Reply(false);
		proxy.setChunkedPost(false);
	}

	@Bean(name = "eKeyServiceRef")
	@Scope(value = "prototype")
	public ValidateToken geteKeyServiceRef()
	{
		try
		{
			proxy.setPassword(propImpl.geteGOVeKeyPassword());
			eKeyServiceRef = (ValidateToken) proxy.create(ValidateToken.class, propImpl.geteGOVeKeyServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("eKeyServiceRef()", exception);
		}
		return eKeyServiceRef;
	}

	@Bean(name = "AddressServiceRef")
	@Scope(value = "prototype")
	public AddressService getAddressServiceRef()
	{

		try
		{

			addressServiceRef = (AddressService) proxy.create(AddressService.class, propImpl.getAddressServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getAddressServiceRef()", exception);
		}
		return addressServiceRef;
	}

	@Bean(name = "BiometricServiceRef")
	@Scope(value = "prototype")
	public BiometricService getBiometricServiceRef()
	{

		try
		{

			biometricServiceRef = (BiometricService) proxy.create(BiometricService.class, propImpl.getBiometricServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("biometricServiceRef()", exception);
		}
		return biometricServiceRef;
	}

	@Bean(name = "DisabilityServiceRef")
	@Scope(value = "prototype")
	public DisabilityService getDisabilityServiceRef()
	{

		try
		{

			disabilityServiceRef = (DisabilityService) proxy.create(DisabilityService.class, propImpl.getDisabilityServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getDisabilityServiceRef()", exception);
		}
		return disabilityServiceRef;
	}

	@Bean(name = "EmploymentServiceRef")
	@Scope(value = "prototype")
	public EmploymentService getEmploymentServiceRef()
	{

		try
		{

			employmentServiceRef = (EmploymentService) proxy.create(EmploymentService.class, propImpl.getEmploymentServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getEmploymentServiceRef()", exception);
		}
		return employmentServiceRef;
	}

	@Bean(name = "FamilyServiceRef")
	@Scope(value = "prototype")
	public FamilyService getFamilyServiceRef()
	{

		try
		{

			familyServiceRef = (FamilyService) proxy.create(FamilyService.class, propImpl.getFamilyServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getFamilyServiceRef()", exception);
		}
		return familyServiceRef;
	}

	@Bean(name = "GDNPRServiceRef")
	@Scope(value = "prototype")
	public GDNPRService getGDNPRServiceRef()
	{

		try
		{

			gdnprServiceRef = (GDNPRService) proxy.create(GDNPRService.class, propImpl.getGdnprServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("gdnprServiceRef()", exception);
		}
		return gdnprServiceRef;
	}

	@Bean(name = "HousingServiceRef")
	@Scope(value = "prototype")
	public HousingService getHousingServiceRef()
	{
		try
		{

			housingServiceRef = (HousingService) proxy.create(HousingService.class, propImpl.getHousingServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getHousingServiceRef()", exception);
		}
		return housingServiceRef;
	}

	@Bean(name = "PersonServiceRef")
	@Scope(value = "prototype")
	public PersonService getPersonServiceRef()
	{
		try
		{
			personServiceRef = (PersonService) proxy.create(PersonService.class, propImpl.getPersonServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getPersonServiceRef()", exception);
		}
		return personServiceRef;
	}

	@Bean(name = "WatchlistServiceRef")
	@Scope(value = "prototype")
	public PersonWatchListService getWatchlistServiceRef()
	{
		try
		{
			watchlistServiceRef = (PersonWatchListService) proxy.create(PersonWatchListService.class, propImpl.getWatchlistServiceURL());
		}
		catch (final MalformedURLException exception)
		{
			
			logger.error("getWatchlistServiceRef()", exception);
		}
		return watchlistServiceRef;
	}
	
//	@Bean(name = "NewPersonServiceRef")
//	@Scope(value = "prototype")
//	public bh.gov.cio.crs.esb.service.PersonService getNewPersonServiceRef()
//	{
//		try
//		{
//			
//			newPersonServiceRef = (bh.gov.cio.crs.esb.service.PersonService) proxy.create(bh.gov.cio.crs.esb.service.PersonService.class, propImpl.getPersonServiceURL());
//		}
//		catch (final MalformedURLException exception)
//		{
//			
//			logger.error("getPersonServiceRef()", exception);
//		}
//		return newPersonServiceRef;
//	}
//
//	@Bean(name = "NewAddressServiceRef")
//	@Scope(value = "prototype")
//	public bh.gov.cio.crs.esb.service.AddressService getNewAddressServiceRef()
//	{
//		try
//		{
//			
//			newAddressServiceRef = (bh.gov.cio.crs.esb.service.AddressService) proxy.create(bh.gov.cio.crs.esb.service.AddressService.class, propImpl.getAddressServiceURL());
//		}
//		catch (final MalformedURLException exception)
//		{
//			
//			logger.error("getNewAddressServiceRef()", exception);
//		}
//		return newAddressServiceRef;
//	}

	@Bean(name = "UnitServiceRef")
	@Scope(value = "prototype")
	public UnitService getUnitServiceRef()
	{

		try
		{

			unitServiceRef = (UnitService) proxy.create(UnitService.class, propImpl.getUnitServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getUnitServiceRef()", exception);
		}
		return unitServiceRef;
	}

	@Bean(name = "LookupServiceRef")
	@Scope(value = "prototype")
	public LookupService getLookupServiceRef()
	{

		try
		{

			lookupServiceRef = (LookupService) proxy.create(LookupService.class, propImpl.getLookupServiceURL());
		}
		catch (final MalformedURLException exception)
		{

			logger.error("getLookupServiceRef()", exception);
		}
		return lookupServiceRef;
	}

	
	public void setAddressServiceRef(AddressService addressServiceRef)
	{
		this.addressServiceRef = addressServiceRef;
	}

	public void setBiometricServiceRef(BiometricService biometricServiceRef)
	{
		this.biometricServiceRef = biometricServiceRef;
	}

	public void setDisabilityServiceRef(DisabilityService disabilityServiceRef)
	{
		this.disabilityServiceRef = disabilityServiceRef;
	}

	public void setEmploymentServiceRef(EmploymentService employmentServiceRef)
	{
		this.employmentServiceRef = employmentServiceRef;
	}

	public void setFamilyServiceRef(FamilyService familyServiceRef)
	{
		this.familyServiceRef = familyServiceRef;
	}

	public void setGDNPRServiceRef(GDNPRService gdnprServiceRef)
	{
		this.gdnprServiceRef = gdnprServiceRef;
	}

	public void setHousingServiceRef(HousingService housingServiceRef)
	{
		this.housingServiceRef = housingServiceRef;
	}

	public void setPersonServiceRef(PersonService personServiceRef)
	{
		this.personServiceRef = personServiceRef;
	}

	public void setWatchlistServiceRef(PersonWatchListService watchlistServiceRef)
	{
		this.watchlistServiceRef = watchlistServiceRef;
	}

	public void setUnitServiceRef(UnitService unitServiceRef)
	{
		this.unitServiceRef = unitServiceRef;
	}

	public void setLookupServiceRef(LookupService lookupServiceRef)
	{
		this.lookupServiceRef = lookupServiceRef;
	}

	public void seteKeyServiceRef(ValidateToken eKeyServiceRef)
	{
		this.eKeyServiceRef = eKeyServiceRef;
	}

}
