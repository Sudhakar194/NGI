package bh.gov.cio.integration.common;

import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

import bh.gov.cio.integration.common.dao.PropertiesDao;

@Configuration
public class PropertyServiceImpl
{
	/**
	 * Logger for this class
	 */
	private static final Logger	logger			= LoggerFactory.getLogger(PropertyServiceImpl.class);

	@Autowired
	protected PropertiesDao		propertLoaderDao;

	@Value("${admin.schema.name}")
	private String schemaName;

	@Value("${WATCHLIST_SERVICE_URL}")
	private String				watchlistServiceURL;

	@Value("${PERSON_SERVICE_URL}")
	private String				personServiceURL;

	@Value("${BIOMETRIC_SERVICE_URL}")
	private String				biometricServiceURL;

	@Value("${ADDRESS_SERVICE_URL}")
	private String				addressServiceURL;

	@Value("${EMPLOYMENT_SERVICE_URL}")
	private String				employmentServiceURL;

	@Value("${DISABILITY_SERVICE_URL}")
	private String				disabilityServiceURL;

	@Value("${UNIT_SERVICE_URL}")
	private String				unitServiceURL;

	@Value("${LOOKUP_SERVICE_URL}")
	private String				lookupServiceURL;
	
	@Value("${GDNPR_SERVICE_URL}")
	private String				gdnprServiceURL;

	@Value("${FAMILY_SERVICE_URL}")
	private String				familyServiceURL;

	@Value("${GOSI_SERVICE_URL}")
	private String				gosiServiceURL;

	@Value("${HOUSING_SERVICE_URL}")
	private String				housingServiceURL;

	@Value("${EGOV_EKEY_SERVICE_URL}")
	private String				eGOVeKeyServiceURL;

	@Value("${EGOV_EKEY_PASSOWRD}")
	private String				eGOVeKeyPassword;

	private final int			refreshCount	= 0;

	@Value("${REFRESH_RATE}")
	private int					refreshRate;

	public String getAddressServiceURL()
	{

		return addressServiceURL;
	}

	public String getBiometricServiceURL()
	{

		return biometricServiceURL;
	}

	public String getDisabilityServiceURL()
	{

		return disabilityServiceURL;
	}

	public String getEmploymentServiceURL()
	{

		return employmentServiceURL;
	}

	public String getFamilyServiceURL()
	{

		return familyServiceURL;
	}

	public String getGdnprServiceURL()
	{

		return gdnprServiceURL;
	}

	public String getGosiServiceURL()
	{

		return gosiServiceURL;
	}

	public String getHousingServiceURL()
	{
		return housingServiceURL;
	}

	public String getPersonServiceURL()
	{

		return personServiceURL;
	}

	public String getWatchlistServiceURL()
	{
		
		return watchlistServiceURL;
	}

	public int getRefreshRate()
	{
		return refreshRate;
	}

	public String getUnitServiceURL()
	{

		return unitServiceURL;
	}

	public String getLookupServiceURL()
	{

		return lookupServiceURL;
	}

	public void loadProperties()
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("loadProperties() - start");
		}

		// if (refreshCount > getRefreshRate())
		// {
		List<Map<String, Object>> result;
		try
		{
			result = propertLoaderDao.getCurrentServerProperties();
			for (final Map<String, Object> propertiesMapObject : result)
			{
				// MQ Settings
				// Hessian URLs
				if (propertiesMapObject.get("PERSON_SERVICE_URL") != null)
				{
					setPersonServiceURL((String) propertiesMapObject.get("PERSON_SERVICE_URL"));
				}
				if (propertiesMapObject.get("ADDRESS_SERVICE_URL") != null)
				{
					setAddressServiceURL((String) propertiesMapObject.get("ADDRESS_SERVICE_URL"));
				}
				if (propertiesMapObject.get("EMPLOYMENT_SERVICE_URL") != null)
				{
					setEmploymentServiceURL((String) propertiesMapObject.get("EMPLOYMENT_SERVICE_URL"));
				}
				if (propertiesMapObject.get("DISABILITY_SERVICE_URL") != null)
				{
					setDisabilityServiceURL((String) propertiesMapObject.get("DISABILITY_SERVICE_URL"));
				}
				if (propertiesMapObject.get("UNIT_SERVICE_URL") != null)
				{
					setUnitServiceURL((String) propertiesMapObject.get("UNIT_SERVICE_URL"));
				}
				if (propertiesMapObject.get("GDNPR_SERVICE_URL") != null)
				{
					setGdnprServiceURL((String) propertiesMapObject.get("GDNPR_SERVICE_URL"));
				}
				if (propertiesMapObject.get("LOOKUP_SERVICE_URL") != null)
				{
					setGdnprServiceURL((String) propertiesMapObject.get("LOOKUP_SERVICE_URL"));
				}
				if (propertiesMapObject.get("WATCHLIST_SERVICE_URL") != null)
				{
					setGdnprServiceURL((String) propertiesMapObject.get("WATCHLIST_SERVICE_URL"));
				}
				if (propertiesMapObject.get("FAMILY_SERVICE_URL") != null)
				{
					setFamilyServiceURL((String) propertiesMapObject.get("FAMILY_SERVICE_URL"));
				}
				if (propertiesMapObject.get("BIOMETRIC_SERVICE_URL") != null)
				{
					setBiometricServiceURL((String) propertiesMapObject.get("BIOMETRIC_SERVICE_URL"));
				}
				if (propertiesMapObject.get("GOSI_SERVICE_URL") != null)
				{
					setGosiServiceURL((String) propertiesMapObject.get("GOSI_SERVICE_URL"));
				}

				if (propertiesMapObject.get("HOUSING_SERVICE_URL") != null)
				{
					setHousingServiceURL((String) propertiesMapObject.get("HOUSING_SERVICE_URL"));
				}
				if (propertiesMapObject.get("REFRESH_RATE") != null)
				{
					setRefreshRate((Integer) propertiesMapObject.get("REFRESH_RATE"));
				}
				if (propertiesMapObject.get("EGOV_EKEY_SERVICE_URL") != null)
				{
					seteGOVeKeyServiceURL((String) propertiesMapObject.get("EGOV_EKEY_SERVICE_URL"));
				}
				if (propertiesMapObject.get("EGOV_EKEY_PASSOWRD") != null)
				{
					seteGOVeKeyServiceURL((String) propertiesMapObject.get("EGOV_EKEY_SERVICE_URL"));
				}
			}
		}
		catch (final UnknownHostException e)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("loadProperties() - " + e.getMessage());
			}
		}
		// catch (ApplicationException e)
		// {
		// if (logger.isDebugEnabled())
		// {
		// logger.debug("loadProperties() - " + e.getMessage());
		// }
		// }
		// catch (BusinessException e)
		// {
		// if (logger.isDebugEnabled())
		// {
		// logger.debug("loadProperties() - " + e.getMessage());
		// }
		// }
		catch (final CannotGetJdbcConnectionException e)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("loadProperties() - " + e.getMessage());
			}
		}
		catch (final Exception e)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("loadProperties() - " + e.getMessage());
			}

		}
		// refreshCount = 0;
		// }// if
		// else
		// {
		// refreshCount++;
		// }

		if (logger.isDebugEnabled())
		{
			logger.debug("loadProperties() - end");
		}
	}

	public void setAddressServiceURL(String addressServiceURL)
	{
		this.addressServiceURL = addressServiceURL;
	}

	public void setBiometricServiceURL(String biometricServiceURL)
	{
		this.biometricServiceURL = biometricServiceURL;
	}

	public void setDisabilityServiceURL(String disabilityServiceURL)
	{
		this.disabilityServiceURL = disabilityServiceURL;
	}

	public void setEmploymentServiceURL(String employmentServiceURL)
	{
		this.employmentServiceURL = employmentServiceURL;
	}

	public void setFamilyServiceURL(String familyServiceURL)
	{
		this.familyServiceURL = familyServiceURL;
	}

	public void setGdnprServiceURL(String gdnprServiceURL)
	{
		this.gdnprServiceURL = gdnprServiceURL;
	}

	public void setWatchlistServiceURL(String watchlistServiceURL)
	{
		this.watchlistServiceURL = watchlistServiceURL;
	}

	public void setGosiServiceURL(String gosiServiceURL)
	{
		this.gosiServiceURL = gosiServiceURL;
	}

	public void setHousingServiceURL(String housingServiceURL)
	{
		this.housingServiceURL = housingServiceURL;
	}

	public void setPersonServiceURL(String personServiceURL)
	{
		this.personServiceURL = personServiceURL;
	}

	public void setRefreshRate(int refreshRate)
	{
		this.refreshRate = refreshRate;
	}

	public void setUnitServiceURL(String unitServiceURL)
	{
		this.unitServiceURL = unitServiceURL;
	}

	public void setLookupServiceURL(String lookupServiceURL)
	{
		this.lookupServiceURL = lookupServiceURL;
	}

	public void seteGOVeKeyServiceURL(String eGOVeKeyServiceURL)
	{
		this.eGOVeKeyServiceURL = eGOVeKeyServiceURL;
	}

	public String geteGOVeKeyPassword() {
		return eGOVeKeyPassword;
	}

	public void seteGOVeKeyPassword(String eGOVeKeyPassword) {
		this.eGOVeKeyPassword = eGOVeKeyPassword;
	}

	public String geteGOVeKeyServiceURL()
	{
		return eGOVeKeyServiceURL;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

}
