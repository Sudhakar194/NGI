package bh.gov.cio.integration.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.cr.CRDetails;
import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.CPRCard;
import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.Smartcard;
import bh.gov.cio.crs.model.support.CRSConstants;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.util.CRSUtils;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

@Configuration(value = "ValidationService")
public class ValidationServiceImpl implements ErrorMessages, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(ValidationServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl	crsService;
	@Autowired
	private PropertyServiceImpl				propImpl;

	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	public CommonTypes.Nationality getNationalityCategory(String nationalityCode) throws ApplicationExceptionInfo {
		CommonTypes.Nationality returned = CommonTypes.Nationality.Other;
		if (isBahraini(nationalityCode)) {
			returned = CommonTypes.Nationality.Bahraini;
			return returned;
		} else if (isGCC(nationalityCode)) {
			returned = CommonTypes.Nationality.GCC;
			return returned;
		} else
			return returned;

	}

	public boolean isGCC(String nationalityCode) throws ApplicationExceptionInfo {
		if (logger.isTraceEnabled()) {
			logger.debug("isGCC(String) - start");
		}

		try {
			if ((nationalityCode != null)
					&& (nationalityCode.equalsIgnoreCase("411") || nationalityCode.equalsIgnoreCase("430")
							|| nationalityCode.equalsIgnoreCase("436") || nationalityCode.equalsIgnoreCase("440")
							|| nationalityCode.equalsIgnoreCase("441") || nationalityCode.equalsIgnoreCase("900")
							|| nationalityCode.equalsIgnoreCase("930") || nationalityCode.equalsIgnoreCase("940"))) {
				return true;
			} else {
				return false;
			}
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo("GCC ID Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}
	}

	public boolean isBahraini(String nationalityCode) throws ApplicationExceptionInfo {
		if (logger.isTraceEnabled()) {
			logger.debug("isGCC(String) - start");
		}

		try {
			if ((nationalityCode != null) && (nationalityCode.equalsIgnoreCase("499"))) {
				return true;
			} else {
				return false;
			}
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo("GCC ID Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}
	}

	public Integer getGCCCpr(String IDNumber, String cardCountry) throws ApplicationExceptionInfo {
		if (logger.isTraceEnabled()) {
			logger.debug("getGCCCpr(Integer,String) - start");
		}

		Integer isValid = -1;
		PersonService ps = getCrsService().getPersonServiceRef();
		if (cardCountry == null || "".equals(cardCountry.trim())) {
			cardCountry = "499";
		}
		try {

			isValid = ps.getGccNationalSn(IDNumber, cardCountry);
		} catch (Exception e) {
			logger.debug("getGCCCpr() -  : getGCCNatioanlSn Failed : {}", e.getMessage());
		}

		if (isValid != -1)
			return isValid;

		try {
			isValid = Integer.parseInt(IDNumber);
		} catch (Exception e) {
			logger.debug("getGCCCpr() -  : Integer.parseInt(IDNumber) Failed : {}", e.getMessage());
			throw new ApplicationExceptionInfo("GCC ID Validation General Exception",
					new ApplicationException("The Provided GCCID Is Incorrect"));
		}

		try {
			ps.getPersonBasicInfo(isValid);
		} catch (Exception e) {
			logger.debug("getGCCCpr() -  : ps.getPersonBasicInfo(isValid) Failed : {}", e.getMessage());
			throw new ApplicationExceptionInfo("GCC ID Validation General Exception",
					new ApplicationException("The Provided GCCID Is Incorrect"));
		}
		// Commented upon shayma request for eKey
		// String dbNat = pbi.getNationalityCode();
		// logger.debug("getGCCCpr() - :
		// "+dbNat+".equals("+nationalityCode+")"+dbNat.equals(nationalityCode));
		// if (!dbNat.equals(nationalityCode) && !dbNat.equalsIgnoreCase("499"))
		// {
		// logger.debug("getGCCCpr() - :
		// !pbi.getNationalityCode("+dbNat+"\").equals("+nationalityCode+")");
		// throw new ApplicationExceptionInfo("GCC ID Validation General
		// Exception",
		// new ApplicationException("The Provided GCCID Is Incorrect"));
		// }
		logger.debug("getGCCCpr(Integer) - end");
		return isValid;
	}

	public boolean hasValidBlock(Integer cprNumber, Integer blockNumber) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("hasValidBlock(Integer, Integer) - start");
		}
		boolean isValid = false;
		final ArrayList<Address> pAddresses = getCPRNumberBlock(cprNumber);

		for (Iterator<Address> iterator = pAddresses.iterator(); iterator.hasNext();) {
			Address address = (Address) iterator.next();
			if (blockNumber.equals(address.getBlockNumber())) {
				isValid = true;
			}

		}

		if (logger.isDebugEnabled()) {
			logger.debug("hasValidBlock(Integer, Integer) - end");
		}
		return isValid;
	}

	public boolean hasValidDateOfBirth(Integer cprNumber, Date dateOfBirth) throws ApplicationExceptionInfo {
		boolean isValid = false;

		if (logger.isDebugEnabled()) {
			logger.debug("hasValidDateOfBirth(Integer, Date) - start");
		}

		PersonBasicInfo personBasicInfo = null;
		try {
			personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);

			final Date dbDateOfBirth = CRSUtils.getDateFromTimestamp(personBasicInfo.getDateOfBirth());

			if (logger.isDebugEnabled()) {
				logger.debug("hasValidDateOfBirth() -  : dbDateOfBirth = " + dbDateOfBirth);
				logger.debug("hasValidDateOfBirth() -  : dateOfBirth = " + dateOfBirth);
			}

			if (dbDateOfBirth.equals(dateOfBirth)) {
				isValid = true;
			}
		} catch (final Exception exception) {
			throw new ApplicationExceptionInfo("Birth Date Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("hasValidDateOfBirth(Integer, Date) - end");
		}

		return isValid;
	}

	public boolean hasValidExpiryCardData(Integer cprNumber, Date cardExpiryDate) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("hasValidExpiryCardData(Integer, Date) - start");
		}

		// PersonSummary personSummary =
		// getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
		boolean isValid = false;
		final Date dbCardExpiryDate = getCPRNumberExpiry(cprNumber);

		logger.debug("hasValidExpiryCardData() -  : cardExpiryDate = " + cardExpiryDate);

		if (dbCardExpiryDate != null && dbCardExpiryDate.equals(cardExpiryDate)) {
			isValid = true;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("hasValidExpiryCardData(Integer, Date) - end");
		}
		return isValid;
	}

	public boolean checkValidCardExpiryDate(Integer cprNumber) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("checkValidCardExpiryDate(Integer) - start");
		}

		boolean isValid = false;
		final Date dbCardExpiryDate = getCPRNumberExpiry(cprNumber);

		logger.debug("checkValidCardExpiryDate() -  : dbCardExpiryDate = " + dbCardExpiryDate);

		if (dbCardExpiryDate != null && dbCardExpiryDate.after(new Date())) {
			isValid = true;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("dbCardExpiryDate(Integer) - end");
		}
		return isValid;
	}

	public boolean hasValidCardSerialNumber(Integer cprNumber, String cardSerialNumber)
			throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("hasValidCardSerialNumber(Integer, Date) - start");
		}

		boolean isValid = false;
		try {
			final List<Smartcard> personSmartcards = getCrsService().getPersonServiceRef()
					.getActivePersonSmartcards(cprNumber);

			if (personSmartcards.size() != 0) {

				final String dbCardSerialNumber = personSmartcards.get(personSmartcards.size() - 1)
						.getCardSerialNumber();

				if (logger.isDebugEnabled()) {
					logger.debug("hasValidCardSerialNumber() -  : dbCardSerialNumber = " + dbCardSerialNumber);
					logger.debug("hasValidCardSerialNumber() -  : cardSerialNumber = " + cardSerialNumber);
				}

				if (dbCardSerialNumber.equals(cardSerialNumber)) {
					isValid = true;
				}
			}
		} catch (final Exception exception) {
			throw new ApplicationExceptionInfo("Card Serial Number Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("hasValidCardSerialNumber(Integer, Date) - end");
		}
		return isValid;
	}

	public boolean isDeletedCpr(Integer cprNumber) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("isValidCpr(Integer) - start");
		}

		boolean isDeleted = false;
		try {
			isDeleted = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber).getIsDeleted()
					.equalsIgnoreCase("F") ? false
							: getCrsService().getPersonServiceRef().getPersonSummary(cprNumber).getIsActive()
									.equalsIgnoreCase("F") ? false : true;
		} catch (org.springframework.dao.EmptyResultDataAccessException exception) {
			throw new ApplicationExceptionInfo(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
					new ApplicationException(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
							ERROR_CPR_NOT_FOUND_CODE));
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo(ERROR_DELETED_CPR.replaceAll("\\?", cprNumber + ""),
					new ApplicationException(ERROR_DELETED_CPR.replaceAll("\\?", cprNumber + ""),
							ERROR_DELETED_CPR_CODE));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("isValidCpr(Integer) - end");
		}
		return isDeleted;
	}

	public boolean isMilitaryCpr(Integer cprNumber) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("isMilitaryCpr(Integer) - start");
		}
		final Integer[] MilitaryUnitNumbers = new Integer[] { 80134700, 80121500, 80134800, 80134900, 80135000,
				80135100, 80135200, 80135300, 80135400, 80135500, 80135505, 80135600, 80135700, 80135800, 80135900,
				80136000, 80136100, 80136111, 80136121, 80136131, 80136200, 80136201, 80136202, 80136204, 80136205,
				80136300, 80136301, 80136302, 80136303, 80136304, 80136400, 80136401, 80136402, 80136500, 80136501,
				80136502, 80136600, 80136700, 80136701, 80136800, 80136801, 80136802, 80136803, 80136804, 80136805,
				80136900, 80136901, 80850000, 80860000, 80870000, 80880000, 80890000, 80600000, 80139500, 80137000,
				80137001, 80137100, 80137200, 80137300, 80137400, 80137500, 80137600, 80137700, 80137800, 80137900,
				80138000, 80138100, 80138200, 80138300, 80138400, 80138500, 80138600, 80138800, 80138900, 80139000,
				80139100, 80139200, 80139300, 80139600, 80139700, 80139800, 80139900, 80139901, 80139902, 80139903,
				80139904, 80130000, 80130100, 80131100, 80131200, 80131400, 80131500, 80131600, 80131700, 80131800,
				80131900, 80132106, 80132200, 80132300, 80132400, 80132500, 80132600, 80132800, 80133000, 80133100,
				80133200, 80133300, 80133400, 80133500, 80133600, 80133700, 80133800, 80133900, 80134000, 80134100,
				80134200, 80134300, 80134400, 80134420, 80134500, 80134803, 80134810, 80134811, 80134812, 80134821,
				80134822, 80134823, 80134824, 80134832, 80134833, 80134834, 80134820 };
		final List<Integer> MilitaryUnitNumbersList = Arrays.asList(MilitaryUnitNumbers);
		boolean isMilitary = false;
		try {
			final List<Employment> employment = getCrsService().getEmploymentServiceRef()
					.getActiveEmployments(cprNumber);
			// @SuppressWarnings("unchecked")
			// List<Employment> military =
			// getCrsService().getEmploymentService().getMilitryUnits();
			// employment.retainAll(military);
			if (employment != null) {
				for (final Employment employment2 : employment) {
					final Employment currentEmployement = employment2;
					final Integer employerNumber = currentEmployement.getEmployerNumber();

					if (logger.isDebugEnabled()) {
						logger.debug("isMilitaryCpr(cprNumber = " + cprNumber + ") -  : employerNumber = "
								+ employerNumber + " -  : employerType = " + employment2.getEmployerType());
					}

					/*
					 * (T.UNIT_NUMBER BETWEEN 80120000 AND 80139999) OR (T.UNIT_NUMBER BETWEEN
					 * 80550000 AND 80559999) OR (T.UNIT_NUMBER BETWEEN 80600000 AND 80609999) OR
					 * (T.UNIT_NUMBER BETWEEN 79100101 AND 79499999 ) OR (T.UNIT_NUMBER BETWEEN
					 * 99100001 AND 99199999 ) OR -- (T.UNIT_NUMBER BETWEEN 80110000 AND 80119999 )
					 * OR (T.UNIT_NUMBER BETWEEN 80901100 AND 80901199 ) OR (T.UNIT_NUMBER BETWEEN
					 * 80901300 AND 80901399 ) OR (T.UNIT_NUMBER BETWEEN 80703999 AND 80703000 ) OR
					 * (T.UNIT_NUMBER BETWEEN 80850000 AND 80889999 ) OR (T.UNIT_NUMBER BETWEEN
					 * 80704000 AND 80704999 ) OR (T.UNIT_NUMBER IN
					 * (80110000,80111300,80341111,80242011,80242012
					 * ,80242013,80242021,80242022,80242032,80181111,80241621))
					 * 
					 * ) AND (NOT (T.UNIT_NUMBER = 80901177 OR T.UNIT_NUMBER = 79400321 OR
					 * T.UNIT_NUMBER =80901189))
					 */
					// if ( ((employerNumber >= 80120000) & (employerNumber <=
					// 80120000)) |
					// ((employerNumber >= 80550000) & (employerNumber <=
					// 80559999)) |
					// ((employerNumber >= 80600000) & (employerNumber <=
					// 80609999)) |
					// ((employerNumber >= 79100101) & (employerNumber <=
					// 79499999)) |
					// ((employerNumber >= 99100001) & (employerNumber <=
					// 99199999)) |
					// ((employerNumber >= 80110000) & (employerNumber <=
					// 80119999)) |
					// ((employerNumber >= 80901100) & (employerNumber <=
					// 80901199)) |
					// ((employerNumber >= 80901300) & (employerNumber <=
					// 80901399)) |
					// ((employerNumber >= 80703999) & (employerNumber <=
					// 80703000)) |
					// ((employerNumber >= 80850000) & (employerNumber <=
					// 80889999)) |
					// ((employerNumber >= 80704000) & (employerNumber <=
					// 80704999)) &
					// (employerNumber == 80110000) | (employerNumber ==
					// 80111300) | (employerNumber == 80341111) |
					// (employerNumber == 80242011) | (employerNumber ==
					// 80242012) | (employerNumber ==
					// 80242013) |
					// (employerNumber == 80242021) | (employerNumber ==
					// 80242022) | (employerNumber == 80242032) |
					// (employerNumber == 80181111) | (employerNumber ==
					// 80241621) &
					// (employerNumber != 80901177) & (employerNumber !=
					// 79400321) & (employerNumber != 80901189 ))
					isMilitary = MilitaryUnitNumbersList.contains(employerNumber)
							&& employment2.getEmployerType().equals(CRSConstants.EntityType.UNIT);

					if (logger.isDebugEnabled()) {
						logger.debug("isMilitaryCpr() -  : employerNumber = " + employerNumber);
					}
				} // end for
			}
		} catch (org.springframework.dao.EmptyResultDataAccessException exception) {
			throw new ApplicationExceptionInfo(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
					new ApplicationException(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
							ERROR_CPR_NOT_FOUND_CODE));
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo(ERROR_RESTRICTED_CPR,
					new ApplicationException(ERROR_RESTRICTED_CPR, ERROR_RESTRICTED_CPR_CODE));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("isMilitaryCpr(Integer) - end");
		}
		return isMilitary;
	}

	public boolean isBDFEmployeeCpr(Integer cprNumber) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("isMilitaryCpr(Integer) - start");
		}
		final Integer[] MilitaryUnitNumbers = new Integer[] {

				80120000, // MINISTRY OF DEFENCE
				80121100, // MINISTER OF STATE FOR DEFENSE OFFICE
				80121500, // BAHRAIN DEFENCE FORCE HEAD QUARTER
				80121700, // PERSONNAL &OFFICERS DIR./MINISTRY OF DEFENCE
				80122100, // MEDICAL SERVICES HEADQUARTERS
				80122101, // MILITARY HOSPITAL
				80122111, // THE AMIRI ACADEMY OF MEDICAL SPECIALISTS
				80124200, // MILITARY SPORTS ASSOCIATION
				80128800, // MILITARY CONSUMERS ASSOCIATION
				80129000, // SH.ISA AIRBASE
				80129100, // ROYAL BAHRAINI AIR FORCE
				80121000, // ADJUTANT GENERAL OF DEFENSE FORCE OFFICE
				80122121, // MOHAMMED BIN KHALIFA BIN SULMAN AL KHALIFA CARDIAC
							// CENTRE
				80225900 // KING HAMAD UNIVERSITY HOSPITAL
		};
		final List<Integer> MilitaryUnitNumbersList = Arrays.asList(MilitaryUnitNumbers);
		boolean isMilitary = false;
		try {
			final List<Employment> employment = getCrsService().getEmploymentServiceRef()
					.getActiveEmployments(cprNumber);
			// @SuppressWarnings("unchecked")
			// List<Employment> military =
			// getCrsService().getEmploymentService().getMilitryUnits();
			// employment.retainAll(military);
			if (employment != null) {
				for (final Employment employment2 : employment) {
					final Employment currentEmployement = employment2;
					final Integer employerNumber = currentEmployement.getEmployerNumber();

					if (logger.isDebugEnabled()) {
						logger.debug("isMilitaryCpr(cprNumber = " + cprNumber + ") -  : employerNumber = "
								+ employerNumber + " -  : employerType = " + employment2.getEmployerType());
					}
					isMilitary = MilitaryUnitNumbersList.contains(employerNumber)
							&& employment2.getEmployerType().equals(CRSConstants.EntityType.UNIT);

					if (logger.isDebugEnabled()) {
						logger.debug("isMilitaryCpr() -  : employerNumber = " + employerNumber);
					}
				} // end for
			}
		} catch (org.springframework.dao.EmptyResultDataAccessException exception) {
			throw new ApplicationExceptionInfo(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
					new ApplicationException(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
							ERROR_CPR_NOT_FOUND_CODE));
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo(ERROR_RESTRICTED_CPR,
					new ApplicationException(ERROR_RESTRICTED_CPR, ERROR_RESTRICTED_CPR_CODE));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("isMilitaryCpr(Integer) - end");
		}
		return isMilitary;
	}

	public boolean isValidCpr(Integer cprNumber) throws ApplicationExceptionInfo {
		if (logger.isTraceEnabled()) {
			logger.debug("isValidCpr(Integer) - start");
		}

		if (logger.isTraceEnabled()) {
			logger.debug("isValidCpr(cprNumber = " + cprNumber + ")");
		}

		boolean isValid = false;
		try {
			isValid = getCrsService().getPersonServiceRef().isValidCpr(cprNumber);
			if (logger.isTraceEnabled()) {
				logger.debug("isValidCpr() -  : isValid = " + isValid);
			}
		} catch (org.springframework.dao.EmptyResultDataAccessException exception) {
			throw new ApplicationExceptionInfo(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
					new ApplicationException(ERROR_CPR_NOT_FOUND.replaceAll("\\?", cprNumber + ""),
							ERROR_CPR_NOT_FOUND_CODE));
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo("CPR Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isTraceEnabled()) {
			logger.debug("isValidCpr(Integer) - end");
		}
		return isValid;
	}

	public boolean crHasValidExpiryData(Integer crNumber, Date crExpiryDate) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("crHasValidExpiryData(Integer, Date) - start");
		}

		// PersonSummary personSummary =
		// getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
		boolean isValid = false;
		try {
			final CRDetails crDetails = getCrsService().getUnitServiceRef().getCrBasicInfo(crNumber);

			if (crDetails != null) {

				final Date dbCRExpiryDate = CRSUtils.getDateFromTimestamp(crDetails.getLicenseExpiryDate());

				if (logger.isDebugEnabled()) {
					logger.debug("crHasValidExpiryData() -  : dbCardExpiryDate = " + dbCRExpiryDate);
					logger.debug("crHasValidExpiryData() -  : cardExpiryDate = " + crExpiryDate);
				}

				if (dbCRExpiryDate != null && dbCRExpiryDate.equals(crExpiryDate)) {
					isValid = true;
				}
			}

		} catch (final Exception exception) {
			throw new ApplicationExceptionInfo("CR Expiry Date Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("crHasValidExpiryData(Integer, Date) - end");
		}
		return isValid;
	}

	public boolean crHasValidBlockData(Integer crNumber, Integer blockNumber) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("crHasValidBlockData(Integer, Integer) - start");
		}

		// PersonSummary personSummary =
		// getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
		boolean isValid = false;
		try {
			final CRDetails crDetails = getCrsService().getUnitServiceRef().getCrBasicInfo(crNumber);

			if (crDetails != null) {

				final Integer dbCRBlockNumber = crDetails.getBlock();

				logger.debug("crHasValidBlockData() -  : dbBlockNumber = " + dbCRBlockNumber);
				logger.debug("crHasValidBlockData() -  : blockNumber = " + blockNumber);

				if (dbCRBlockNumber.equals(blockNumber)) {
					isValid = true;
				}
			}

		} catch (final Exception exception) {
			throw new ApplicationExceptionInfo("CR Block Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("crHasValidBlockData(Integer, Integer) - end");
		}
		return isValid;
	}

	public boolean isCrActive(Integer crNumber) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("isCrActive(Integer) - start");
		}

		boolean isActive = false;
		try {
			isActive = getCrsService().getUnitServiceRef().getCrBasicInfo(crNumber).getIsActive().equalsIgnoreCase("F")
					? false
					: true;
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo("Inactive CR Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("isCrActive(Integer) - end");
		}
		return isActive;
	}

	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	public ArrayList<Address> getCPRNumberBlock(Integer cprNumber) throws ApplicationExceptionInfo {
		ArrayList<Address> address = new ArrayList<Address>();
		try {
			final List<Address> personAddress = getCrsService().getAddressServiceRef().getAddressDetails(cprNumber);
			for (final Address pAddress : personAddress) {
				address.add((pAddress));
				if (logger.isDebugEnabled()) {
					logger.debug("getCPRNumberBlock(blockNumber = " + address + ") -  : dbBlockNumber = " + address
							+ ", personAddress = " + pAddress);
				}

			}

		} catch (final Exception exception) {
			throw new ApplicationExceptionInfo("Block Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		return address;
	}

	public Date getCPRNumberExpiry(Integer cprNumber) throws ApplicationExceptionInfo {
		Date expiry = null;

		try {
			final List<CPRCard> personCPRs = getCrsService().getPersonServiceRef().getPersonCPRs(cprNumber);
			final List<Smartcard> personSmartcards = getCrsService().getPersonServiceRef()
					.getActivePersonSmartcards(cprNumber);

			logger.debug("getCPRNumberExpiry() -  : personSmartcards.size() = {}", personSmartcards.size());
			logger.debug("getCPRNumberExpiry() -  : personCPRs.size() = {}", personCPRs.size());
			if (personSmartcards.size() != 0) {

				expiry = CRSUtils
						.getDateFromTimestamp(personSmartcards.get(personSmartcards.size() - 1).getExpiryDate());

			} else {
				if (personCPRs.size() != 0)
					expiry = CRSUtils.getDateFromTimestamp(personCPRs.get(personCPRs.size() - 1).getExpiryDate());
			}

			if (logger.isDebugEnabled()) {
				logger.debug("getCPRNumberExpiry() -  : dbCardExpiryDate = " + expiry);
			}
		} catch (final Exception exception) {
			// exception.printStackTrace();
			throw new ApplicationExceptionInfo("Card Expiry Date Validation General Exception",
					new ApplicationException(exception.getMessage()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("hasValidExpiryCardData(Integer, Date) - end");
		}
		return expiry;
	}

	public boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID,
			String eKeyTimestamp) {
		ValidateToken eKey = crsService.geteKeyServiceRef();
		String accessPassword = propImpl.geteGOVeKeyPassword();
		String response = null;
		CryptoUtil cryptoUtil = new CryptoUtil();
		try {
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber),
					cryptoUtil.encrypt(eKeyServiceID), cryptoUtil.encrypt(eKeyTokenID),
					cryptoUtil.encrypt(eKeyTimestamp));

			response = cryptoUtil.decrypt(response);

			logger.debug("eKey Response:" + response);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));

	}

}
