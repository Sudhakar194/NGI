package bh.gov.cio.integration.crs.retrieve.nhra.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.nhra.service.dto.NHRABasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NHRABasicInfoService", targetNamespace = "http://service.nhra.retrieve.crs.integration.cio.gov.bh/")
public interface NHRABasicInfoServiceInterface {

	@WebResult(name = "NHRABasicInfo")
	@WebMethod(operationName = "getNHRABasicInfo")
	NHRABasicInfoDTO getNHRABasicInfo(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String nationalityCode,
			@WebParam(name = "BlobkNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "CardExpiryDate") @XmlElement(required = true) Date cardExpiryDate)
			throws ApplicationExceptionInfo;
}