package bh.gov.cio.integration.crs.retrieve.address.service;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.address.service.dto.RoadSearchInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "RoadSearchService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
public interface RoadSearchServiceInterface
{
	@WebResult(name = "RoadsResult")
	@WebMethod(operationName = "searchRoadInformationByName")
	List<RoadSearchInfoDTO> searchRoadInformationByName(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "roadName") @XmlElement(required = true) String roadName) throws ApplicationExceptionInfo;


}
