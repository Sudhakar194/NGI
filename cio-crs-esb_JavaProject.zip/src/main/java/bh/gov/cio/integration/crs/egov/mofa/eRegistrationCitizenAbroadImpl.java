package bh.gov.cio.integration.crs.egov.mofa;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.person.GDNPRDocument;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.mofa.service.eRegistrationCitizenAbroadInterface;
import bh.gov.cio.integration.crs.egov.mofa.service.dto.eRegistrationCitizenAbroadDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "EregistrationCitizenAbroadService", targetNamespace = "http://service.mofa.egov.crs.integration.cio.gov.bh/")
public class eRegistrationCitizenAbroadImpl implements eRegistrationCitizenAbroadInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(eRegistrationCitizenAbroadImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	@Autowired
	private PropertyServiceImpl	propImpl;
	private boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp)
	{
		ValidateToken eKey = crsService.geteKeyServiceRef();
		String accessPassword = propImpl.geteGOVeKeyPassword();
		String response = null;
		CryptoUtil cryptoUtil = new CryptoUtil();
		try
		{
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber), cryptoUtil.encrypt(eKeyServiceID),
					cryptoUtil.encrypt(eKeyTokenID), cryptoUtil.encrypt(eKeyTimestamp));
			response = cryptoUtil.decrypt(response);
			logger.debug("eKey Response:" + response);
		}
		catch (Exception e)
		{

			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));

	}
	


	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@Override
	@Secured(
	{ "ROLE_registeredCitizenAbroad" })
	@WebMethod(operationName = "registeredCitizenAbroad")
	public eRegistrationCitizenAbroadDTO registeredCitizenAbroad(SecurityTagObject security, Integer cprNumber, String eKeyCPRNumber,
			String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp) throws ApplicationExceptionInfo
	{
		eRegistrationCitizenAbroadDTO personMOFADTO = null;

		if (logger.isDebugEnabled())
		{
			logger.debug("registeredCitizenAbroad(Integer,String,String,String,String) - start");
		}

		if (!checkeKeyResponse(eKeyCPRNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp))
		{
			throw new ApplicationExceptionInfo("Error in retrieving data...", new ApplicationException("Authentication Failed.", "001"));
		}
		try
		{
			if (validationUtil.isDeletedCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("CPR Number Deleted.", new ApplicationException("CPR Number Deleted.", "005"));
			}
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final GDNPRDocument gdnprDocument = getCrsService().getGDNPRServiceRef().getPersonLatestGDNPRDocument(cprNumber);

			personMOFADTO = new eRegistrationCitizenAbroadDTO(personBasicInfo.getPersonDisplayName(), personSummeryInfo.getArabicFullName(),
					personSummeryInfo.getArabicFirstName(), personSummeryInfo.getArabicMiddleName1(), personSummeryInfo.getArabicMiddleName2(),
					personSummeryInfo.getArabicMiddleName3(), personSummeryInfo.getArabicMiddleName4(), personSummeryInfo.getArabicFamilyName(),
					personSummeryInfo.getEnglishFullName(), personSummeryInfo.getEnglishFirstName(), personSummeryInfo.getEnglishMiddleName1(),
					personSummeryInfo.getEnglishMiddleName2(), personSummeryInfo.getEnglishMiddleName3(), personSummeryInfo.getEnglishMiddleName4(),
					personSummeryInfo.getEnglishFamilyName(), personSummeryInfo.isBahraini(), gdnprDocument.getDocumentNumber());

			if (logger.isDebugEnabled())
			{
				logger.debug("registeredCitizenAbroad(Integer,String,String,String,String) - end");
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("registeredCitizenAbroad(Integer,String,String,String,String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found.", new ApplicationException("Person Basic Details Not found.", "002"));
		}

		return personMOFADTO;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
