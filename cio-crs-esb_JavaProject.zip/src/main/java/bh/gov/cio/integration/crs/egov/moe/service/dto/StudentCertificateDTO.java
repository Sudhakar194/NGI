package bh.gov.cio.integration.crs.egov.moe.service.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "StudentInformation", propOrder = { "idNumber", "englishName",
		"arabicName", "nationality", "dateOfBirth", "passportNumber",
		"passportExpiryDate", "flatNumber", "buildingNumber", "blockNumber",
		"nameAlphaEnglish", "nameAlphaArabic", "roadNumber", "roadNameArabic",
		"roadNameEnglish", "areaCode", "areaNameArabic", "areaNameEnglish",
		"gender" })
public class StudentCertificateDTO {

	public StudentCertificateDTO() {
	}

	private String idNumber;
	private String englishName;
	private String arabicName;
	private String nationality;
	private Date dateOfBirth;
	private String passportNumber;
	private Date passportExpiryDate;
	private Integer flatNumber;
	private Integer buildingNumber;
	private Integer blockNumber;
	private String nameAlphaEnglish;
	private String nameAlphaArabic;
	private Integer roadNumber;
	private String roadNameArabic;
	private String roadNameEnglish;
	private Integer areaCode;
	private String areaNameArabic;
	private String areaNameEnglish;
	private String gender;

	public StudentCertificateDTO(String idNumber, String englishName,
			String arabicName, String nationality, Date dateOfBirth,
			String passportNumber, Date passportExpiryDate, Integer flatNumber,
			Integer buildingNumber, Integer blockNumber,
			String nameAlphaEnglish, String nameAlphaArabic,
			Integer roadNumber, String roadNameArabic, String roadNameEnglish,
			Integer areaCode, String areaNameArabic, String areaNameEnglish,
			String gender) {
		super();
		this.idNumber = idNumber;
		this.englishName = englishName;
		this.arabicName = arabicName;
		this.nationality = nationality;
		this.dateOfBirth = dateOfBirth;
		this.passportNumber = passportNumber;
		this.passportExpiryDate = passportExpiryDate;
		this.flatNumber = flatNumber;
		this.buildingNumber = buildingNumber;
		this.blockNumber = blockNumber;
		this.nameAlphaEnglish = nameAlphaEnglish;
		this.nameAlphaArabic = nameAlphaArabic;
		this.roadNumber = roadNumber;
		this.roadNameArabic = roadNameArabic;
		this.roadNameEnglish = roadNameEnglish;
		this.areaCode = areaCode;
		this.areaNameArabic = areaNameArabic;
		this.areaNameEnglish = areaNameEnglish;
		this.gender = gender;
	}

	@XmlElement(name = "IDNumber")
	public String getIdNumber() {
		return idNumber;
	}

	@XmlElement(name = "EnglishName")
	public String getEnglishName() {
		return englishName;
	}

	@XmlElement(name = "ArabicName")
	public String getArabicName() {
		return arabicName;
	}

	@XmlElement(name = "Nationality")
	public String getNationality() {
		return nationality;
	}

	@XmlElement(name = "DateOfBirth")
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	@XmlElement(name = "PassportNumber")
	public String getPassportNumber() {
		return passportNumber;
	}

	@XmlElement(name = "PassportExpiryDate")
	public Date getPassportExpiryDate() {
		return passportExpiryDate;
	}

	@XmlElement(name = "FlatNumber")
	public Integer getFlatNumber() {
		return flatNumber;
	}

	@XmlElement(name = "BuildingNumber")
	public Integer getBuildingNumber() {
		return buildingNumber;
	}

	@XmlElement(name = "BlockNumber")
	public Integer getBlockNumber() {
		return blockNumber;
	}

	@XmlElement(name = "NameAlphaEnglish")
	public String getNameAlphaEnglish() {
		return nameAlphaEnglish;
	}

	@XmlElement(name = "NameAlphaArabic")
	public String getNameAlphaArabic() {
		return nameAlphaArabic;
	}

	@XmlElement(name = "RoadNumber")
	public Integer getRoadNumber() {
		return roadNumber;
	}

	@XmlElement(name = "RoadNameArabic")
	public String getRoadNameArabic() {
		return roadNameArabic;
	}

	@XmlElement(name = "RoadNameEnglish")
	public String getRoadNameEnglish() {
		return roadNameEnglish;
	}

	@XmlElement(name = "AreaCode")
	public Integer getAreaCode() {
		return areaCode;
	}

	@XmlElement(name = "AreaNameArabic")
	public String getAreaNameArabic() {
		return areaNameArabic;
	}

	@XmlElement(name = "AreaNameEnglish")
	public String getAreaNameEnglish() {
		return areaNameEnglish;
	}

	@XmlElement(name = "Gender")
	public String getGender() {
		return gender;
	}

	public void setCprNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public void setPassportExpiryDate(Date passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	public void setFlatNumber(Integer flatNumber) {
		this.flatNumber = flatNumber;
	}

	public void setBuildingNumber(Integer buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}

	public void setNameAlphaEnglish(String nameAlphaEnglish) {
		this.nameAlphaEnglish = nameAlphaEnglish;
	}

	public void setNameAlphaArabic(String nameAlphaArabic) {
		this.nameAlphaArabic = nameAlphaArabic;
	}

	public void setRoadNumber(Integer roadNumber) {
		this.roadNumber = roadNumber;
	}

	public void setRoadNameArabic(String roadNameArabic) {
		this.roadNameArabic = roadNameArabic;
	}

	public void setRoadNameEnglish(String roadNameEnglish) {
		this.roadNameEnglish = roadNameEnglish;
	}

	public void setAreaCode(Integer areaCode) {
		this.areaCode = areaCode;
	}

	public void setAreaNameArabic(String areaNameArabic) {
		this.areaNameArabic = areaNameArabic;
	}

	public void setAreaNameEnglish(String areaNameEnglish) {
		this.areaNameEnglish = areaNameEnglish;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
}
