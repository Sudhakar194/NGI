package bh.gov.cio.integration.common.admin.model;

public class UserRole {
	private String username;
	private String rolename;

	public String getUsername() {
		return username;
	}

	public String getRolename() {
		return rolename;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	@Override
	public String toString() {
		return "UserRoles [username=" + username + ", rolename=" + rolename + "]";
	}
}
