package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "OrphanServiceBasicInfo", propOrder =
{ "applicantFullArabicName", "applicantFullEnglishName", "applicantGender", "applicantEmploymentStatusCode","applicantDateOfBirth", "applicantNoOfChildren", "applicantAddresses", "childrenDetails"})
public class OrphanServiceBasicInfoDTO
{
	private String applicantFullArabicName;
	private String applicantFullEnglishName;
	private String applicantGender;
	private List<OrphanApplicantAddressDTO>  applicantAddresses;
	private String applicantEmploymentStatusCode;
	private String applicantDateOfBirth;
	private Integer applicantNoOfChildren;
	private List<OrphanChildrensDetailsDTO> childrenDetails;
	public OrphanServiceBasicInfoDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public OrphanServiceBasicInfoDTO(String applicantFullArabicName, String applicantFullEnglishName, String applicantGender, List<OrphanApplicantAddressDTO> applicantAddresses, String applicantEmploymentStatusCode, String dateOfBirth,
			Integer noOfChildren, List<OrphanChildrensDetailsDTO> childrenDetails)
	{
		super();
		this.applicantFullArabicName = applicantFullArabicName != null ? applicantFullArabicName: "";
		this.applicantFullEnglishName = applicantFullEnglishName != null ? applicantFullEnglishName: "";
		this.applicantGender = applicantGender != null ? applicantGender: "";
		this.applicantAddresses = applicantAddresses != null ? applicantAddresses: new ArrayList<OrphanApplicantAddressDTO>();
		this.applicantEmploymentStatusCode = applicantEmploymentStatusCode != null ? applicantEmploymentStatusCode : "";
		this.applicantDateOfBirth = dateOfBirth != null ? dateOfBirth: "";
		this.applicantNoOfChildren = noOfChildren != null ? noOfChildren: 0;
		this.childrenDetails = childrenDetails != null ? childrenDetails: new ArrayList<OrphanChildrensDetailsDTO>();
	}
	@XmlElement(name = "ApplicantFullArabicName")
	public String getApplicantFullArabicName()
	{
		return applicantFullArabicName;
	}
	@XmlElement(name = "ApplicantFullEnglishName")
	public String getApplicantFullEnglishName()
	{
		return applicantFullEnglishName;
	}
	@XmlElement(name = "ApplicantGender")
	public String getApplicantGender()
	{
		return applicantGender;
	}
	@XmlElement(name = "ApplicantAddresses")
	public List<OrphanApplicantAddressDTO> getApplicantAddresses()
	{
		return applicantAddresses;
	}
	@XmlElement(name = "ApplicantDateOfBirth")
	public String getApplicantDateOfBirth()
	{
		return applicantDateOfBirth;
	}
	@XmlElement(name = "ApplicantNoOfChildren")
	public Integer getApplicantNoOfChildren()
	{
		return applicantNoOfChildren;
	}
	@XmlElement(name = "ChildrenDetails")
	public List<OrphanChildrensDetailsDTO> getChildrenDetails()
	{
		return childrenDetails;
	}
	@XmlElement(name = "ApplicantEmploymentStatusCode")
	public String getApplicantEmploymentStatusCode()
	{
		return applicantEmploymentStatusCode;
	}
	public void setApplicantFullArabicName(String applicantFullArabicName)
	{
		this.applicantFullArabicName = applicantFullArabicName;
	}
	public void setApplicantFullEnglishName(String applicantFullEnglishName)
	{
		this.applicantFullEnglishName = applicantFullEnglishName;
	}
	public void setApplicantGender(String applicantGender)
	{
		this.applicantGender = applicantGender;
	}
	public void setApplicantAddresses(List<OrphanApplicantAddressDTO> applicantAddresses)
	{
		this.applicantAddresses = applicantAddresses;
	}
	public void setApplicantDateOfBirth(String dateOfBirth)
	{
		this.applicantDateOfBirth = dateOfBirth;
	}
	public void setApplicantNoOfChildren(Integer noOfChildren)
	{
		this.applicantNoOfChildren = noOfChildren;
	}
	public void setChildrenDetails(List<OrphanChildrensDetailsDTO> childrenDetails)
	{
		this.childrenDetails = childrenDetails;
	}
	public void setApplicantEmploymentStatusCode(String applicantEmploymentStatusCode)
	{
		this.applicantEmploymentStatusCode = applicantEmploymentStatusCode;
	}
}
