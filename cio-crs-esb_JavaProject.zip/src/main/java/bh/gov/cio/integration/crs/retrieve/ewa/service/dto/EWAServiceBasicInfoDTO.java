package bh.gov.cio.integration.crs.retrieve.ewa.service.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;

@XmlType(name = "EWABasicInformatoin", propOrder = { "arabicFirstName", "arabicMiddleName1", "arabicMiddleName2",
		"arabicMiddleName3", "arabicMiddleName4", "arabicFamilyName", "englishFirstName", "englishMiddleName1",
		"englishMiddleName2", "englishMiddleName3", "englishMiddleName4", "englishFamilyName", "nationalityIndicator",
		"gender", "dead", "domestic", "adult", "smartCardExpired"

})
public class EWAServiceBasicInfoDTO implements Serializable, CommonTypes {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3364963642739242914L;

	private String arabicFirstName, arabicMiddleName1, arabicMiddleName2, arabicMiddleName3, arabicMiddleName4,
			arabicFamilyName;
	private String englishFirstName, englishMiddleName1, englishMiddleName2, englishMiddleName3, englishMiddleName4,
			englishFamilyName;

	private Nationality nationalityIndicator;
	private Gender gender;
	private Boolean dead, domestic, adult, smartCardExpired;

	public EWAServiceBasicInfoDTO() {
		super();
	}

	public EWAServiceBasicInfoDTO(String arabicFirstName, String arabicMiddleName1, String arabicMiddleName2,
			String arabicMiddleName3, String arabicMiddleName4, String arabicFamilyName, String englishFirstName,
			String englishMiddleName1, String englishMiddleName2, String englishMiddleName3, String englishMiddleName4,
			String englishFamilyName, Nationality nationalityIndicator, Gender gender, Boolean dead, Boolean domestic,
			Boolean adult, Boolean smartCardExpired) {
		super();
		this.arabicFirstName = arabicFirstName != null ? arabicFirstName : "";
		this.arabicMiddleName1 = arabicMiddleName1 != null ? arabicMiddleName1 : "";
		this.arabicMiddleName2 = arabicMiddleName2 != null ? arabicMiddleName2 : "";
		this.arabicMiddleName3 = arabicMiddleName3 != null ? arabicMiddleName3 : "";
		this.arabicMiddleName4 = arabicMiddleName4 != null ? arabicMiddleName4 : "";
		this.arabicFamilyName = arabicFamilyName != null ? arabicFamilyName : "";
		this.englishFirstName = englishFirstName != null ? englishFirstName : "";
		this.englishMiddleName1 = englishMiddleName1 != null ? englishMiddleName1 : "";
		this.englishMiddleName2 = englishMiddleName2 != null ? englishMiddleName2 : "";
		this.englishMiddleName3 = englishMiddleName3 != null ? englishMiddleName3 : "";
		this.englishMiddleName4 = englishMiddleName4 != null ? englishMiddleName4 : "";
		this.englishFamilyName = englishFamilyName != null ? englishFamilyName : "";
		this.nationalityIndicator = nationalityIndicator;
		this.gender = gender;
		this.dead = dead;
		this.domestic = domestic;
		this.adult = adult;
		this.smartCardExpired = smartCardExpired;
	}

	public Nationality getNationalityIndicator() {
		return nationalityIndicator;
	}

	public void setNationalityIndicator(Nationality nationalityIndicator) {
		this.nationalityIndicator = nationalityIndicator;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Boolean getDead() {
		return dead;
	}

	public void setDead(Boolean dead) {
		this.dead = dead;
	}

	public Boolean getDomestic() {
		return domestic;
	}

	public void setDomestic(Boolean domestic) {
		this.domestic = domestic;
	}

	public Boolean getAdult() {
		return adult;
	}

	public void setAdult(Boolean adult) {
		this.adult = adult;
	}

	public Boolean getSmartCardExpired() {
		return smartCardExpired;
	}

	public void setSmartCardExpired(Boolean smartCardExpired) {
		this.smartCardExpired = smartCardExpired;
	}

	public String getArabicFirstName() {
		return arabicFirstName;
	}

	public void setArabicFirstName(String arabicFirstName) {
		this.arabicFirstName = arabicFirstName;
	}

	public String getArabicMiddleName1() {
		return arabicMiddleName1;
	}

	public void setArabicMiddleName1(String arabicMiddleName1) {
		this.arabicMiddleName1 = arabicMiddleName1;
	}

	public String getArabicMiddleName2() {
		return arabicMiddleName2;
	}

	public void setArabicMiddleName2(String arabicMiddleName2) {
		this.arabicMiddleName2 = arabicMiddleName2;
	}

	public String getArabicMiddleName3() {
		return arabicMiddleName3;
	}

	public void setArabicMiddleName3(String arabicMiddleName3) {
		this.arabicMiddleName3 = arabicMiddleName3;
	}

	public String getArabicMiddleName4() {
		return arabicMiddleName4;
	}

	public void setArabicMiddleName4(String arabicMiddleName4) {
		this.arabicMiddleName4 = arabicMiddleName4;
	}

	public String getArabicFamilyName() {
		return arabicFamilyName;
	}

	public void setArabicFamilyName(String arabicFamilyName) {
		this.arabicFamilyName = arabicFamilyName;
	}

	public String getEnglishFirstName() {
		return englishFirstName;
	}

	public void setEnglishFirstName(String englishFirstName) {
		this.englishFirstName = englishFirstName;
	}

	public String getEnglishMiddleName1() {
		return englishMiddleName1;
	}

	public void setEnglishMiddleName1(String englishMiddleName1) {
		this.englishMiddleName1 = englishMiddleName1;
	}

	public String getEnglishMiddleName2() {
		return englishMiddleName2;
	}

	public void setEnglishMiddleName2(String englishMiddleName2) {
		this.englishMiddleName2 = englishMiddleName2;
	}

	public String getEnglishMiddleName3() {
		return englishMiddleName3;
	}

	public void setEnglishMiddleName3(String englishMiddleName3) {
		this.englishMiddleName3 = englishMiddleName3;
	}

	public String getEnglishMiddleName4() {
		return englishMiddleName4;
	}

	public void setEnglishMiddleName4(String englishMiddleName4) {
		this.englishMiddleName4 = englishMiddleName4;
	}

	public String getEnglishFamilyName() {
		return englishFamilyName;
	}

	public void setEnglishFamilyName(String englishFamilyName) {
		this.englishFamilyName = englishFamilyName;
	}

}
