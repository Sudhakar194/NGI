package bh.gov.cio.integration.crs.lmra;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
//import bh.gov.cio.crs.model.sc.Person;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.util.CRSUtils;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.lmra.dto.HouseHoldInfoDTO;
import bh.gov.cio.integration.crs.lmra.service.ChildrenInfoOfHouseholdDTO;
import bh.gov.cio.integration.crs.lmra.service.HouseHoldInfoServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(targetNamespace = "http://lmra.crs.integration.cio.gov.bh/", portName = "HouseHoldInfoServiceImplPort", serviceName = "HouseHoldInfoServiceImplService")
public class HouseHoldInfoServiceImpl implements HouseHoldInfoServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(HouseHoldInfoServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Autowired
	private ValidationServiceImpl validationUtil;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getHouseHoldInfo" })
	@WebMethod(operationName = "getHouseHoldInfo")
	public HouseHoldInfoDTO getHouseHoldInfo(SecurityTagObject security, String idNumber, String nationalityCode,
			String applicantIdNumber, String applicantNationalityCode) throws ApplicationExceptionInfo {

		final FamilyService familyService = getCrsService().getFamilyServiceRef();

		final PersonService personService = getCrsService().getPersonServiceRef();
		HouseHoldInfoDTO houseHoldInfoDTO = new HouseHoldInfoDTO();
		Integer personCPR = null;
		Integer applicantPersonCPR = null;

		if (logger.isDebugEnabled()) {
			logger.debug("getHouseHoldInfo(String, String, String, String) - start");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getHouseHoldInfo(String idNumber = " + idNumber + ", String nationalityCode = "
					+ nationalityCode + ", String applicantIdNumber = " + applicantIdNumber
					+ ", String applicantNationalityCode = " + applicantNationalityCode + ")");
		}

		// if (nationalityCode.equalsIgnoreCase("411") ||
		// nationalityCode.equalsIgnoreCase("430")
		// || nationalityCode.equalsIgnoreCase("436") ||
		// nationalityCode.equalsIgnoreCase("440")
		// || nationalityCode.equalsIgnoreCase("930") ||
		// nationalityCode.equalsIgnoreCase("441")
		// || nationalityCode.equalsIgnoreCase("940"))
		// {
		personCPR = validationUtil.getGCCCpr(idNumber, nationalityCode);
		// }
		// else
		// {
		// try
		// {
		// personCPR = Integer.parseInt(idNumber);
		// }
		// catch (Exception exception)
		// {
		// exception.printStackTrace();
		// }
		// }

		try {
			PersonBasicInfo personBasicInfo = personService.getPersonBasicInfo(personCPR);
			PersonSummary personSummary = personService.getPersonSummary(personCPR);

			if (personBasicInfo != null) {

				// if(personBasicInfo.getNationalityCode().equals("499"))
				// throw new ApplicationExceptionInfo("Can't Process Bahraini
				// Information:", new ApplicationException("Can't Process
				// Bahraini Information"));;;

				houseHoldInfoDTO.setPersonCpr(idNumber);
				houseHoldInfoDTO.setPersonArabicName(personBasicInfo.getArabicName());
				houseHoldInfoDTO.setPersonEnglishName(personBasicInfo.getEnglishName());
				houseHoldInfoDTO.setGender(personBasicInfo.getGender());
				houseHoldInfoDTO.setBirthDate(CRSUtils.getDateStringFromTimeStamp(personBasicInfo.getDateOfBirth()));
				houseHoldInfoDTO.setLivingStatus(personSummary.isDead() == true ? "F" : "T");
				houseHoldInfoDTO.setMaritalStatus(personSummary.getMaritalStatusCode().equals("002") ? "T" : "F");

				houseHoldInfoDTO.setMaritalStatusCode(personSummary.getMaritalStatusCode());
				int numberOfMarriages = getCrsService().getFamilyServiceRef()
						.getPersonNumberOfActiveMarriages(personCPR);
				houseHoldInfoDTO.setNoOfWives(numberOfMarriages);

				if (logger.isDebugEnabled()) {
					logger.debug("Person Details --- CPR Number: " + personCPR + " Name: "
							+ personBasicInfo.getEnglishName() + "Gender : " + personBasicInfo.getGender()
							+ "Marital Status: " + personSummary.getMaritalStatusCode());
				}
				Address personAddress = getCrsService().getAddressServiceRef().getAddressDetailsByCpr(personCPR);

				/*******************
				 * Check if household is working
				 ***********************/
				String householdWorkingStatus = "F";
				final List<Employment> houseHoldEmployement = getCrsService().getEmploymentServiceRef()
						.getActiveEmployments(personCPR);
				if (houseHoldEmployement.size() != 0) {
					householdWorkingStatus = "T";
				}
				houseHoldInfoDTO.setPersonWorkingStatus(householdWorkingStatus);

				if (personAddress != null) {

					/************ Retrieve Address Details ************/
					houseHoldInfoDTO.setBuildingNumber((personAddress.getBuildingNumber()));
					houseHoldInfoDTO.setBuildingAlphaArabic((personAddress.getNameAlphaArabic()));
					houseHoldInfoDTO.setBuildingAlphaEnglish((personAddress.getNameAlphaEnglish()));

					houseHoldInfoDTO.setFaltNumber((personAddress.getFlatNumber()));
					houseHoldInfoDTO.setBlockNumber((personAddress.getBlockNumber()));
					houseHoldInfoDTO.setRoadNumber((personAddress.getRoadNumber()));

					houseHoldInfoDTO.setAreaArabicName((personAddress.getAreaNameArabic()));
					houseHoldInfoDTO.setAreaEnglishName((personAddress.getAreaNameEnglish()));

					houseHoldInfoDTO.setAddressType(personAddress.getAddressTypeNameEnglish());

					if (logger.isDebugEnabled()) {
						logger.debug("AddressDetails is --- Flat: " + personAddress.getFlatNumber() + "Building: "
								+ personAddress.getBuildingNumber() + "Road: " + personAddress.getRoadNumber()
								+ "Block: " + personAddress.getBlockNumber());
					}

					/************** get person Children ************/
					ArrayList<Integer> childrenCprs = new ArrayList<Integer>();
					final HashMap<Integer, List<PersonSummary>> hm = familyService.getPersonChildrenBySpouse(personCPR);
					final Collection<List<PersonSummary>> wivesList = hm.values();

					if (logger.isDebugEnabled()) {
						logger.debug("getPersonChildrenBySpouse is :" + hm.size());
					}
					int currentChild = 0;
					for (final List<PersonSummary> list : wivesList) {
						final List<PersonSummary> childrenList = list;
						for (final PersonSummary personSummary1 : childrenList) {
							final PersonSummary childrenSummary = personSummary1;

							childrenCprs.add(childrenSummary.getCprNumber());

							currentChild++;

						}
					}

					/***********
					 * check if the children live with the household
					 ********/

					List<Address> allAddressOccupants = new ArrayList<Address>();
					List<Integer> allAddressOccupantsCPR = new ArrayList<Integer>();

					if (logger.isDebugEnabled()) {
						logger.debug("AddressSN is :" + personAddress.getAddressSn());
					}

					allAddressOccupants = getCrsService().getAddressServiceRef()
							.getOccupantsByAddressSn(personAddress.getAddressSn());

					for (final Address address : allAddressOccupants) {
						Address OccupantAddress = address;

						allAddressOccupantsCPR.add(OccupantAddress.getCprNumber());
					}

					boolean childrenSameAddressWithParent = false;
					int noOfChildrenWithLiveWithHouseHold = 0;
					int noOfChildrenWorking = 0;
					if (allAddressOccupants != null) {

						for (int i = 0; i < childrenCprs.size(); i++) {
							if (allAddressOccupantsCPR.contains(childrenCprs.get(i))) {

								if (logger.isDebugEnabled()) {
									logger.debug("person live with his father: " + childrenCprs.get(i));
								}

								noOfChildrenWithLiveWithHouseHold++;
								childrenSameAddressWithParent = true;

								/************
								 * Check if the son/ daughter working
								 ******************/
								if (childrenSameAddressWithParent = true) {
									List<Employment> personEmployement = getCrsService().getEmploymentServiceRef()
											.getActiveEmployments(childrenCprs.get(i));

									PersonSummary ChildrenPersonData = getCrsService().getPersonServiceRef()
											.getPersonSummary(childrenCprs.get(i));
									ChildrenInfoOfHouseholdDTO childrenInfoOfHouseholdDTO = new ChildrenInfoOfHouseholdDTO();

									childrenInfoOfHouseholdDTO.setAge(ChildrenPersonData.getAge());
									childrenInfoOfHouseholdDTO.setGender(ChildrenPersonData.getGender());
									childrenInfoOfHouseholdDTO
											.setWorkingStatus(personEmployement.size() != 0 ? "T" : "F");
									houseHoldInfoDTO.getChildrenInfoOfHouseholds().add(childrenInfoOfHouseholdDTO);

									if (personEmployement.size() != 0) {
										if (logger.isDebugEnabled()) {
											logger.debug("son/ daughter working: " + childrenCprs.get(i));
										}

										noOfChildrenWorking++;
									}
								}

							}
						}

					}

					houseHoldInfoDTO.setNoOfChildren(noOfChildrenWithLiveWithHouseHold);
					houseHoldInfoDTO.setNoOfChildrenWorking(noOfChildrenWorking);

					/*******************
					 * Retrieve Wife CPR
					 ***********************/
					Integer wifeCpr = familyService.getPersonPrimarySpouse(personCPR);
					String wifeWorkingStatus = "F";
					if (wifeCpr != null) {
						/****************
						 * Check if the wife is working
						 ****************/
						List<Employment> wifeEmployement = getCrsService().getEmploymentServiceRef()
								.getActiveEmployments(wifeCpr);
						if (wifeEmployement.size() != 0) {
							wifeWorkingStatus = "T";
							// houseHoldInfoDTO.set
						}

						houseHoldInfoDTO.setSpouseCpr(CRSUtils.getCprString(wifeCpr));
						houseHoldInfoDTO.setSpouseWorkingStatus(wifeWorkingStatus);
					}

					if (logger.isDebugEnabled()) {
						logger.debug("getHouseHoldInfo(String, String, String, String) - end");
					}

				}

				else {
					throw new ApplicationExceptionInfo("Person Address Not found",
							new ApplicationException("Person Address Not found"));
				}

			}

//			if (applicantNationalityCode.equalsIgnoreCase("411") || applicantNationalityCode.equalsIgnoreCase("430")
//					|| applicantNationalityCode.equalsIgnoreCase("436")
//					|| applicantNationalityCode.equalsIgnoreCase("440")
//					|| applicantNationalityCode.equalsIgnoreCase("930")
//					|| applicantNationalityCode.equalsIgnoreCase("441")
//					|| applicantNationalityCode.equalsIgnoreCase("940")) {
				applicantPersonCPR = validationUtil.getGCCCpr(applicantIdNumber, applicantNationalityCode);
//			} else {
//				try {
//					applicantPersonCPR = Integer.parseInt(applicantIdNumber);
//				} catch (Exception exception) {
//					exception.printStackTrace();
//				}
//			}

			try {
				PersonBasicInfo applicantBasicInfo = personService.getPersonBasicInfo(applicantPersonCPR);
				if (applicantBasicInfo != null) {
					houseHoldInfoDTO.setApplicantArabicName(applicantBasicInfo.getArabicName());
					houseHoldInfoDTO.setApplicantEnglishName(applicantBasicInfo.getEnglishName());
				}

			} catch (Exception e) {

				throw new ApplicationExceptionInfo("Applicant details Not found:" + e.getMessage(),
						new ApplicationException("Applicant details Not found:" + e.getMessage()));
			}

		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				exception.printStackTrace();
				logger.error("getHouseHoldInfo(String, String, String, String) Error: " + exception.getMessage());
			}

			throw new ApplicationExceptionInfo("Person Basic Details Not found\n" + exception.getMessage(),
					new ApplicationException(exception.getMessage()));
		}

		return houseHoldInfoDTO;
	}

}
