package bh.gov.cio.integration.crs.lmra;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.EmploymentService;
import bh.gov.cio.crs.service.GDNPRService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.lmra.dto.GetDomesticEmployeeRPDTO;
import bh.gov.cio.integration.crs.lmra.dto.GetForeignerEmployerDTO;
import bh.gov.cio.integration.crs.lmra.dto.IsRunAwayDomesticsEmployeeDTO;
import bh.gov.cio.integration.crs.lmra.service.GetDomesticEmployeeInfoServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GetDomesticEmployeeInfoService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public class GetDomesticEmployeeInfoServiceImpl implements
GetDomesticEmployeeInfoServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(GetDomesticEmployeeInfoServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_GetForeignerEmployer" })
	@WebMethod(operationName = "getForeignerEmployer")
	public GetForeignerEmployerDTO getForeignerEmployer(SecurityTagObject security,Integer employeeCprNumber) throws ApplicationExceptionInfo {

		GetForeignerEmployerDTO getForeignerEmployerDTO = new GetForeignerEmployerDTO();

		final PersonService personService = getCrsService()
				.getPersonServiceRef();
		
		final EmploymentService employmentService = getCrsService().getEmploymentServiceRef();
//		
//		final GDNPRService gdnprService = getCrsService()
//				.getGDNPRServiceRef();
//		
//		GDNPRDocument maidDocument = new GDNPRDocument();
		
		
		
		Integer employerNumber = null;
		
			
			if (logger.isDebugEnabled()) {
				logger.debug("GetForeignerEmployer() - started..........");
			}
			
//			
//			maidDocument = gdnprService.getNonBahrainiLatestDocumentInfo(cprNumber);
//			if(maidDocument!=null){
//				
//				
//				if (logger.isDebugEnabled()) {
//					logger.debug("GetForeignerEmployer() - gdnprService.getNonBahrainiLatestDocumentInfo("+cprNumber+") = "+maidDocument);
//				}
			
			
			PersonSummary summary = null;
			try {
				summary = personService.getPersonSummary(employeeCprNumber);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ApplicationExceptionInfo("Failed Retrieving the Person.",new ApplicationException("Failed Retrieving the Person."));
			}
			
			
			if(summary == null){
				throw new ApplicationExceptionInfo("Person Was Not Found.",new ApplicationException("Person Was Not Found."));
				
			}
			
			
			if(summary.isBahraini() || summary.isGcc()){
			
				if (logger.isDebugEnabled()) {
					logger.debug("GetForeignerEmployer() - Not Foreigner "+summary.getEnglishFullName());
				}
				
				
				throw new ApplicationExceptionInfo("Person ID Not a Foreigner.",new ApplicationException("Person ID Not a Foreigner."));
				
			}
			
			
//				
			
			  Employment employment = null;
			try {
				employment = employmentService.getEmploymentRecord(employeeCprNumber);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ApplicationExceptionInfo("Failed Retrieving Employment.",new ApplicationException("Failed Retrieving Employment."));
			}
				if (employment != null){
					
					if (logger.isDebugEnabled()) {
						logger.debug("GetForeignerEmployer() - Employment is not null");
					}
					
					employerNumber= employment.getEmployerNumber();
					if(employerNumber!=null){
						
						if (logger.isDebugEnabled()) {
							logger.debug("GetForeignerEmployer() - Employer number is not null");
						}
						
						
						PersonSummary person = null;
						try {
							person = personService.getPersonSummary(employerNumber);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							throw new ApplicationExceptionInfo("Failed Retrieving Employer.",new ApplicationException("Failed Retrieving Employer."));
						}
						
						if(person!=null){
							if (logger.isDebugEnabled()) {
								logger.debug("GetForeignerEmployer() - Employer Person is not null "+person.getArabicFirstName());
							}
							
							getForeignerEmployerDTO.setEmployerNumber(employment.getEmployerNumber());
							
							
							
							String nameArabic = employment.getEmployerEN();
							logger.debug("Employer Name Arabic "+employment.getEmployerAN());
							if(nameArabic == null){
								nameArabic = person.getArabicFullName();
								logger.debug("Person Name Arabic "+nameArabic);
								
								if(nameArabic == null){
									
									nameArabic = "";
									
									if(person.getArabicFirstName() != null && !"".equals(person.getArabicFirstName().trim())){
										
									nameArabic = nameArabic + person.getArabicFirstName();
									
									if(person.getArabicMiddleName1() != null && !"".equals(person.getArabicMiddleName1().trim()))
										nameArabic = nameArabic + " "+person.getArabicMiddleName1();
									if(person.getArabicMiddleName2() != null && !"".equals(person.getArabicMiddleName2().trim()))
										nameArabic = nameArabic + " "+person.getArabicMiddleName2();
									if(person.getArabicMiddleName3() != null && !"".equals(person.getArabicMiddleName3().trim()))
										nameArabic = nameArabic + " "+person.getArabicMiddleName3();
									if(person.getArabicMiddleName4() != null && !"".equals(person.getArabicMiddleName4().trim()))
										nameArabic = nameArabic + " "+person.getArabicMiddleName4();
									
									
									if(person.getArabicFamilyName() != null && !"".equals(person.getArabicFamilyName().trim()))
										nameArabic = nameArabic + " "+person.getArabicFamilyName();
									
									
									}
									logger.debug("Name Arabic Collection"+nameArabic);
								}
								
							}
							
							getForeignerEmployerDTO.setEmployerNameAr(nameArabic);
							
							
							String nameEnglish = employment.getEmployerEN();
							logger.debug("Employer Name English "+employment.getEmployerEN());
							if(nameEnglish == null){
								nameEnglish = person.getEnglishFullName();
							logger.debug("Person Name English "+nameEnglish);
							
							if(nameEnglish== null){
								
								nameEnglish = "";
								
								if(person.getEnglishFirstName() != null && !"".equals(person.getEnglishFirstName().trim())){
									
								nameEnglish= nameEnglish+ person.getEnglishFirstName();
								
								if(person.getEnglishMiddleName1() != null && !"".equals(person.getEnglishMiddleName1().trim()))
									nameEnglish= nameEnglish+ " "+person.getEnglishMiddleName1();
								if(person.getEnglishMiddleName2() != null && !"".equals(person.getEnglishMiddleName2().trim()))
									nameEnglish= nameEnglish+ " "+person.getEnglishMiddleName2();
								if(person.getEnglishMiddleName3() != null && !"".equals(person.getEnglishMiddleName3().trim()))
									nameEnglish= nameEnglish+ " "+person.getEnglishMiddleName3();
								if(person.getEnglishMiddleName4() != null && !"".equals(person.getEnglishMiddleName4().trim()))
									nameEnglish= nameEnglish+ " "+person.getEnglishMiddleName4();
								
								
								if(person.getEnglishFamilyName() != null && !"".equals(person.getEnglishFamilyName().trim()))
									nameEnglish= nameEnglish+ " "+person.getEnglishFamilyName();
								
								
								}
								logger.debug("Name English Collection"+nameEnglish);
							}
							
							
							
							
							}
							
							getForeignerEmployerDTO.setEmployerNameEn(nameEnglish);
						
						}else{
							
							if (logger.isDebugEnabled()) {
								logger.debug("GetForeignerEmployer() - employer person is null");
							}
							throw new ApplicationExceptionInfo("Employer Was Not Found.",new ApplicationException("Employer Was Not Found."));
						}
					}
			
				
				}else {
					
					if (logger.isDebugEnabled()) {
						logger.debug("GetForeignerEmployer() - Employment is null");
					}
					
					throw new ApplicationExceptionInfo("Person Employment was not found.",new ApplicationException("Person Employment Was Not Found."));
				}
			
			
//			}
			
			
			
			
	

				
						
			return getForeignerEmployerDTO;
			
	}
	
	
	
	
	
	
	
	
	
	
	@Override
	@Secured({ "ROLE_IsRunAwayDomesticsEmployee" })
	@WebMethod(operationName = "isRunAwayDomesticsEmployee")
	public IsRunAwayDomesticsEmployeeDTO isRunAwayDomesticsEmployee(SecurityTagObject security,Integer employeeCprNumber) throws ApplicationExceptionInfo {

		IsRunAwayDomesticsEmployeeDTO isRunAwayDomesticsEmployeeDTO = new IsRunAwayDomesticsEmployeeDTO();

		final PersonService personService = getCrsService()
				.getPersonServiceRef();
		
		final EmploymentService employmentService = getCrsService().getEmploymentServiceRef();
//		
//		final GDNPRService gdnprService = getCrsService()
//				.getGDNPRServiceRef();
//		
//		GDNPRDocument maidDocument = new GDNPRDocument();
		
		
		
		Integer employerNumber = null;
		
			
			if (logger.isDebugEnabled()) {
				logger.debug("isRunAwayDomesticsEmployee() - started..........");
			}
			
//			
//			maidDocument = gdnprService.getNonBahrainiLatestDocumentInfo(cprNumber);
//			if(maidDocument!=null){
//				
//				
//				if (logger.isDebugEnabled()) {
//					logger.debug("GetForeignerEmployer() - gdnprService.getNonBahrainiLatestDocumentInfo("+cprNumber+") = "+maidDocument);
//				}
			
			
			PersonSummary summary = null;
			try {
				summary = personService.getPersonSummary(employeeCprNumber);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ApplicationExceptionInfo("Failed Retrieving the Person.",new ApplicationException("Failed Retrieving the Person."));
			}
			
			
			if(summary == null){
				throw new ApplicationExceptionInfo("Person Was Not Found.",new ApplicationException("Person Was Not Found."));
				
			}
			
			
			if(summary.isBahraini() || summary.isGcc()){
			
				if (logger.isDebugEnabled()) {
					logger.debug("isRunAwayDomesticsEmployee() - Not Foreigner "+summary.getEnglishFullName());
				}
				
				
				throw new ApplicationExceptionInfo("Person ID Not a Foreigner.",new ApplicationException("Person ID Not a Foreigner."));
				
			}
			
			
//				
			
			  Employment employment = null;
			try {
				employment = employmentService.getEmploymentRecord(employeeCprNumber);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ApplicationExceptionInfo("Failed Retrieving Employment.",new ApplicationException("Failed Retrieving Employment."));
			}
				if (employment != null){
					
					if (logger.isDebugEnabled()) {
						logger.debug("isRunAwayDomesticsEmployee() - Employment is not null");
					}
					
					employerNumber= employment.getEmployerNumber();
					if(employerNumber!=null){
						
						if (logger.isDebugEnabled()) {
							logger.debug("isRunAwayDomesticsEmployee() - Employer number is not null");
						}
						
						
						PersonSummary person = null;
						try {
							person = personService.getPersonSummary(employerNumber);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							throw new ApplicationExceptionInfo("Failed Retrieving Employer.",new ApplicationException("Failed Retrieving Employer."));
						}
						
						if(person!=null){
							if (logger.isDebugEnabled()) {
								logger.debug("GetForeignerEmployer() - Employer Person is not null "+person.getArabicFirstName());
							}
							
							
							
						
						
						
						}else{
							
							if (logger.isDebugEnabled()) {
								logger.debug("isRunAwayDomesticsEmployee() - employer person is null");
							}
							throw new ApplicationExceptionInfo("Employer Was Not Found.",new ApplicationException("Employer Was Not Found."));
						}
					}
			
//					GDNPRDocument document = gdnprService.getGDNPRDocumentFromGDNPRClientForNonBahrainiByCpr(employeeCprNumber);
					
					String watchList = summary.getIsWatchlisted();
					
					isRunAwayDomesticsEmployeeDTO.setIsRunAway(watchList);
					isRunAwayDomesticsEmployeeDTO.setEmployeeCprNumber(summary.getCprNumber());
					
					logger.debug("is watch listed = "+watchList);
				
				}else {
					
					if (logger.isDebugEnabled()) {
						logger.debug("isRunAwayDomesticsEmployee() - Employment is null");
					}
					
					throw new ApplicationExceptionInfo("Person Employment was not found.",new ApplicationException("Person Employment Was Not Found."));
				}
			
			
//			}
			
			
			
			
	

				
						
			return isRunAwayDomesticsEmployeeDTO;
			
	}
	
	@Override
	@Secured({ "ROLE_GetDomesticEmployeeRP" })
	@WebMethod(operationName = "getDomesticEmployeeRP")
	public GetDomesticEmployeeRPDTO getDomesticEmployeeRP(SecurityTagObject security,Integer employeeCprNumber) throws ApplicationExceptionInfo {

		GetDomesticEmployeeRPDTO getDomesticEmployeeRPDTO = new GetDomesticEmployeeRPDTO();

		final PersonService personService = getCrsService()
				.getPersonServiceRef();
		
		final EmploymentService employmentService = getCrsService().getEmploymentServiceRef();
		final GDNPRService gdnprService = getCrsService()
				.getGDNPRServiceRef();

		
		
		
		Integer employerNumber = null;
		
			
			if (logger.isDebugEnabled()) {
				logger.debug("getDomesticEmployeeRP() - started..........");
			}
			

			
			PersonSummary summary = null;
			try {
				summary = personService.getPersonSummary(employeeCprNumber);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ApplicationExceptionInfo("Failed Retrieving the Person.",new ApplicationException("Failed Retrieving the Person."));
			}
			
			
			if(summary == null){
				throw new ApplicationExceptionInfo("Person Was Not Found.",new ApplicationException("Person Was Not Found."));
				
			}
			
			
			if(summary.isBahraini() || summary.isGcc()){
			
				if (logger.isDebugEnabled()) {
					logger.debug("getDomesticEmployeeRP() - Not Foreigner "+summary.getEnglishFullName());
				}
				
				
				throw new ApplicationExceptionInfo("Person ID Not a Foreigner.",new ApplicationException("Person ID Not a Foreigner."));
				
			}
			
			
//				
			
			  Employment employment = null;
			try {
				employment = employmentService.getEmploymentRecord(employeeCprNumber);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ApplicationExceptionInfo("Failed Retrieving Employment.",new ApplicationException("Failed Retrieving Employment."));
			}
				if (employment != null){
					
					if (logger.isDebugEnabled()) {
						logger.debug("getDomesticEmployeeRP() - Employment is not null");
					}
					
					employerNumber= employment.getEmployerNumber();
					if(employerNumber!=null){
						
						if (logger.isDebugEnabled()) {
							logger.debug("getDomesticEmployeeRP() - Employer number is not null");
						}
						
						
						PersonSummary person = null;
						try {
							person = personService.getPersonSummary(employerNumber);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							throw new ApplicationExceptionInfo("Failed Retrieving Employer.",new ApplicationException("Failed Retrieving Employer."));
						}
						
						if(person!=null){
							if (logger.isDebugEnabled()) {
								logger.debug("getDomesticEmployeeRP() - Employer Person is not null "+person.getArabicFirstName());
							}
							
							
							
						
						
						
						}else{
							
							if (logger.isDebugEnabled()) {
								logger.debug("getDomesticEmployeeRP() - employer person is null");
							}
							throw new ApplicationExceptionInfo("Employer Was Not Found.",new ApplicationException("Employer Was Not Found."));
						}
					}
			
					try {
						
						
						
						bh.gov.cio.crs.model.person.ResidencyPermit residencyPermit  = gdnprService.getResidencyPermit(employeeCprNumber);
			
						if(residencyPermit == null || residencyPermit.getPermitNumber() == null || "".equals(residencyPermit.getPermitNumber().trim())){
							
							if (logger.isDebugEnabled()) {
								logger.debug("getDomesticEmployeeRP() - residencyPermit is null");
							}
							throw new ApplicationExceptionInfo("Residency Permit Was Not Found.",new ApplicationException("Residency Permit Was Not Found."));
							
							
						}
						
						
						getDomesticEmployeeRPDTO.setExpiryDate(residencyPermit.getExpiryDate()); 
						getDomesticEmployeeRPDTO.setPermitNumber(residencyPermit.getPermitNumber()); 
						getDomesticEmployeeRPDTO.setFirstArrivalDate(residencyPermit.getFirstArrivalDate()); 
						getDomesticEmployeeRPDTO.setOriginCountry(residencyPermit.getOriginCountry()); 
						getDomesticEmployeeRPDTO.setResidenceReason(residencyPermit.getResidenceReason()); 
						getDomesticEmployeeRPDTO.setResidenceReasonNameArabic(residencyPermit.getResidenceReasonNameArabic()); 
						getDomesticEmployeeRPDTO.setResidenceReasonNameEnglish(residencyPermit.getResidenceReasonNameEnglish()); 
						getDomesticEmployeeRPDTO.setIssueDate(residencyPermit.getIssueDate()); 
						getDomesticEmployeeRPDTO.setIsNoc(residencyPermit.getIsNoc()); 

						if(residencyPermit.isValid())
						getDomesticEmployeeRPDTO.setIsValid("T"); 

						if(!residencyPermit.isValid())
							getDomesticEmployeeRPDTO.setIsValid("F"); 
						
					
					
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						throw new ApplicationExceptionInfo("Failed Retrieiving Residency Permit Info.",new ApplicationException("Failed Retrieiving Residency Permit Info."));
					}
					
					
					
					
				
				}else {
					
					if (logger.isDebugEnabled()) {
						logger.debug("getDomesticEmployeeRP() - Employment is null");
					}
					
					throw new ApplicationExceptionInfo("Person Employment was not found.",new ApplicationException("Person Employment Was Not Found."));
				}
			
			
//			}
			
			
			
			
	

				
						
			return getDomesticEmployeeRPDTO;
			
	}
	
}
