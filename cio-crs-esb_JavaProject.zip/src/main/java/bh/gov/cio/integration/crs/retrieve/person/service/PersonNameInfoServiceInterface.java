package bh.gov.cio.integration.crs.retrieve.person.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServiceNameInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonNameInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface PersonNameInfoServiceInterface
{

	@WebResult(name = "PersonNameInformation")
	@WebMethod(operationName = "getPersonNameInfo")
	PersonServiceNameInfoDTO getPersonNameInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber, @WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "PersonNameInformation")
	@WebMethod(operationName = "getPersonNameInfoByEKey")
	PersonServiceNameInfoDTO getPersonNameInfoByEKey(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "eKeyIDNumber") @XmlElement(required = true) String eKeyIDNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp) throws ApplicationExceptionInfo;

	@WebResult(name = "PersonNameInformation")
	@WebMethod(operationName = "getPersonNameInfoByCPR")
	PersonServiceNameInfoDTO getPersonNameInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

	@WebResult(name = "PersonNameInformation")
	@WebMethod(operationName = "getAllPersonNameInfoByCPR")
	PersonServiceNameInfoDTO getAllPersonNameInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;
}
