package bh.gov.cio.integration.crs.egov.gdt;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.joda.time.DateMidnight;
import org.joda.time.DateTime;
import org.joda.time.Months;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.person.ResidencyPermit;
import bh.gov.cio.crs.model.person.Smartcard;
import bh.gov.cio.crs.model.person.Sponsor;
import bh.gov.cio.crs.service.GDNPRService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.egov.gdt.service.GDTCitizenServiceInterface;
import bh.gov.cio.integration.crs.egov.gdt.service.dto.CitizenStatusDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GDTCitizenService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public class GDTCitizenServiceImpl implements GDTCitizenServiceInterface {

	private static final Logger logger = LoggerFactory.getLogger(GDTCitizenServiceImpl.class);
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_CheckCitizenStatus" })
	@WebMethod(operationName = "CheckCitizenStatus")
	public CitizenStatusDTO CheckCitizenStatus(SecurityTagObject security, Integer idNumber, String eKeyServiceID, String eKeyTokenID,
			String eKeyTimestamp) throws ApplicationExceptionInfo {
		CitizenStatusDTO returned = null;

		if (!checkeKeyResponse(idNumber + "", eKeyServiceID, eKeyTokenID, eKeyTimestamp))
			throw new ApplicationExceptionInfo("Error Checking Citizen Status...", new ApplicationException("Authentication Failed.", "001"));
		try {
			PersonService ps = getCrsService().getPersonServiceRef();
			GDNPRService gdnpr = getCrsService().getGDNPRServiceRef();
			final PersonBasicInfo personBasicInfo = ps.getPersonBasicInfo(idNumber);
			final PersonSummary personSummeryInfo = ps.getPersonSummary(idNumber);
			// check Age Less Than 60
			boolean isAgeLessThan60 = false;
			Integer age = personBasicInfo.getAge();
			if (age < 60)
				isAgeLessThan60 = true;

			// check is bahraini
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499") || personSummeryInfo.getNationalityCountryCode()
					.equals("900")) ? true : false;

			// check GCC
			final boolean isGCC = personSummeryInfo.isGcc();
			// check Smartcard
			boolean hasSmartcard = false;
			final List<Smartcard> personSmartcards = ps.getPersonSmartcards(idNumber);

			if (personSmartcards != null && personSmartcards.size() != 0) {

				hasSmartcard = true;
			}
			// check Valid RP
			ResidencyPermit rp = gdnpr.getResidencyPermit(idNumber);
			boolean hasValidRP = false;
			if (rp != null && rp.isValid()) {
				DateMidnight rpExpiryDate = new DateMidnight(rp.getExpiryDate());
				DateTime now = new DateTime();
				Months rpExpiredIn = Months.monthsBetween(now, rpExpiryDate);
				if (rpExpiredIn.isGreaterThan(Months.ONE))
					hasValidRP = true;
				logger.debug("rp.getExpiryDate()" + rp.getExpiryDate());
				logger.debug("rp.isValid()" + rp.isValid());
			}

			// Sponsor name
			Sponsor sponsor = gdnpr.getPersonSponsor(idNumber);
			String sponorName = sponsor != null ? sponsor.getEnglishName() : "";

			returned = new CitizenStatusDTO(hasSmartcard, isAgeLessThan60, isGCC, hasValidRP, isBahraini, sponorName);

		} catch (final Exception exception) {
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Problem occured while checking citizen details", new ApplicationException(exception.getMessage()));
		}
		return returned;
	}

	private boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp) {
		ValidateToken eKey = getCrsService().geteKeyServiceRef();
		String accessPassword = "w/8WRzqqmdG3TYfxpyWiJltKA+CVkMbM";
		CryptoUtil cryptoUtil = new CryptoUtil();
		String response = null;
		try {
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber), cryptoUtil.encrypt(eKeyServiceID),
					cryptoUtil.encrypt(eKeyTokenID), cryptoUtil.encrypt(eKeyTimestamp));
			response = cryptoUtil.decrypt(response);
			logger.debug("eKey Response:" + response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));
	}

}
