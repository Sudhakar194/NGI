package bh.gov.cio.integration.crs.retrieve.address.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "governorate", propOrder =
{ "code", "message", "governorate" })
public class CheckValidateAddressDTO
{
	private java.lang.String code;
	private java.lang.String message;
	private java.lang.String governorate;

	public CheckValidateAddressDTO()
	{
		super();
	}

	public CheckValidateAddressDTO(String code, String message, String governorate) {
		super();
		this.code = code;
		this.message = message;
		this.governorate = governorate;
	}

	public java.lang.String getCode() {
		return code;
	}

	public void setCode(java.lang.String code) {
		this.code = code;
	}

	public java.lang.String getMessage() {
		return message;
	}

	public void setMessage(java.lang.String message) {
		this.message = message;
	}

	public java.lang.String getGovernorate() {
		return governorate;
	}

	public void setGovernorate(java.lang.String governorate) {
		this.governorate = governorate;
	}

}
