package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "BDFEmployeeInformation", propOrder = { "fatherCPRNumber", "fatherNameArabic", "fatherNameEnglish",
		"motherCPRNumber", "motherNameArabic", "motherNameEnglish", "ioStatus", "maritalStatus", "flat", "bldg",
		"bldgAlpha", "road", "block", "numberOfActiveMarriages", "marriageList", "divorceList", "childrenList" ,"photo"})
public class BDFPersonServiceSummaryDTO {
	private Integer fatherCPRNumber;
	private String fatherNameArabic;
	private String fatherNameEnglish;

	private Integer motherCPRNumber;
	private String motherNameArabic;
	private String motherNameEnglish;

	private Integer numberOfActiveMarriages;
	private String  ioStatus;
	private String maritalStatus;

	private Integer flat;
	private Integer bldg;
	private String bldgAlpha;
	private Integer road;
	private Integer block;

	private byte[] photo;
	
	private BDFPersonMarriageDTO marriageList = new BDFPersonMarriageDTO();
	private BDFPersonDivorceDTO divorceList = new BDFPersonDivorceDTO();
	private BDFPersonChildDTO childrenList = new BDFPersonChildDTO();

	public BDFPersonServiceSummaryDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BDFPersonServiceSummaryDTO(Integer fatherCPRNumber, String fatherNameArabic, String fatherNameEnglish,
			Integer motherCPRNumber, String motherNameArabic, String motherNameEnglish, Integer numberOfActiveMarriages,
			String ioStatus, String maritalStatus, Integer flat, Integer bldg, String bldgAlpha, Integer road,
			Integer block, BDFPersonMarriageDTO marriageList, BDFPersonDivorceDTO divorceList,
			BDFPersonChildDTO childrenList,byte[] photo) {
		super();
		this.fatherCPRNumber = fatherCPRNumber;
		this.fatherNameArabic = fatherNameArabic;
		this.fatherNameEnglish = fatherNameEnglish;
		this.motherCPRNumber = motherCPRNumber;
		this.motherNameArabic = motherNameArabic;
		this.motherNameEnglish = motherNameEnglish;
		this.numberOfActiveMarriages = numberOfActiveMarriages;
		this.ioStatus = ioStatus;
		this.maritalStatus = maritalStatus;
		this.flat = flat;
		this.bldg = bldg;
		this.bldgAlpha = bldgAlpha;
		this.road = road;
		this.block = block;
		this.marriageList = marriageList;
		this.divorceList = divorceList;
		this.childrenList = childrenList;
		this.photo = photo;
	}

	public Integer getFatherCPRNumber() {
		return fatherCPRNumber;
	}

	public void setFatherCPRNumber(Integer fatherCPRNumber) {
		this.fatherCPRNumber = fatherCPRNumber;
	}

	public String getFatherNameArabic() {
		return fatherNameArabic;
	}

	public void setFatherNameArabic(String fatherNameArabic) {
		this.fatherNameArabic = fatherNameArabic;
	}

	public String getFatherNameEnglish() {
		return fatherNameEnglish;
	}

	public void setFatherNameEnglish(String fatherNameEnglish) {
		this.fatherNameEnglish = fatherNameEnglish;
	}

	public Integer getMotherCPRNumber() {
		return motherCPRNumber;
	}

	public void setMotherCPRNumber(Integer motherCPRNumber) {
		this.motherCPRNumber = motherCPRNumber;
	}

	public String getMotherNameArabic() {
		return motherNameArabic;
	}

	public void setMotherNameArabic(String motherNameArabic) {
		this.motherNameArabic = motherNameArabic;
	}

	public String getMotherNameEnglish() {
		return motherNameEnglish;
	}

	public void setMotherNameEnglish(String motherNameEnglish) {
		this.motherNameEnglish = motherNameEnglish;
	}

	public Integer getNumberOfActiveMarriages() {
		return numberOfActiveMarriages;
	}

	public void setNumberOfActiveMarriages(Integer numberOfActiveMarriages) {
		this.numberOfActiveMarriages = numberOfActiveMarriages;
	}

	public String getIoStatus() {
		return ioStatus;
	}

	public void setIoStatus(String ioStatus) {
		this.ioStatus = ioStatus;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Integer getFlat() {
		return flat;
	}

	public void setFlat(Integer flat) {
		this.flat = flat;
	}

	public Integer getBldg() {
		return bldg;
	}

	public void setBldg(Integer bldg) {
		this.bldg = bldg;
	}

	public String getBldgAlpha() {
		return bldgAlpha;
	}

	public void setBldgAlpha(String bldgAlpha) {
		this.bldgAlpha = bldgAlpha;
	}

	public Integer getRoad() {
		return road;
	}

	public void setRoad(Integer road) {
		this.road = road;
	}

	public Integer getBlock() {
		return block;
	}

	public void setBlock(Integer block) {
		this.block = block;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public BDFPersonMarriageDTO getMarriageList() {
		return marriageList;
	}

	public void setMarriageList(BDFPersonMarriageDTO marriageList) {
		this.marriageList = marriageList;
	}

	public BDFPersonDivorceDTO getDivorceList() {
		return divorceList;
	}

	public void setDivorceList(BDFPersonDivorceDTO divorceList) {
		this.divorceList = divorceList;
	}

	public BDFPersonChildDTO getChildrenList() {
		return childrenList;
	}

	public void setChildrenList(BDFPersonChildDTO childrenList) {
		this.childrenList = childrenList;
	}

}
