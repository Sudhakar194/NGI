package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "ChildrenList", propOrder = { "children" })
public class BDFPersonChildDTO {

	private ArrayList<Children> children;
	
	public BDFPersonChildDTO(ArrayList<Children> children) {
		super();
		this.children = children;
	}

	@XmlType(name = "Children", propOrder = { "childCPRNumber", "childNameArabic", "childNameEnglish","hasCR" })
	public static class Children{
		
		
		private Integer childCPRNumber;
		private String childNameArabic;
		private String childNameEnglish;
		private Boolean hasCR;
		
		public Integer getChildCPRNumber() {
			return childCPRNumber;
		}

		public void setChildCPRNumber(Integer childCPRNumber) {
			this.childCPRNumber = childCPRNumber;
		}

		public String getChildNameArabic() {
			return childNameArabic;
		}

		public void setChildNameArabic(String childNameArabic) {
			this.childNameArabic = childNameArabic;
		}

		public String getChildNameEnglish() {
			return childNameEnglish;
		}

		public void setChildNameEnglish(String childNameEnglish) {
			this.childNameEnglish = childNameEnglish;
		}

		public Children(Integer childCPRNumber, String childNameArabic, String childNameEnglish,Boolean hasCR) {
			super();
			this.childCPRNumber = childCPRNumber;
			this.childNameArabic = childNameArabic;
			this.childNameEnglish = childNameEnglish;
			this.hasCR = hasCR;
		}

		public Boolean getHasCR() {
			return hasCR;
		}

		public void setHasCR(Boolean hasCR) {
			this.hasCR = hasCR;
		}

		public Children() {
			super();
			// TODO Auto-generated constructor stub
		}
	}
	
	public BDFPersonChildDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ArrayList<Children> getChildren() {
		return children;
	}

	public void setChildren(ArrayList<Children> children) {
		this.children = children;
	}

}
