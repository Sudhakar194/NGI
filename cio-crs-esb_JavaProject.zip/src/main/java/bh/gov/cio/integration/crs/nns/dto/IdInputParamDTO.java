package bh.gov.cio.integration.crs.nns.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "idsList", propOrder =
{ "idNumber", "cardCountryCode","idType","blockNumber","expiryDate"})
public class IdInputParamDTO {
	private String idNumber;

	private String cardCountryCode;

	private String idType;

	private Integer blockNumber;

	private Date expiryDate;
	
	
	public IdInputParamDTO() {
		super();
	}


	public IdInputParamDTO(String idNumber, String cardCountryCode, String idType, Integer blockNumber,
			Date expiryDate) {
		super();
		this.idNumber = idNumber;
		this.cardCountryCode = cardCountryCode;
		this.idType = idType;
		this.blockNumber = blockNumber;
		this.expiryDate = expiryDate;
	}


	@XmlElement(name = "IdNumber", required = true)
	public String getIdNumber() {
		return idNumber;
	}


	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}


	@XmlElement(name = "CardCountryCode", required = true)
	public String getCardCountryCode() {
		return cardCountryCode;
	}


	public void setCardCountryCode(String cardCountryCode) {
		this.cardCountryCode = cardCountryCode;
	}


	@XmlElement(name = "IdType", required = true)
	public String getIdType() {
		return idType;
	}


	public void setIdType(String idType) {
		this.idType = idType;
	}


	@XmlElement(name = "BlockNumber", required = true)
	public Integer getBlockNumber() {
		return blockNumber;
	}


	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}


	@XmlElement(name = "ExpiryDate", required = true)
	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


}
