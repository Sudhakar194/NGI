package bh.gov.cio.integration.crs.retrieve.person;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.util.exception.AddressLoadException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressServiceBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.WomenBasicInfoForSCWServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.WomenServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "WomenBasicInfoSCWServic", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "WomenBasicInfoSCWServic"
public class WomenBasicInfoSCWServiceImpl implements WomenBasicInfoForSCWServiceInterface
{

	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(WomenBasicInfoSCWServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Autowired
	private ValidationServiceImpl validationUtil;

	@Override
	@Secured(
	{ "ROLE_checkNeedGAC" })
	@WebMethod(operationName = "checkNeedGAC")
	public WomenServiceBasicInfoDTO checkNeedGAC(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{

		PersonService personService = getCrsService().getPersonServiceRef();
		FamilyService familyService = getCrsService().getFamilyServiceRef();
		WomenServiceBasicInfoDTO womenBasicInfoDTO = new WomenServiceBasicInfoDTO();

		if (logger.isDebugEnabled())
		{

			logger.debug("checkNeedGAC(Integer, Integer, Date) - start " + cprNumber + " " + blockNumber + " " + cardExpiryDate);
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}

		try
		{
			final PersonSummary wifePersonSummary = personService.getPersonSummary(cprNumber);
			logger.debug("applicant Gender: " + wifePersonSummary.getGender() + " - Applicant is Bahraini: " + wifePersonSummary.isBahraini());

			/* check if her husband is bahraini */
			final List<Marriage> personMarriages = familyService.getPersonMarriageDivorceList(cprNumber);

			int count = 0;
			boolean husbandIsBahraini = false;
			Integer husbandCPRNumber = null;
			List<PersonSummary> childInfoSummaryList = new ArrayList<PersonSummary>();
			if (personMarriages != null)
			{
				for (final Marriage marriage : personMarriages)
				{
					final Marriage spouse = marriage;
					final PersonSummary spousePersonSummary = personService.getPersonSummary(spouse.getPartnerCprNumber());
					if (logger.isDebugEnabled())
					{
						logger.debug("getPersonDetails()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
					}
					husbandIsBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
							.getNationalityCountryCode().equals("900")) ? true : false;
					husbandCPRNumber = spouse.getPartnerCprNumber();
					logger.debug("Husband CPR: " + husbandCPRNumber + " is Bahraini: " + husbandIsBahraini);
					count++;
				}
				logger.debug("personMarriages.size() " + personMarriages.size());
			}
			try
			{

				childInfoSummaryList = familyService.getCoupleChildren(husbandCPRNumber, cprNumber);
			}

			catch (BusinessException e)
			{
				throw new ApplicationExceptionInfo("Applicant Children ", new ApplicationException("No children for the applicant"));
			}

			if ((wifePersonSummary.getGender().equalsIgnoreCase("M")))
			{
				throw new ApplicationExceptionInfo("Applicant gender ", new ApplicationException(" Applicant not female"));
			}

			// if (!(wifePersonSummary.isBahraini()))
			// {
			// throw new ApplicationExceptionInfo("Applicant Nationality ", new
			// ApplicationException(" Applicant not Bahraini"));
			// }

			if (personMarriages == null || personMarriages.size() == 0)
			{
				throw new ApplicationExceptionInfo("Applicant Marital status ", new ApplicationException(" Marriage record not found"));
			}

			if (!(wifePersonSummary.isBahraini()) && (husbandIsBahraini = false))
			{

				throw new ApplicationExceptionInfo("Applicant Nationality ", new ApplicationException(
						"Woman not Bahraini and her husband is not Bahraini either"));

			}

			AddressServiceBasicInfoDTO applicantAddresses = getApplicantAddressesGovernorate(cprNumber);

			// List<WomenChildrenDetailsDTO> womenChildrenDetailsDTOList = new
			// ArrayList<WomenChildrenDetailsDTO>();

			// if (childInfoSummaryList != null)
			// {
			// for (PersonSummary childInfo : childInfoSummaryList)
			// {
			// if (!(childInfo.isBahraini()))
			// {
			// womenChildrenDetailsDTOList.add(new
			// WomenChildrenDetailsDTO(childInfo.getCprNumber(),
			// childInfo.getArabicFullName(),
			// childInfo.getEnglishFullName(),
			// CRSUtils.getDateStringFromTimeStamp(childInfo.getDateOfBirth()),
			// childInfo
			// .getGender()));
			// }
			// }
			// }

			womenBasicInfoDTO.setApplicantCprNumber(cprNumber);
			womenBasicInfoDTO.setApplicantFullArabicName(wifePersonSummary.getArabicFullName());
			womenBasicInfoDTO.setApplicantFullEnglishName(wifePersonSummary.getEnglishFullName());
			womenBasicInfoDTO.setApplicantMaritalStatus(wifePersonSummary.getMaritalStatusCode());
			womenBasicInfoDTO.setApplicantGender(wifePersonSummary.getGender());
			womenBasicInfoDTO.setApplicantNoOfChildren(childInfoSummaryList != null ? childInfoSummaryList.size() : 0);
			womenBasicInfoDTO.setGovernorateNameArabic(applicantAddresses.getGovernorateNameArabic());
			womenBasicInfoDTO.setGovernorateNameEnglish(applicantAddresses.getGovernorateNameEnglish());

			// womenBasicInfoDTO.setApplicantDateOfBirth(CRSUtils.getDateStringFromTimeStamp(wifePersonSummary.getDateOfBirth()));
			// womenBasicInfoDTO.setApplicantEmploymentStatusCode(motherPersonSummary.getEmploymentStatusCode());
			// womenBasicInfoDTO.setChildrenDetails(womenChildrenDetailsDTOList);

		}

		catch (BusinessException e)
		{
			e.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("checkNeedGAC  Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(e.getMessage()));
		}

		catch (bh.gov.cio.crs.util.exception.ApplicationException e)
		{

			if (logger.isDebugEnabled())
			{
				logger.error("checkNeedGAC(Integer, Integer, Date) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(e.getMessage()));
		}
		return womenBasicInfoDTO;
	}

//	@Override
//	@Secured(
//	{ "ROLE_checkWomenHousingStatus" })
//	@WebMethod(operationName = "checkWomenHousingStatus")
//	public WomenHousingServiceBasicInfoDTO checkWomenHousingStatus(SecurityTagObject security, Integer cprNumber, Integer blockNumber,
//			Date cardExpiryDate, String housingApplicationNo) throws ApplicationExceptionInfo
//	{
//		PersonService personService = getCrsService().getPersonServiceRef();
//		FamilyService familyService = getCrsService().getFamilyServiceRef();
//		HousingService housingService = getCrsService().getHousingServiceRef();
//
//		WomenHousingServiceBasicInfoDTO womenHousingInfoDTO = new WomenHousingServiceBasicInfoDTO();
//		List<PersonSummary> childInfoSummaryList = new ArrayList<PersonSummary>();
//
//		if (logger.isDebugEnabled())
//		{
//
//			logger.debug("checkWomenHousingStatus(Integer, Integer, Date) - start " + cprNumber + " " + blockNumber + " " + cardExpiryDate);
//		}
//
//		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
//		{
//			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
//		}
//		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
//		{
//			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
//		}
//		if (validationUtil.isDeletedCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//		}
//
//		try
//		{
//			final PersonSummary applicantSummary = personService.getPersonSummary(cprNumber);
//			logger.debug("applicant Gender: " + applicantSummary.getGender() + " - Applicant is Bahraini: " + applicantSummary.isBahraini());
//
//			RequestDto applicantRequestDTO = housingService.getRequestByNumber(housingApplicationNo);
//
//			if (logger.isDebugEnabled())
//			{
//				logger.debug("ApplicantRequest No:" + applicantRequestDTO.getNumber() + " -  Applicant CPR for housing service = "
//						+ applicantRequestDTO.getCpr());
//			}
//
//			final List<Marriage> personMarriages = familyService.getPersonMarriageDivorceList(cprNumber);
//
//			int count = 0;
//			boolean husbandIsBahraini = false;
//			Integer husbandCPRNumber = null;
//			if (personMarriages != null)
//			{
//				for (final Marriage marriage : personMarriages)
//				{
//					final Marriage spouse = marriage;
//					final PersonSummary spousePersonSummary = personService.getPersonSummary(spouse.getPartnerCprNumber());
//					if (logger.isDebugEnabled())
//					{
//						logger.debug("getPersonDetails()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
//					}
//					husbandIsBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
//							.getNationalityCountryCode().equals("900")) ? true : false;
//					husbandCPRNumber = spouse.getPartnerCprNumber();
//					logger.debug("Husband CPR: " + husbandCPRNumber + " Is her Husband Bahraini: " + husbandIsBahraini);
//					count++;
//				}
//				logger.debug("personMarriages.size() " + personMarriages.size());
//			}
//
//			if ((applicantSummary.getGender().equalsIgnoreCase("M")))
//			{
//				throw new ApplicationExceptionInfo("Applicant gender ", new ApplicationException(" Applicant not female"));
//			}
//
//			if (!(applicantSummary.isBahraini()) && (husbandIsBahraini = false))
//			{
//				throw new ApplicationExceptionInfo("Applicant Nationality ", new ApplicationException(
//						" Woman not Bahraini and her husband is not Bahraini either"));
//			}
//
//			if (!(applicantSummary.isDivorced() == true))
//			{
//				throw new ApplicationExceptionInfo("Applicant Marital status ", new ApplicationException(" Woman not divorce"));
//			}
//
//			try
//			{
//
//				childInfoSummaryList = familyService.getCoupleChildren(husbandCPRNumber, cprNumber);
//
//				if (!(applicantRequestDTO.getCpr().equals(cprNumber)))
//				{
//					throw new ApplicationExceptionInfo("Housing Application Number ", new ApplicationException(
//							"Housing application number not correct"));
//				}
//			}
//
//			catch (BusinessException e)
//			{
//				throw new ApplicationExceptionInfo("Applicant Children ", new ApplicationException("No children for the applicant"));
//
//			}
//
//			AddressServiceBasicInfoDTO applicantAddresses = getApplicantAddressesGovernorate(cprNumber);
//			womenHousingInfoDTO.setApplicantCprNumber(cprNumber);
//			womenHousingInfoDTO.setApplicantFullArabicName(applicantSummary.getArabicFullName());
//			womenHousingInfoDTO.setApplicantFullEnglishName(applicantSummary.getEnglishFullName());
//			womenHousingInfoDTO.setApplicantMaritalStatus(applicantSummary.getMaritalStatusCode());
//			womenHousingInfoDTO.setApplicantGender(applicantSummary.getGender());
//			womenHousingInfoDTO.setApplicantNoOfChildren(childInfoSummaryList != null ? childInfoSummaryList.size() : 0);
//			womenHousingInfoDTO.setGovernorateNameArabic(applicantAddresses.getGovernorateNameArabic());
//			womenHousingInfoDTO.setGovernorateNameEnglish(applicantAddresses.getGovernorateNameEnglish());
//			womenHousingInfoDTO.setDateOfHousingApplication(CRSUtils.getDateStringFromTimeStamp((CRSUtils.getTimestampFromDate(applicantRequestDTO
//					.getCreated()))));
//			womenHousingInfoDTO.setTypeOfHousingApplication(applicantRequestDTO.getType());
//			womenHousingInfoDTO.setCategoryOfHousingApplication(applicantRequestDTO.getCategory());
//			womenHousingInfoDTO.setStatusOfHousingApplication(applicantRequestDTO.getStatus());
//
//		}
//
//		catch (BusinessException e)
//		{
//			e.printStackTrace();
//			if (logger.isDebugEnabled())
//			{
//				logger.error("checkWomenHousingStatus  Error: " + e.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(e.getMessage()));
//		}
//
//		catch (bh.gov.cio.crs.util.exception.ApplicationException e)
//		{
//
//			if (logger.isDebugEnabled())
//			{
//				logger.error("checkWomenHousingStatus(Integer, Integer, Date) Error: " + e.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(e.getMessage()));
//		}
//		catch (ServiceException e)
//		{
//
//			e.printStackTrace();
//			throw new ApplicationExceptionInfo(" Housing application request not found for the applicant", new ApplicationException(e.getMessage()));
//		}
//		return womenHousingInfoDTO;
//
//	}

	private AddressServiceBasicInfoDTO getApplicantAddressesGovernorate(Integer cprNumber) throws BusinessException,
			bh.gov.cio.crs.util.exception.ApplicationException
	{
		AddressService addressService = getCrsService().getAddressServiceRef();
		AddressServiceBasicInfoDTO applicantAddresses = new AddressServiceBasicInfoDTO();
		// Address

		List<Address> appCRSAddresses = null;
		try
		{
			// appCRSAddresses =
			// addressService.getPersonAddressByCpr(cprNumber);
			ArrayList<Integer> CPRs = new ArrayList<Integer>();
			CPRs.add(cprNumber);

			appCRSAddresses = addressService.getAddressForListCprNumber(CPRs);

			if (appCRSAddresses != null)
			{
				for (Address currentAdd : appCRSAddresses)
				{
					applicantAddresses = new AddressServiceBasicInfoDTO(currentAdd.getBlockNumber(), currentAdd.getBlockNameArabic(),
							currentAdd.getBuildingNumber(), currentAdd.getNameAlphaEnglish(), currentAdd.getNameAlphaArabic(),
							currentAdd.getBuildingNameArabic(), currentAdd.getBuildingNameEnglish(), currentAdd.getBlockNameEnglish(),
							currentAdd.getRoadNumber(), currentAdd.getRoadNameArabic(), currentAdd.getRoadNameEnglish(), currentAdd.getAreaCode(),
							currentAdd.getAreaNameArabic(), currentAdd.getAreaNameEnglish(), currentAdd.getFlatNumber(),
							currentAdd.getRegionNameArabic(), currentAdd.getRegionNameEnglish(), currentAdd.getGovernorateNameArabic(),
							currentAdd.getGovernorateNameEnglish(), currentAdd.getAddressTypeCode());
				}
			}
		}

		catch (AddressLoadException e)
		{
			e.printStackTrace();
		}
		return applicantAddresses;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

}
