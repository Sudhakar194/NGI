package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "WomenChildrenDetails", propOrder =
{ "cprNumber", "arabicFullName", "englishFullName", "gender", "dateOfBirth" })
public class WomenChildrenDetailsDTO
{
	private java.lang.Integer cprNumber;
	private java.lang.String arabicFullName;
	private java.lang.String englishFullName;
	private java.lang.String dateOfBirth;
	private java.lang.String gender;

	public WomenChildrenDetailsDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public WomenChildrenDetailsDTO(Integer cprNumber, String arabicFullName, String englishFullName, String dateOfBirth, String gender)
	{
		super();
		this.cprNumber = cprNumber != null ? cprNumber : 0;
		this.arabicFullName = arabicFullName != null ? arabicFullName : "";
		this.englishFullName = englishFullName != null ? englishFullName : "";
		this.dateOfBirth = dateOfBirth != null ? englishFullName : "";
		this.gender = gender != null ? gender : "";
	}

	@XmlElement(name = "ArabicFullName")
	public java.lang.String getArabicFullName()
	{
		return arabicFullName;
	}

	@XmlElement(name = "CprNumber")
	public java.lang.Integer getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(name = "DateOfBirth")
	public java.lang.String getDateOfBirth()
	{
		return dateOfBirth;
	}

	@XmlElement(name = "EnglishFullName")
	public java.lang.String getEnglishFullName()
	{
		return englishFullName;
	}

	@XmlElement(name = "Gender")
	public java.lang.String getGender()
	{
		return gender;
	}

	public void setArabicFullName(java.lang.String arabicFullName)
	{
		this.arabicFullName = arabicFullName;
	}

	public void setCprNumber(java.lang.Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDateOfBirth(java.lang.String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public void setEnglishFullName(java.lang.String englishFullName)
	{
		this.englishFullName = englishFullName;
	}

	public void setGender(java.lang.String gender)
	{
		this.gender = gender;
	}

}
