package bh.gov.cio.integration.crs.egov.orphan.service.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "OrphanServiceBasicInfo", propOrder =
{ "applicantFullArabicName", "applicantFullEnglishName","isLastActionMarried","isWifeMarriedAfter", "childrenDetails"})
public class OrphanServiceBasicInfoDTO
{
	private String applicantFullArabicName;
	private String applicantFullEnglishName;
	private List<OrphanChildrensDetailsDTO> childrenDetails;
	private boolean isLastActionMarried;
	private boolean isWifeMarriedAfter;
	public OrphanServiceBasicInfoDTO()
	{
		super();
	}
	public OrphanServiceBasicInfoDTO(String applicantFullArabicName, String applicantFullEnglishName,
			List<OrphanChildrensDetailsDTO> childrenDetails,boolean isLastActionMarried, boolean isWifeMarriedAfter) {
		super();
		this.isLastActionMarried = isLastActionMarried;
		this.isWifeMarriedAfter = isWifeMarriedAfter;
		this.applicantFullArabicName = applicantFullArabicName;
		this.applicantFullEnglishName = applicantFullEnglishName;
		this.childrenDetails = childrenDetails;
	}
	public boolean getIsWifeMarriedAfter() {
		return isWifeMarriedAfter;
	}
	public void setIsWifeMarriedAfter(boolean isWifeMarriedAfter) {
		this.isWifeMarriedAfter = isWifeMarriedAfter;
	}
	public boolean getIsLastActionMarried() {
		return isLastActionMarried;
	}
	public void setIsLastActionMarried(boolean isLastActionMarried) {
		this.isLastActionMarried = isLastActionMarried;
	}
	@XmlElement(name = "ApplicantFullArabicName")
	public String getApplicantFullArabicName()
	{
		return applicantFullArabicName;
	}
	@XmlElement(name = "ApplicantFullEnglishName")
	public String getApplicantFullEnglishName()
	{
		return applicantFullEnglishName;
	}
	@XmlElement(name = "ChildrenDetails")
	public List<OrphanChildrensDetailsDTO> getChildrenDetails()
	{
		return childrenDetails;
	}
	public void setApplicantFullArabicName(String applicantFullArabicName)
	{
		this.applicantFullArabicName = applicantFullArabicName;
	}
	public void setApplicantFullEnglishName(String applicantFullEnglishName)
	{
		this.applicantFullEnglishName = applicantFullEnglishName;
	}
	public void setChildrenDetails(List<OrphanChildrensDetailsDTO> childrenDetails)
	{
		this.childrenDetails = childrenDetails;
	}
}
