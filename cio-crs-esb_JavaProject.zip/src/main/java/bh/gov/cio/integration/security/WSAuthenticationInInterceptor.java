package bh.gov.cio.integration.security;

import java.util.ArrayList;
import java.util.Map;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.ws.security.wss4j.WSS4JInInterceptor;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityEngineResult;
import org.apache.ws.security.WSUsernameTokenPrincipal;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.handler.WSHandlerResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.Assert;

import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

public class WSAuthenticationInInterceptor extends WSS4JInInterceptor implements InitializingBean
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(WSAuthenticationInInterceptor.class);

	private AuthenticationManager authenticationManager;

	public WSAuthenticationInInterceptor()
	{
		super();
	}

	public WSAuthenticationInInterceptor(Map<String, Object> properties)
	{
		super(properties);
	}

	// @Override
	@Override
	public void afterPropertiesSet() throws Exception
	{
		Assert.notNull(getAuthenticationManager(), "Authentication manager must be set");
		Assert.notNull(getProperties(), "Interceptor properties must be set, even if empty");
	}

	/**
	 * @return the authenticationManager
	 */
	public AuthenticationManager getAuthenticationManager()
	{
		return authenticationManager;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void handleMessage(SoapMessage message) throws Fault
	{
		if (logger.isDebugEnabled())
			logger.debug("handleMessage(SoapMessage) - start");

		try
		{
			super.setIgnoreActions(true);
			super.handleMessage(message);
//			if (logger.isDebugEnabled())
//				logger.debug("handleMessage(message = " + message + ")");

			final ArrayList<WSHandlerResult> result = (ArrayList<WSHandlerResult>) message.getContextualProperty(WSHandlerConstants.RECV_RESULTS);
			if (result != null && !result.isEmpty())
				for (final WSHandlerResult res : result)
					// loop through security engine results
					for (final WSSecurityEngineResult securityResult : (ArrayList<WSSecurityEngineResult>) res.getResults())
					{
						final int action = (Integer) securityResult.get(WSSecurityEngineResult.TAG_ACTION);
						// determine if the action was a username token
						if ((action & WSConstants.UT) > 0)
						{
							// get the principal object
							final WSUsernameTokenPrincipal principal = (WSUsernameTokenPrincipal) securityResult.get(WSSecurityEngineResult.TAG_PRINCIPAL);
							if (principal.getPassword() == null)
								principal.setPassword("");
							Authentication authentication = new UsernamePasswordAuthenticationToken(principal.getName(), principal.getPassword());
							authentication = authenticationManager.authenticate(authentication);
							if (!authentication.isAuthenticated())
								if (logger.isDebugEnabled())
									logger.debug("This user is not authentic.");
							SecurityContextHolder.getContext().setAuthentication(authentication);
						}
					}
		}
		catch (final RuntimeException ex)
		{
//			ex.printStackTrace();
			logger.error("handleMessage(SoapMessage)", ex);
			if (ex instanceof org.springframework.security.authentication.DisabledException)
				throw new Fault(new ApplicationExceptionInfo("User is Disabled", new ApplicationException(ex.getMessage())));
			if (ex instanceof org.springframework.security.authentication.BadCredentialsException)
			{
				throw new Fault(new ApplicationExceptionInfo("Bad credentials", new ApplicationException(ex.getMessage())));
				
			}
			
			else
				throw new Fault(new ApplicationExceptionInfo("Error Validating Username/Password", new ApplicationException(ex.getMessage())));
		}

		if (logger.isDebugEnabled())
			logger.debug("handleMessage(SoapMessage) - end");
	}

	/**
	 * @param authenticationManager
	 *            the authenticationManager to set
	 */
	public void setAuthenticationManager(AuthenticationManager authenticationManager)
	{
		this.authenticationManager = authenticationManager;
	}

}