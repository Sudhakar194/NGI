package bh.gov.cio.integration.crs.retrieve.person;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.IsPersonAliveServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "IsPersonAliveService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public class IsPersonAliveServiceImpl implements IsPersonAliveServiceInterface {

	
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(IsPersonAliveServiceImpl.class);
	
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	
	@Autowired
	private ValidationServiceImpl validationUtil;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}
	
	
	@Override
	@Secured(
	{ "ROLE_getIsPersonAlive" })
	@WebMethod(operationName = "IsPersonAlive")
	public Boolean getIsPersonAlive(SecurityTagObject security,
			Integer cprNumber) throws ApplicationExceptionInfo {
		// TODO Auto-generated method stub
		
		if (logger.isDebugEnabled())
		{
			logger.debug("getIsPersonAlive(Integer) - start");
		}
		
		Boolean result = false;
		
		// if (validationUtil.isMilitaryCpr(cprNumber))
		// {
		// throw new ApplicationExceptionInfo("UNAUTHORIZED",
		// new ApplicationException("UNAUTHORIZED"));
		// }
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		
		try {
			
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			
			result = !personSummeryInfo.isDead();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return result;
	}

}
