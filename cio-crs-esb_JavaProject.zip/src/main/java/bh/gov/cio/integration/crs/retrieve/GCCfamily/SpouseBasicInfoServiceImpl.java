package bh.gov.cio.integration.crs.retrieve.GCCfamily;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.IndMarriageDivorce;
import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.SpouseBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.DivorcesBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.DivorcesDetailDTO;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.SpouseBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.SpouseDetailDTO;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.WidowBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.WidowDetailDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GCCSpouseBasicInfoService",
		targetNamespace = "http://service.GCCfamily.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "GCCSpouseBasicInfoService"
public class SpouseBasicInfoServiceImpl implements SpouseBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(SpouseBasicInfoServiceImpl.class);
	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@Override
	@Secured(
	{ "ROLE_getAllDivorcesBasicInfoForGcc" })
	@WebMethod(operationName = "getAllDivorcesBasicInfo")
	public DivorcesBasicInfoDTO getAllDivorcesBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		DivorcesBasicInfoDTO divorcesServiceBasicInfoDTO = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getDivorceBasicInfo(Integer, Integer, Date) - start");
			}

			if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
			{
				throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
			}
			if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
			{
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
			}

			// if (validationUtil.isMilitaryCpr(cprNumber))
			// {
			// throw new BusinessException("UNAUTHORIZED");
			// }
			if (validationUtil.isDeletedCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
			}
			final PersonService personService = getCrsService().getPersonServiceRef();
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() - familyService.getPersonMarriageDivorceList(cprNumber) = " + hm);
			}
			final ArrayList<DivorcesDetailDTO> divorcesDetailDTOList = new ArrayList<DivorcesDetailDTO>();
			int count = 0;
			if (hm != null)
			{
				for (final Marriage marriage : hm)
				{
					final Marriage spouse = marriage;
					final PersonBasicInfo spousePersonBasicInfo = personService.getPersonBasicInfo(spouse.getPartnerCprNumber());
					final PersonSummary spousePersonSummary = personService.getPersonSummary(spouse.getPartnerCprNumber());
					if (logger.isDebugEnabled())
					{
						logger.debug("getPersonDetails()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
					}
					final boolean isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
							.getNationalityCountryCode().equals("900")) ? true : false;
					logger.debug("DivorcePersonBasicInfo:" + spousePersonBasicInfo);
					if (spouse.getLastActionWithPartner().equals("DIVORCE"))
					{
						final List<IndMarriageDivorce> marriageDivorceList = spouse.getIndMarriageDivorceList();
						if (marriageDivorceList != null)
						{
							for (final IndMarriageDivorce marriageDivorce : marriageDivorceList)

							{
								if (marriageDivorce.getActionType().equals("DIVORCE"))
								{
									if (logger.isDebugEnabled())
									{
										logger.debug("spouse.getIndMarriageDivorceList" + spouse.getIndMarriageDivorceList().size() + " -  spouse = "
												+ marriageDivorce.getActionType() + "divorve Date: "
												+ DateServiceImpl.formatDateAsString(marriageDivorce.getMarriageDivorceDate()));
									}

									
									String number = "";
									
									String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
									
									
									if(idNumber !=null)
									
										number = idNumber;
										else
									number = spousePersonBasicInfo.getCprNumber().toString();
									
									divorcesDetailDTOList
											.add(new DivorcesDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
													.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
													.getGender(), DateServiceImpl.formatDateAsString(marriageDivorce.getMarriageDivorceDate())));
								}

							}
						}
					}
					count++;
				}
			}

			
			if (divorcesDetailDTOList.size() == 0)
			{
				throw new Exception("No Data Found");
			}
			final DivorcesDetailDTO divorcesDetailDTO[] = new DivorcesDetailDTO[divorcesDetailDTOList.size()];

			divorcesServiceBasicInfoDTO = new DivorcesBasicInfoDTO(divorcesDetailDTOList.toArray(divorcesDetailDTO));
			if (logger.isDebugEnabled())
			{
				logger.debug("getDivorceBasicInfo() -  IndMarriageDivorce = " + divorcesServiceBasicInfoDTO);
			}

			if (logger.isDebugEnabled())
			{
				logger.debug("getDivorceBasicInfo(Integer, Integer, Date) - end");
			}
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getDivorceBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Divorces Basic Information Can't Be Retrieved", new ApplicationException("Divorces Basic Details Not found :"
					+ exception.getMessage()));
		}
		return divorcesServiceBasicInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getAllDivorcesBasicInfoByCPRForGcc" })
	@WebMethod(operationName = "getAllDivorcesBasicInfoByCPR")
	public DivorcesBasicInfoDTO getAllDivorcesBasicInfoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		DivorcesBasicInfoDTO divorcesServiceBasicInfoDTO = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getAllDivorcesBasicInfoByCPR(Integer) - start");
			}

			if (validationUtil.isDeletedCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
			}
			final PersonService personService = getCrsService().getPersonServiceRef();
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() - familyService.getPersonMarriageDivorceList(cprNumber) = " + hm);
			}
			final ArrayList<DivorcesDetailDTO> divorcesDetailDTOList = new ArrayList<DivorcesDetailDTO>();
			int count = 0;

			if (hm != null)
			{

				for (final Marriage marriage : hm)
				{
					final Marriage spouse = marriage;
					final PersonBasicInfo spousePersonBasicInfo = personService.getPersonBasicInfo(spouse.getPartnerCprNumber());
					final PersonSummary spousePersonSummary = personService.getPersonSummary(spouse.getPartnerCprNumber());
					if (logger.isDebugEnabled())
					{
						logger.debug("getPersonDetails()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
					}
					final boolean isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
							.getNationalityCountryCode().equals("900")) ? true : false;
					logger.debug("DivorcePersonBasicInfo:" + spousePersonBasicInfo);
					if (spouse.getLastActionWithPartner().equals("DIVORCE"))
					{
						final List<IndMarriageDivorce> marriageDivorceList = spouse.getIndMarriageDivorceList();
						if (marriageDivorceList != null)
						{
							for (final IndMarriageDivorce marriageDivorce : marriageDivorceList)

							{
								if (marriageDivorce.getActionType().equals("DIVORCE"))
								{
									if (logger.isDebugEnabled())
									{
										logger.debug("spouse.getIndMarriageDivorceList" + spouse.getIndMarriageDivorceList().size() + " -  spouse = "
												+ marriageDivorce.getActionType() + "divorve Date: "
												+ DateServiceImpl.formatDateAsString(marriageDivorce.getMarriageDivorceDate()));
									}

									
									String number = "";
									
									String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
									
									
									if(idNumber !=null)
									
										number = idNumber;
										else
									number = spousePersonBasicInfo.getCprNumber().toString();
									
									divorcesDetailDTOList
											.add(new DivorcesDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
													.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
													.getGender(), DateServiceImpl.formatDateAsString(marriageDivorce.getMarriageDivorceDate())));
								}

							}
						}
					}
					count++;
				}

			}

			if (divorcesDetailDTOList.size() == 0)
			{
				throw new Exception("No Data Found");
			}
			final DivorcesDetailDTO divorcesDetailDTO[] = new DivorcesDetailDTO[divorcesDetailDTOList.size()];

			divorcesServiceBasicInfoDTO = new DivorcesBasicInfoDTO(divorcesDetailDTOList.toArray(divorcesDetailDTO));
			if (logger.isDebugEnabled())
			{
				logger.debug("getAllDivorcesBasicInfoByCPR() -  IndMarriageDivorce = " + divorcesServiceBasicInfoDTO);
			}

			if (logger.isDebugEnabled())
			{
				logger.debug("getAllDivorcesBasicInfoByCPR(Integer) - end");
			}
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getAllDivorcesBasicInfoByCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Divorces Basic Information Can't Be Retrieved", new ApplicationException("Divorces Basic Details Not found :"
					+ exception.getMessage()));
		}
		return divorcesServiceBasicInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getAllSpouseBasicInfoForGcc" })
	@WebMethod(operationName = "getAllSpouseBasicInfo")
	public SpouseBasicInfoDTO getAllSpouseBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		SpouseBasicInfoDTO spouseServiceBasicInfoDTO = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getSpouseBasicInfo(Integer, Integer, Date) - start");
			}

			if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
			{
				throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
			}
			if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
			{
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
			}
			if (validationUtil.isDeletedCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
			}
			spouseServiceBasicInfoDTO = getSpouseDetails(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getSpouseBasicInfo(Integer, Integer, Date) - end");
			}
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getSpouseBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Spouse Basic Information Can't Be Retrieved", new ApplicationException("Spouse Basic Details Not found"
					+ exception.getMessage()));
		}
		return spouseServiceBasicInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getAllWidowBasicInfoForGcc" })
	@WebMethod(operationName = "getAllWidowBasicInfo")
	public WidowBasicInfoDTO getAllWidowBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		WidowBasicInfoDTO widowServiceBasicInfoDTO = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getAllWidowBasicInfo(Integer, Integer, Date) - start");
			}

			if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
			{
				throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
			}
			if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
			{
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
			}

			// if (validationUtil.isMilitaryCpr(cprNumber))
			// {
			// throw new BusinessException("UNAUTHORIZED");
			// }
			if (validationUtil.isDeletedCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
			}
			final PersonService personService = getCrsService().getPersonServiceRef();
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final Integer spouseRecord = familyService.getPersonPrimarySpouse(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() - familyService.getPersonPrimarySpouse(cprNumber) = " + spouseRecord);
			}
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() - familyService.getPersonMarriageDivorceList(cprNumber) = " + hm);
			}
			final ArrayList<WidowDetailDTO> widowDetailDTOList = new ArrayList<WidowDetailDTO>();
			boolean isSpouseFoundInMarriageDivorceList = false;
			if (spouseRecord == null)
			{
				isSpouseFoundInMarriageDivorceList = true;
			}
			int count = 0;
			if (hm != null)
			{
				for (final Marriage marriage : hm)
				{
					final Marriage spouse = marriage;
					if (spouse.getPartnerCprNumber().equals(spouseRecord))
					{
						isSpouseFoundInMarriageDivorceList = true;
					}
					final PersonBasicInfo spousePersonBasicInfo = personService.getPersonBasicInfo(spouse.getPartnerCprNumber());
					final PersonSummary spousePersonSummary = personService.getPersonSummary(spouse.getPartnerCprNumber());
					if (logger.isDebugEnabled())
					{
						logger.debug("getPersonDetails()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
					}
					logger.debug("spouse.isAlive() " + spouse.isAlive());
					final boolean isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
							.getNationalityCountryCode().equals("900")) ? true : false;
					logger.debug("spousePersonBasicInfo:" + spousePersonBasicInfo);
					if (!spouse.getLastActionWithPartner().equals("DIVORCE") && spousePersonSummary.getDateOfDeath() != null)
					{
						String number = "";
						
						String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
						
						
						if(idNumber !=null)
						
							number = idNumber;
							else
						number = spousePersonBasicInfo.getCprNumber().toString();
						
						widowDetailDTOList
								.add(new WidowDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
										.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
										.getGender(), DateServiceImpl.formatDateAsString(spousePersonSummary.getDateOfDeath())));
					}
					count++;
				}
			}

			// If main spouse not in marriage divorce list then add it
			if (!isSpouseFoundInMarriageDivorceList)
			{
				final PersonBasicInfo spousePersonBasicInfo = personService.getPersonBasicInfo(spouseRecord);
				final PersonSummary spousePersonSummary = personService.getPersonSummary(spouseRecord);
				if (logger.isDebugEnabled())
				{
					logger.debug("getPersonDetails() -  Mainspouse = " + spousePersonSummary);
				}
				final boolean isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
						.getNationalityCountryCode().equals("900")) ? true : false;
				if (spousePersonSummary.getDateOfBirth() != null)
				{
					
					String number = "";
					
					String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
					
					
					if(idNumber !=null)
					
						number = idNumber;
						else
					number = spousePersonBasicInfo.getCprNumber().toString();
					
					widowDetailDTOList.add(
							count,
							new WidowDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
									.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
									.getGender(), DateServiceImpl.formatDateAsString(spousePersonSummary.getDateOfDeath())));
				}

			}
			if (widowDetailDTOList.size() == 0)
			{
				throw new Exception("No Data Found");
			}

			final WidowDetailDTO widowDetailDTO[] = new WidowDetailDTO[widowDetailDTOList.size()];

			widowServiceBasicInfoDTO = new WidowBasicInfoDTO(widowDetailDTOList.toArray(widowDetailDTO));
			if (logger.isDebugEnabled())
			{
				logger.debug("getAllWidowBasicInfo() -  IndMarriageDivorce = " + widowServiceBasicInfoDTO);
			}

			if (logger.isDebugEnabled())
			{
				logger.debug("getAllWidowBasicInfo(Integer, Integer, Date) - end");
			}
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getSpouseBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Widow Basic Information Can't Be Retrieved", new ApplicationException("Widow Basic Details Not found :"
					+ exception.getMessage()));
		}
		return widowServiceBasicInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getAllWidowBasicInfoByCPRForGcc" })
	@WebMethod(operationName = "getAllWidowBasicInfoByCPR")
	public WidowBasicInfoDTO getAllWidowBasicInfoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		WidowBasicInfoDTO widowServiceBasicInfoDTO = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getAllWidowBasicInfoByCPR(Integer) - start");
			}

			if (validationUtil.isDeletedCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
			}
			final PersonService personService = getCrsService().getPersonServiceRef();
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final Integer spouseRecord = familyService.getPersonPrimarySpouse(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() - familyService.getPersonPrimarySpouse(cprNumber) = " + spouseRecord);
			}
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() - familyService.getPersonMarriageDivorceList(cprNumber) = " + hm);
			}
			final ArrayList<WidowDetailDTO> widowDetailDTOList = new ArrayList<WidowDetailDTO>();
			boolean isSpouseFoundInMarriageDivorceList = false;
			if (spouseRecord == null)
			{
				isSpouseFoundInMarriageDivorceList = true;
			}
			int count = 0;
			if (hm != null)
			{
				for (final Marriage marriage : hm)
				{
					final Marriage spouse = marriage;
					if (spouse.getPartnerCprNumber().equals(spouseRecord))
					{
						isSpouseFoundInMarriageDivorceList = true;
					}
					final PersonBasicInfo spousePersonBasicInfo = personService.getPersonBasicInfo(spouse.getPartnerCprNumber());
					final PersonSummary spousePersonSummary = personService.getPersonSummary(spouse.getPartnerCprNumber());
					if (logger.isDebugEnabled())
					{
						logger.debug("getPersonDetails()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
					}
					logger.debug("spouse.isAlive() " + spouse.isAlive());
					final boolean isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
							.getNationalityCountryCode().equals("900")) ? true : false;
					logger.debug("spousePersonBasicInfo:" + spousePersonBasicInfo);
					if (!spouse.getLastActionWithPartner().equals("DIVORCE") && spousePersonSummary.getDateOfDeath() != null)
					{
						
						String number = "";
						
						String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
						
						
						if(personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber()) !=null)
						
							number = idNumber;
							else
						number = spousePersonBasicInfo.getCprNumber().toString();
						
						
						widowDetailDTOList
								.add(new WidowDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
										.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
										.getGender(), DateServiceImpl.formatDateAsString(spousePersonSummary.getDateOfDeath())));
					}
					count++;
				}
			}

			// If main spouse not in marriage divorce list then add it
			if (!isSpouseFoundInMarriageDivorceList)
			{
				final PersonBasicInfo spousePersonBasicInfo = personService.getPersonBasicInfo(spouseRecord);
				final PersonSummary spousePersonSummary = personService.getPersonSummary(spouseRecord);
				if (logger.isDebugEnabled())
				{
					logger.debug("getPersonDetails() -  Mainspouse = " + spousePersonSummary);
				}
				final boolean isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
						.getNationalityCountryCode().equals("900")) ? true : false;
				if (spousePersonSummary.getDateOfBirth() != null)
				{
					
					
					String number = "";
					
					String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
					
					
					if(personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber()) !=null)
					
						number = idNumber;
						else
					number = spousePersonBasicInfo.getCprNumber().toString();
					
					widowDetailDTOList.add(
							count,
							new WidowDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
									.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
									.getGender(), DateServiceImpl.formatDateAsString(spousePersonSummary.getDateOfDeath())));
				}

			}
			if (widowDetailDTOList.size() == 0)
			{
				throw new Exception("No Data Found");
			}

			final WidowDetailDTO widowDetailDTO[] = new WidowDetailDTO[widowDetailDTOList.size()];

			widowServiceBasicInfoDTO = new WidowBasicInfoDTO(widowDetailDTOList.toArray(widowDetailDTO));
			if (logger.isDebugEnabled())
			{
				logger.debug("getAllWidowBasicInfoByCPR() -  IndMarriageDivorce = " + widowServiceBasicInfoDTO);
			}

			if (logger.isDebugEnabled())
			{
				logger.debug("getAllWidowBasicInfoByCPR(Integer) - end");
			}
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getSpouseBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Widow Basic Information Can't Be Retrieved", new ApplicationException("Widow Basic Details Not found :"
					+ exception.getMessage()));
		}
		return widowServiceBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getSpouseBasicInfoForGcc" })
	@WebMethod(operationName = "getSpouseBasicInfo")
	public SpouseBasicInfoDTO getSpouseBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		SpouseBasicInfoDTO spouseServiceBasicInfoDTO = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getSpouseBasicInfo(Integer, Integer, Date) - start");
			}

			if (validationUtil.isMilitaryCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
			}
			spouseServiceBasicInfoDTO = getAllSpouseBasicInfo(security, cprNumber, blockNumber, cardExpiryDate);
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getSpouseBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Spouse Basic Information Can't Be Retrieved", new ApplicationException("Spouse Basic Details Not found"));
		}
		return spouseServiceBasicInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getSpouseBasicInfoByCPRForGcc" })
	@WebMethod(operationName = "getSpouseBasicInfoCPR")
	public SpouseBasicInfoDTO getSpouseBasicInfoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		SpouseBasicInfoDTO spouseServiceBasicInfoDTO = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getSpouseBasicInfo(Integer, Integer, Date) - start");
			}

			if (validationUtil.isMilitaryCpr(cprNumber))
			{
				throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
			}

			spouseServiceBasicInfoDTO = getSpouseDetails(cprNumber);

		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getSpouseBasicInfoByCPR(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Spouse Basic Information Can't Be Retrieved", new ApplicationException("Spouse Basic Details Not found :"
					+ exception.getMessage()));
		}
		return spouseServiceBasicInfoDTO;
	}

	SpouseBasicInfoDTO getSpouseDetails(Integer cprNumber) throws Exception
	{
		SpouseBasicInfoDTO spouseServiceBasicInfoDTO = new SpouseBasicInfoDTO();
		final PersonService personService = getCrsService().getPersonServiceRef();
		final FamilyService familyService = getCrsService().getFamilyServiceRef();
		final Integer spouseRecord = familyService.getPersonPrimarySpouse(cprNumber);
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonDetails() - familyService.getPersonPrimarySpouse(cprNumber) = " + spouseRecord);
		}
		final List<Marriage> hm = familyService.getPersonMarriageDivorceList(cprNumber);
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonDetails() - familyService.getPersonMarriageDivorceList(cprNumber) = " + hm);
		}
		final ArrayList<SpouseDetailDTO> spouseDetailDTOList = new ArrayList<SpouseDetailDTO>();
		boolean isSpouseFoundInMarriageDivorceList = false;
		if (spouseRecord == null)
		{
			isSpouseFoundInMarriageDivorceList = true;
		}
		int count = 0;
		if (hm != null)
		{
			for (final Marriage marriage : hm)
			{
				final Marriage spouse = marriage;
				if (spouse != null && spouse.getPartnerCprNumber() != null && spouse.getPartnerCprNumber().equals(spouseRecord))
				{
					isSpouseFoundInMarriageDivorceList = true;
				}
				PersonBasicInfo spousePersonBasicInfo = new PersonBasicInfo();
				PersonSummary spousePersonSummary = new PersonSummary();
				boolean isBahraini = false;
				if (spouse.getPartnerCprNumber() != null)
				{
					spousePersonBasicInfo = personService.getPersonBasicInfo(spouse.getPartnerCprNumber());
					spousePersonSummary = personService.getPersonSummary(spouse.getPartnerCprNumber());
					isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary.getNationalityCountryCode()
							.equals("900")) ? true : false;
				}
				if (logger.isDebugEnabled())
				{
					logger.debug("getPersonDetails()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
				}
				logger.debug("spousePersonBasicInfo:" + spousePersonBasicInfo);
				if (spouse != null && !spouse.getLastActionWithPartner().equals("DIVORCE"))
				{
					String number = "";
					
					String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
					
					
					if(idNumber !=null)
					
						number = idNumber;
						else
					number = spousePersonBasicInfo.getCprNumber().toString();
					
					
					spouseDetailDTOList
							.add(new SpouseDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
									.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
									.getGender(), spouse.getMarriageDivorceDate() != null ? DateServiceImpl.formatDate(spouse
									.getMarriageDivorceDate()) : ""));
				}
				count++;
			}
		}

		// If main spouse not in marriage divorce list then add it
		if (!isSpouseFoundInMarriageDivorceList)
		{
			final PersonBasicInfo spousePersonBasicInfo = personService.getPersonBasicInfo(spouseRecord);
			final PersonSummary spousePersonSummary = personService.getPersonSummary(spouseRecord);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() -  Mainspouse = " + spousePersonSummary);
			}
			final boolean isBahraini = (spousePersonSummary.getNationalityCountryCode().equals("499") || spousePersonSummary
					.getNationalityCountryCode().equals("900")) ? true : false;
			final List<IndMarriageDivorce> mainSpouseActionList = familyService.getCoupleMarriageDivorceList(cprNumber, spouseRecord);
			String marriageDate = "";

			if (mainSpouseActionList != null)
			{
				for (final IndMarriageDivorce marriage : mainSpouseActionList)
				{
					if (marriage.getActionType().equalsIgnoreCase("MARRIAGE"))
					{
						marriageDate = marriage.getMarriageDivorceDate() != null ? DateServiceImpl.formatDateAsString(marriage
								.getMarriageDivorceDate()) : "";
						break;
					}
				}
			}

			
			String number = "";
			
			String idNumber = personService.getGccIdByCPR(spousePersonBasicInfo.getCprNumber());
			
			
			if(idNumber!=null)
			
				number = idNumber;
				else
			number = spousePersonBasicInfo.getCprNumber().toString();
			
			spouseDetailDTOList
					.add(count,
							new SpouseDetailDTO(number, spousePersonBasicInfo.getArabicName(), spousePersonBasicInfo
									.getEnglishName(), spousePersonSummary.isArab(), spousePersonSummary.isGcc(), isBahraini, spousePersonSummary
									.getGender(), marriageDate));

		}
		if (spouseDetailDTOList.size() == 0)
		{
			throw new Exception("No Data Found");
		}

		final SpouseDetailDTO spouseDetailDTO[] = new SpouseDetailDTO[spouseDetailDTOList.size()];

		spouseServiceBasicInfoDTO = new SpouseBasicInfoDTO(spouseDetailDTOList.toArray(spouseDetailDTO));
		if (logger.isDebugEnabled())
		{
			logger.debug("getSpouseBasicInfoByCPR() -  IndMarriageDivorce = " + spouseServiceBasicInfoDTO);
		}

		if (logger.isDebugEnabled())
		{
			logger.debug("getSpouseBasicInfoByCPR(Integer, Integer, Date) - end");
		}
		return spouseServiceBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
