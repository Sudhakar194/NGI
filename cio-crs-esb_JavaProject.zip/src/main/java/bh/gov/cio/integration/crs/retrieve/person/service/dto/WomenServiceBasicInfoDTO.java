package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "ApplicantBasicDetails", propOrder =
{ "applicantCprNumber", "applicantFullArabicName", "applicantFullEnglishName", "applicantGender", "applicantMaritalStatus", "applicantNoOfChildren",
		"childrenDetails", "governorateNameArabic", "governorateNameEnglish" })
public class WomenServiceBasicInfoDTO
{
	private Integer applicantCprNumber;
	private String applicantFullArabicName;
	private String applicantFullEnglishName;
	private String applicantGender;
	private String applicantMaritalStatus;
	private Integer applicantNoOfChildren;
	private List<WomenChildrenDetailsDTO> childrenDetails;
	private String governorateNameArabic;
	private String governorateNameEnglish;

	// private String applicantEmploymentStatusCode;
	// private String applicantDateOfBirth;
	// private List<AddressServiceBasicInfoDTO> applicantAddresses;

	public WomenServiceBasicInfoDTO()
	{
		super();

	}

	public WomenServiceBasicInfoDTO(Integer applicantCprNumber, String applicantFullArabicName, String applicantFullEnglishName,
			String applicantGender, String applicantMaritalStatus, Integer applicantNoOfChildren, List<WomenChildrenDetailsDTO> childrenDetails,
			String governorateNameArabic, String governorateNameEnglish)
	{
		super();
		this.applicantCprNumber = applicantCprNumber;
		this.applicantFullArabicName = applicantFullArabicName;
		this.applicantFullEnglishName = applicantFullEnglishName;
		this.applicantGender = applicantGender;
		this.applicantMaritalStatus = applicantMaritalStatus;
		this.applicantNoOfChildren = applicantNoOfChildren;
		this.childrenDetails = childrenDetails;
		this.governorateNameArabic = governorateNameArabic;
		this.governorateNameEnglish = governorateNameEnglish;
	}

	@XmlElement(name = "ApplicantCprNumber")
	public java.lang.Integer getApplicantCprNumber()
	{
		return applicantCprNumber;
	}

	@XmlElement(name = "ApplicantFullArabicName")
	public String getApplicantFullArabicName()
	{
		return applicantFullArabicName;
	}

	@XmlElement(name = "ApplicantFullEnglishName")
	public String getApplicantFullEnglishName()
	{
		return applicantFullEnglishName;
	}

	@XmlElement(name = "ApplicantGender")
	public String getApplicantGender()
	{
		return applicantGender;
	}

	@XmlElement(name = "ApplicantMaritalStatus")
	public String getApplicantMaritalStatus()
	{
		return applicantMaritalStatus;
	}

	@XmlElement(name = "ApplicantNoOfChildren")
	public Integer getApplicantNoOfChildren()
	{
		return applicantNoOfChildren;
	}

	@XmlElement(name = "ChildrenDetails")
	public List<WomenChildrenDetailsDTO> getChildrenDetails()
	{
		return childrenDetails;
	}

	@XmlElement(name = "GovernorateNameArabic")
	public String getGovernorateNameArabic()
	{
		return governorateNameArabic;
	}

	@XmlElement(name = "GovernorateNameEnglish")
	public String getGovernorateNameEnglish()
	{
		return governorateNameEnglish;
	}

	public void setApplicantCprNumber(java.lang.Integer applicantCprNumber)
	{
		this.applicantCprNumber = applicantCprNumber;
	}

	public void setApplicantFullArabicName(String applicantFullArabicName)
	{
		this.applicantFullArabicName = applicantFullArabicName;
	}

	public void setApplicantFullEnglishName(String applicantFullEnglishName)
	{
		this.applicantFullEnglishName = applicantFullEnglishName;
	}

	public void setApplicantGender(String applicantGender)
	{
		this.applicantGender = applicantGender;
	}

	public void setApplicantMaritalStatus(String applicantMaritalStatus)
	{
		this.applicantMaritalStatus = applicantMaritalStatus;
	}

	public void setApplicantNoOfChildren(Integer applicantNoOfChildren)
	{
		this.applicantNoOfChildren = applicantNoOfChildren;
	}

	public void setChildrenDetails(List<WomenChildrenDetailsDTO> childrenDetails)
	{
		this.childrenDetails = childrenDetails;
	}

	public void setGovernorateNameArabic(String governorateNameArabic)
	{
		this.governorateNameArabic = governorateNameArabic;
	}

	public void setGovernorateNameEnglish(String governorateNameEnglish)
	{
		this.governorateNameEnglish = governorateNameEnglish;
	}

}
