package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "FamilyBasicInfoDTO", propOrder =
{ "maritalStatusCode", "partenerCprNumber", "marriageDivorceIndicator",
		"marriageDivorceDate", "partenerFullName", })
public class FamilyBasicInfoDTO
{
	private String	maritalStatusCode;
	private String	partenerCprNumber;
	private String	marriageDivorceIndicator;
	private String	marriageDivorceDate;
	private String	partenerFullName;

	public FamilyBasicInfoDTO()
	{
		super();
	}

	public FamilyBasicInfoDTO(String maritalStatusCode,
			String partenerCprNumber, String marriageDivorceIndicator,
			String marriageDivorceDate, String partenerFullName)
	{
		super();
		this.maritalStatusCode = maritalStatusCode;
		this.partenerCprNumber = partenerCprNumber;
		this.marriageDivorceIndicator = marriageDivorceIndicator;
		this.marriageDivorceDate = marriageDivorceDate;
		this.partenerFullName = partenerFullName;
	}

	@XmlElement(name = "MaritalStatusCode", required = true)
	public String getMaritalStatusCode()
	{
		return maritalStatusCode;
	}

	@XmlElement(name = "MarriageDivorceDate", required = true)
	public String getMarriageDivorceDate()
	{
		return marriageDivorceDate;
	}

	@XmlElement(name = "MarriageDivorceIndicator", required = true)
	public String getMarriageDivorceIndicator()
	{
		return marriageDivorceIndicator;
	}

	@XmlElement(name = "PartenerCprNumber", required = true)
	public String getPartenerCprNumber()
	{
		return partenerCprNumber;
	}

	@XmlElement(name = "PartenerFullName", required = true)
	public String getPartenerFullName()
	{
		return partenerFullName;
	}

	public void setMaritalStatusCode(String maritalStatusCode)
	{
		this.maritalStatusCode = maritalStatusCode;
	}

	public void setMarriageDivorceDate(String marriageDivorceDate)
	{
		this.marriageDivorceDate = marriageDivorceDate;
	}

	public void setMarriageDivorceIndicator(String marriageDivorceIndicator)
	{
		this.marriageDivorceIndicator = marriageDivorceIndicator;
	}

	public void setPartenerCprNumber(String partenerCprNumber)
	{
		this.partenerCprNumber = partenerCprNumber;
	}

	public void setPartenerFullName(String partenerFullName)
	{
		this.partenerFullName = partenerFullName;
	}

}
