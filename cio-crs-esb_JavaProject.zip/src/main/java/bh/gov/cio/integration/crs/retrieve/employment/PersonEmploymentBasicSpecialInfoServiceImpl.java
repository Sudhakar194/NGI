package bh.gov.cio.integration.crs.retrieve.employment;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.employment.service.PersonEmploymentBasicSpecialInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.employment.service.dto.EmploymentServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonEmploymentBasicSpecialInfoService",
		targetNamespace = "http://service.employment.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonEmploymentBasicSpecialInfoService"
public class PersonEmploymentBasicSpecialInfoServiceImpl implements PersonEmploymentBasicSpecialInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(PersonEmploymentBasicSpecialInfoServiceImpl.class);
	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonEmploymentBasicSpecialInfo" })
	@WebMethod(operationName = "getPersonEmploymentBasicSpecialInfo")
	public EmploymentServiceBasicInfoDTO[] getPersonEmploymentBasicSpecialInfo(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
			logger.debug("getPersonEmploymentBasicSpecialInfo(Integer, Integer, Date) - start");
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		EmploymentServiceBasicInfoDTO[] employmentServiceBasicInfoDTO = null;
		try
		{
			final List<Employment> personEmployement = getCrsService().getEmploymentServiceRef().getActiveEmployments(cprNumber);
			if (personEmployement.size() == 0)
				throw new ApplicationExceptionInfo("Employment Basic Details Not found", new ApplicationException(
						"Employment Basic Special Details Not found"));
			Integer employerNumber;
			String employerNumberStr = "";
			String employerArabicName = "";
			String employerEnglishName = "";
			String employerType = "";
			String employmentStatus = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber).getEmploymentStatusCode();
			String occupationCode = "";
			employmentServiceBasicInfoDTO = new EmploymentServiceBasicInfoDTO[personEmployement.size()];
			if ((personEmployement != null) && (!personEmployement.isEmpty()))
			{
				int i = 0;
				for (final Employment employment2 : personEmployement)
				{
					final Employment employment = employment2;
					employerNumber = employment.getEmployerNumber();
					employerArabicName = employment.getEmployerAN();
					employerEnglishName = employment.getEmployerEN();
					employerType = employment.getEmployerType();
					// employmentStatus = employment.getEmploymentStatus();
					occupationCode = employment.getOccupationCode();
					if (employerNumber == null)
						employerNumberStr = "";
					else
						employerNumberStr = employerNumber + "";
					if (employerArabicName == null)
						employerArabicName = "";
					if (employerEnglishName == null)
						employerEnglishName = "";
					if (employerType == null)
						employerType = "";
					if (employmentStatus == null)
						employmentStatus = "";

					employmentServiceBasicInfoDTO[i] = new EmploymentServiceBasicInfoDTO(employerNumberStr, employerArabicName, employerEnglishName,
							employerType, employmentStatus, occupationCode);
					i++;
				}
			}
			if (logger.isDebugEnabled())
				logger.debug("getPersonEmploymentBasicInfo(Integer, Integer, Date) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonEmploymentBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Employment Basic Details Not found", new ApplicationException(exception.getMessage()));
		}
		return employmentServiceBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
