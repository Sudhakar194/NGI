package bh.gov.cio.integration.crs.retrieve.family.rco.service.dto;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "FatherMotherInfoDTO", propOrder =
{ "isLastActionMarried", "isWifeMarriedAfter","fatherInfo","motherInfo","childrenInfo"})
public class FatherMotherInfoDTO
{
	private boolean isLastActionMarried;
	private boolean isWifeMarriedAfter;
	private FatherInfoDTO fatherInfo;
	private MotherInfoDTO motherInfo;
	private ArrayList<ChildrenRCODetailDTO> childrenInfo;
	public FatherMotherInfoDTO() {
		super();
	}
	public FatherMotherInfoDTO(boolean isLastActionMarried, boolean isWifeMarriedAfter, FatherInfoDTO fatherInfo,
			MotherInfoDTO motherInfo, ArrayList<ChildrenRCODetailDTO> childrenInfo) {
		super();
		this.isLastActionMarried = isLastActionMarried;
		this.isWifeMarriedAfter = isWifeMarriedAfter;
		this.fatherInfo = fatherInfo;
		this.motherInfo = motherInfo;
		this.childrenInfo = childrenInfo;
	}
	public ArrayList<ChildrenRCODetailDTO> getChildrenInfo() {
		return childrenInfo;
	}
	public void setChildrenInfo(ArrayList<ChildrenRCODetailDTO> childrenInfo) {
		this.childrenInfo = childrenInfo;
	}
	public boolean getIsLastActionMarried() {
		return isLastActionMarried;
	}
	public void setIsLastActionMarried(boolean isLastActionMarried) {
		this.isLastActionMarried = isLastActionMarried;
	}
	public FatherInfoDTO getFatherInfo() {
		return fatherInfo;
	}
	public void setFatherInfo(FatherInfoDTO fatherInfo) {
		this.fatherInfo = fatherInfo;
	}
	public MotherInfoDTO getMotherInfo() {
		return motherInfo;
	}
	public void setMotherInfo(MotherInfoDTO motherInfo) {
		this.motherInfo = motherInfo;
	}
	public void setLastActionMarried(boolean isLastActionMarried) {
		this.isLastActionMarried = isLastActionMarried;
	}
	public boolean getIsWifeMarriedAfter() {
		return isWifeMarriedAfter;
	}
	public void setIsWifeMarriedAfter(boolean isWifeMarriedAfter) {
		this.isWifeMarriedAfter = isWifeMarriedAfter;
	}
}
