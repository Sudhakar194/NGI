package bh.gov.cio.integration.crs.egov.customs;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.CRSEntity;
import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.egov.customs.service.RetrieveApplicantDetailsServiceInterface;
import bh.gov.cio.integration.crs.egov.customs.service.dto.ApplicantDetailsDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "RetrieveCustomsApplicantDetailsService", targetNamespace = "http://service.customs.egov.crs.integration.cio.gov.bh/")
public class RetrieveApplicantDetailsServiceImpl implements RetrieveApplicantDetailsServiceInterface{

	private static final Logger	logger	= LoggerFactory.getLogger(RetrieveApplicantDetailsServiceImpl.class);
	
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}
	
	
	
	@Override
	@Secured({ "ROLE_CustomsApplicationDetails" })
	@WebMethod(operationName = "RetrieveCustomsApplicantDetails")
	public ApplicantDetailsDTO RetrieveApplicantDetails(
			SecurityTagObject security, Integer cprNumber,Integer age
			)
			throws ApplicationExceptionInfo {
		// TODO Auto-generated method stub
		
		ApplicantDetailsDTO applicantDetailsDTO =  new ApplicantDetailsDTO();
		
		PersonSummary personSummary = null;
		
		logger.debug("RetrieveApplicantDetails -- cprNumber="+cprNumber);
		
			
			try {
				personSummary = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			if(personSummary == null)
				throw new ApplicationExceptionInfo(
						"Applicant Details Not found",
						new bh.gov.cio.integration.exception.ApplicationException(
								"Applicant Details Not found"));
			
			
			String cprString = (""+(cprNumber + 1000000000)).substring(1);
			
			applicantDetailsDTO.setCprNumber(cprString);
			
			int personAge = personSummary.getAge();
			
			logger.debug("age - "+personAge);
			
			if(personAge > age)
				applicantDetailsDTO.setDob("0");
			else
				applicantDetailsDTO.setDob("1");
			
			if(personSummary.getArabicFirstName() != null)
			applicantDetailsDTO.setFirstArabicName(personSummary.getArabicFirstName().trim());
			else
				applicantDetailsDTO.setFirstArabicName("");
		
			if(personSummary.getArabicMiddleName1() != null)
			applicantDetailsDTO.setMiddleArabicName1(personSummary.getArabicMiddleName1().trim());
			else
				applicantDetailsDTO.setMiddleArabicName1("");
		
			if(personSummary.getArabicMiddleName2() != null)
			applicantDetailsDTO.setMiddleArabicName2(personSummary.getArabicMiddleName2().trim());
			else
				applicantDetailsDTO.setMiddleArabicName2("");
		
			if(personSummary.getArabicMiddleName3() != null)
			applicantDetailsDTO.setMiddleArabicName3(personSummary.getArabicMiddleName3().trim());
			else
				applicantDetailsDTO.setMiddleArabicName2("");
		
			if(personSummary.getArabicMiddleName4() != null)
			applicantDetailsDTO.setMiddleArabicName4(personSummary.getArabicMiddleName4().trim());
			else
				applicantDetailsDTO.setMiddleArabicName4("");
		
			if(personSummary.getArabicFamilyName() != null)
			applicantDetailsDTO.setLastArabicName(personSummary.getArabicFamilyName().trim());
			else
				applicantDetailsDTO.setLastArabicName("");
			
			
			
			if(personSummary.getEnglishFirstName() != null)
			applicantDetailsDTO.setFirstEnglishName(personSummary.getEnglishFirstName().trim());
			else
				applicantDetailsDTO.setFirstEnglishName("");
			
			if(personSummary.getEnglishMiddleName1() != null)
			applicantDetailsDTO.setMiddleEnglishName1(personSummary.getEnglishMiddleName1().trim());
			else
				applicantDetailsDTO.setMiddleEnglishName1("");
			
			if(personSummary.getEnglishMiddleName2() != null)
			applicantDetailsDTO.setMiddleEnglishName2(personSummary.getEnglishMiddleName2().trim());
			else
				applicantDetailsDTO.setMiddleEnglishName2("");
			
			if(personSummary.getEnglishMiddleName3() != null)
			applicantDetailsDTO.setMiddleEnglishName3(personSummary.getEnglishMiddleName3().trim());
			else
				applicantDetailsDTO.setMiddleEnglishName3("");
			
			if(personSummary.getEnglishMiddleName4() != null)
			applicantDetailsDTO.setMiddleEnglishName4(personSummary.getEnglishMiddleName4().trim());
			else
				applicantDetailsDTO.setMiddleEnglishName4("");
			
			if(personSummary.getEnglishFamilyName() != null)
			applicantDetailsDTO.setLastEnglishName(personSummary.getEnglishFamilyName().trim());
			else
				applicantDetailsDTO.setLastEnglishName("");
			
			
			String natCode = personSummary.getNationalityCountryCode().trim();
	
			if( "499".equals(natCode)|| //BAH
				"441".equals(natCode)|| //KSA
				"411".equals(natCode)|| //UAE
				"430".equals(natCode)|| //KUWAIT
				"436".equals(natCode)|| //OMAN
				"440".equals(natCode)){ //QATAR
			
				applicantDetailsDTO.setNationality("1");	
			}else{
				applicantDetailsDTO.setNationality("0");	
			}
			
			List<Employment> employments = null;
		
			try {
				employments = getCrsService().getEmploymentServiceRef().getActiveEmployments(cprNumber);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			if(employments !=null && !employments.isEmpty()){
				
				Integer employerNumber = employments.get(0).getEmployerNumber();

				if(employerNumber > 79999999 
						&& "U".equalsIgnoreCase(employments.get(0).getEmployerType().trim())){
					applicantDetailsDTO.setWorkType("3");
					applicantDetailsDTO.setWorkPlace("Y");
					applicantDetailsDTO.setOccupationArabic("");
					applicantDetailsDTO.setOccupationEnglish("");
				
				}else if("P".equalsIgnoreCase(employments.get(0).getEmployerType().trim())){					
					applicantDetailsDTO.setWorkType("4");
					applicantDetailsDTO.setWorkPlace("");
					applicantDetailsDTO.setOccupationArabic("");
					applicantDetailsDTO.setOccupationEnglish("");
				}else{
					
				applicantDetailsDTO.setWorkType("2");
				
				if("M".equalsIgnoreCase(personSummary.getGender().trim()))
				applicantDetailsDTO.setOccupationArabic(employments.get(0).getOccupationANM());
				else
				applicantDetailsDTO.setOccupationArabic(employments.get(0).getOccupationANF());
					
				applicantDetailsDTO.setOccupationEnglish(employments.get(0).getOccupationEN());
				
				applicantDetailsDTO.setWorkPlace(employerNumber.toString());

				}
				
			}else{
				applicantDetailsDTO.setWorkType("4");
				applicantDetailsDTO.setWorkPlace("");
				applicantDetailsDTO.setOccupationArabic("");
				applicantDetailsDTO.setOccupationEnglish("");
			}
			

			List<CRSEntity> crsEntities = new ArrayList<CRSEntity>();
			
			List<CRSEntity> ownedCRs = null;
			List<CRSEntity> ownedUnits = null;
			try {
				ownedCRs = getCrsService().getPersonServiceRef().getPersonOwnedCRs(cprNumber);

				ownedUnits 	= getCrsService().getPersonServiceRef().getPersonOwnedUnits(cprNumber);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(ownedCRs != null && !ownedCRs.isEmpty()){
				crsEntities.addAll(ownedCRs);
			}
			
			if(ownedUnits != null && !ownedUnits.isEmpty()){
				crsEntities.addAll(ownedUnits);
			}
			
			if(!crsEntities.isEmpty()){
				applicantDetailsDTO.setWorkType("1");
			}

		
		
		return applicantDetailsDTO;
	}
	
}
