package bh.gov.cio.integration.crs.retrieve.cr.service.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlType(name = "CRServiceBasicInfoDTO", propOrder =
{ "crNumber","crArabicName", "crEnglishName", "licenseExpiryDate", "flat","building","alpha","road","block",
		"crActivitiesList", "companyStatusCode", "email",
		"fax", "mobile", "phoneContact","poBox" })

public class CRServiceBasicInfoDTO
{
	private Integer 					crNumber;
	private String						crArabicName;

	private String						crEnglishName;

	private String						companyStatusCode;

	private String						mobile;

	private String						licenseExpiryDate;

	private String						email;

	private String						fax;

	private String						phoneContact;
	
	private String						poBox;
	
	private String						flat;
	private String						building;
	private String						alpha;
	private String						road;
	private String						block;
	
	private  List 	<CRActivityInfoDTO> crActivitiesList;
	


	//private ArrayList<CROwnerInfoDTO>	OwnersList;
	public CRServiceBasicInfoDTO()
	{
		super();

	}
	


	public CRServiceBasicInfoDTO(Integer crNumber, String crArabicName,
			String crEnglishName, String companyStatusCode, String mobile,
			String licenseExpiryDate, String email, String fax,
			String phoneContact, String poBox,String flat, String building, String alpha,
			String road, String block, List<CRActivityInfoDTO> crActivitiesList) {
		super();
		this.crNumber = crNumber;
		if (crArabicName != null)
			setCrArabicName(crArabicName);
		else
			setCrArabicName("");
		
		if (crEnglishName != null)
			setCrEnglishName(crEnglishName);
		else
			setCrEnglishName("");
		
		if (companyStatusCode != null)
			setCompanyStatusCode(companyStatusCode);
		else
			setCompanyStatusCode("");
		
		if (mobile != null)
			setMobile(mobile);
		else
			setMobile("");
		
		if (licenseExpiryDate != null)
			setLicenseExpiryDate(licenseExpiryDate);
		else
			setLicenseExpiryDate("");
		
		if (email != null)
			setEmail(email);
		else
			setEmail("");
		
		if (fax != null)
			setFax(fax);
		else
			setFax("");
		
		if (phoneContact != null)
			setPhoneContact(phoneContact);
		else
			setPhoneContact("");
		
		if (poBox != null)
			setPoBox(poBox);
		else
			setPoBox("");
		
		
		if (flat != null)
			setFlat(flat);
		else
			setFlat("");
		
		if (building != null)
			setBuilding(building);
		else
			setBuilding("");
		
		if (alpha != null)
			setAlpha(alpha);
		else
			setAlpha("");
		
		if (road != null)
			setRoad(road);
		else
			setRoad("");
		
		if (block != null)
			setBlock(block);
		else
			setBlock("");
		
		if (crActivitiesList != null)
			setCrActivitiesList(crActivitiesList);
		else
			setCrActivitiesList(new ArrayList <CRActivityInfoDTO>());
		
	}










	@XmlElement(name = "CRNumber", required = true)
	public Integer getCrNumber() {
		return crNumber;
	}
	public void setCrNumber(Integer crNumber) {
		this.crNumber = crNumber;
	}



	@XmlElement(name = "CompanyArabicName", required = true)
	public String getCrArabicName() {
		return crArabicName;
	}

	public void setCrArabicName(String crArabicName) {
		this.crArabicName = crArabicName;
	}

	@XmlElement(name = "CompanyEnglishName", required = true)
	public String getCrEnglishName() {
		return crEnglishName;
	}
	
	
	public void setCrEnglishName(String crEnglishName) {
		this.crEnglishName = crEnglishName;
	}
	
	@XmlElement(name = "CompanyStatus", required = true)
	public String getCompanyStatusCode() {
		return companyStatusCode;
	}

	
	public void setCompanyStatusCode(String companyStatusCode) {
		this.companyStatusCode = companyStatusCode;
	}

	@XmlElement(name = "Mobile", required = true)
	public String getMobile() {
		return mobile;
	}
	
	
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	@XmlElement(name = "EndOfValidity", required = true)
	public String getLicenseExpiryDate() {
		return licenseExpiryDate;
	}

	
	public void setLicenseExpiryDate(String licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}

	@XmlElement(name = "Email", required = true)
	public String getEmail() {
		return email;
	}

	
	public void setEmail(String email) {
		this.email = email;
	}

	@XmlElement(name = "Fax", required = true)
	public String getFax() {
		return fax;
	}

	
	public void setFax(String fax) {
		this.fax = fax;
	}

	@XmlElement(name = "Telephone", required = true)
	public String getPhoneContact() {
		return phoneContact;
	}

	
	public void setPhoneContact(String phoneContact) {
		this.phoneContact = phoneContact;
	}

	@XmlElement(name = "BusinessActivityDetails", required = true)
	public List<CRActivityInfoDTO> getCrActivitiesList() {
		return crActivitiesList;
	}

	public void setCrActivitiesList(List<CRActivityInfoDTO> crActivitiesList) {
		this.crActivitiesList = crActivitiesList;
	}



	@XmlElement(name = "Flat", required = true)
	public String getFlat() {
		return flat;
	}
	public void setFlat(String flat) {
		this.flat = flat;
	}



	@XmlElement(name = "Building", required = true)
	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	@XmlElement(name = "Alpha", required = true)
	public String getAlpha() {
		return alpha;
	}

	public void setAlpha(String alpha) {
		this.alpha = alpha;
	}



	@XmlElement(name = "Road", required = true)
	public String getRoad() {
		return road;
	}

	public void setRoad(String road) {
		this.road = road;
	}



	@XmlElement(name = "Block", required = true)
	public String getBlock() {
		return block;
	}


	public void setBlock(String block) {
		this.block = block;
	}


	@XmlElement(name = "PoBox", required = true)
	public String getPoBox() {
		return poBox;
	}



	public void setPoBox(String poBox) {
		this.poBox = poBox;
	}
	
	
	
	
	
	

}