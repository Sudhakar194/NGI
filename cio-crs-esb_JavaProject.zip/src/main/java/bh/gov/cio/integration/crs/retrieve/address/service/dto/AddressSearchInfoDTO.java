package bh.gov.cio.integration.crs.retrieve.address.service.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "AddressSearchInfo", propOrder =
{ "flatNumber", "buildingNumber", "nameAlphaEnglish", "nameAlphaArabic", "buildingNameArabic", "buildingNameEnglish", "buildingTypeCode",
		"usageTypeCode", "roadNumber", "roadNameArabic", "roadNameEnglish", "blockNumber", "blockNameArabic", "blockNameEnglish", "regionNameArabic",
		"regionNameEnglish", "areaCode", "areaNameArabic", "areaNameEnglish", "governorateNameArabic", "governorateNameEnglish",
		"addressDateCreated", "addressOwners" })
public class AddressSearchInfoDTO
{

	private java.lang.Integer areaCode;
	private java.lang.String areaNameArabic;
	private java.lang.String areaNameEnglish;
	private java.lang.Integer flatNumber;
	private java.lang.String regionNameArabic;
	private java.lang.String regionNameEnglish;
	private java.lang.Integer blockNumber;
	private java.lang.String blockNameArabic;
	private java.lang.Integer buildingNumber;
	private java.lang.String nameAlphaEnglish;
	private java.lang.String nameAlphaArabic;
	private java.lang.String buildingNameArabic;
	private java.lang.String buildingNameEnglish;
	private java.lang.String blockNameEnglish;
	private java.lang.Integer roadNumber;
	private java.lang.String roadNameArabic;
	private java.lang.String roadNameEnglish;
	private java.lang.String governorateNameArabic;
	private java.lang.String governorateNameEnglish;
	private java.lang.String buildingTypeCode;
	private java.lang.String usageTypeCode;
	private java.lang.String addressDateCreated;
	private List<AddressOwnerDTO> addressOwners;

	public AddressSearchInfoDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public AddressSearchInfoDTO(Integer blockNumber, String blockNameArabic, Integer buildingNumber, String nameAlphaEnglish, String nameAlphaArabic,
			String buildingNameArabic, String buildingNameEnglish, String blockNameEnglish, Integer roadNumber, String roadNameArabic,
			String roadNameEnglish, Integer areaCode, String areaNameArabic, String areaNameEnglish, Integer flatNumber, String regionNameArabic,
			String regionNameEnglish, String governorateNameArabic, String governorateNameEnglish, String buildingTypeCode, String usageTypeCode,
			String addressDateCreated, List<AddressOwnerDTO> addressOwners)
	{
		super();
		this.blockNumber = blockNumber != null ? blockNumber : 0;
		this.blockNameArabic = blockNameArabic != null ? blockNameArabic : "";
		this.buildingNumber = buildingNumber != null ? buildingNumber : 0;
		this.nameAlphaEnglish = nameAlphaEnglish != null ? nameAlphaEnglish : "";
		this.nameAlphaArabic = nameAlphaArabic != null ? nameAlphaArabic : "";
		this.buildingNameArabic = buildingNameArabic != null ? buildingNameArabic : "";
		this.buildingNameEnglish = buildingNameEnglish != null ? buildingNameEnglish : "";
		this.blockNameEnglish = blockNameEnglish != null ? blockNameEnglish : "";
		this.roadNumber = roadNumber != null ? roadNumber : 0;
		this.roadNameArabic = roadNameArabic != null ? roadNameArabic : "";
		this.roadNameEnglish = roadNameEnglish != null ? roadNameEnglish : "";
		this.areaCode = areaCode != null ? areaCode : 0;
		this.areaNameArabic = areaNameArabic != null ? areaNameArabic : "";
		this.areaNameEnglish = areaNameEnglish != null ? areaNameEnglish : "";
		this.flatNumber = flatNumber != null ? flatNumber : 0;
		this.regionNameArabic = regionNameArabic != null ? regionNameArabic : "";
		this.regionNameEnglish = regionNameEnglish != null ? regionNameEnglish : "";
		this.governorateNameArabic = governorateNameArabic != null ? governorateNameArabic : "";
		this.governorateNameEnglish = governorateNameEnglish != null ? governorateNameEnglish : "";
		this.buildingTypeCode = buildingTypeCode != null ? buildingTypeCode : "";
		this.usageTypeCode = usageTypeCode != null ? usageTypeCode : "";
		this.addressDateCreated = addressDateCreated != null ? addressDateCreated : "";
		this.addressOwners = addressOwners;

	}

	public java.lang.String getAddressDateCreated()
	{
		return addressDateCreated;
	}

	public List<AddressOwnerDTO> getAddressOwners()
	{
		return addressOwners;
	}

	public java.lang.Integer getAreaCode()
	{
		return areaCode;
	}

	public java.lang.String getAreaNameArabic()
	{
		return areaNameArabic;
	}

	public java.lang.String getAreaNameEnglish()
	{
		return areaNameEnglish;
	}

	public java.lang.String getBlockNameArabic()
	{
		return blockNameArabic;
	}

	public java.lang.String getBlockNameEnglish()
	{
		return blockNameEnglish;
	}

	public java.lang.Integer getBlockNumber()
	{
		return blockNumber;
	}

	public java.lang.String getBuildingNameArabic()
	{
		return buildingNameArabic;
	}

	public java.lang.String getBuildingNameEnglish()
	{
		return buildingNameEnglish;
	}

	public java.lang.Integer getBuildingNumber()
	{
		return buildingNumber;
	}

	public java.lang.String getBuildingTypeCode()
	{
		return buildingTypeCode;
	}

	public java.lang.Integer getFlatNumber()
	{
		return flatNumber;
	}

	public java.lang.String getGovernorateNameArabic()
	{
		return governorateNameArabic;
	}

	public java.lang.String getGovernorateNameEnglish()
	{
		return governorateNameEnglish;
	}

	public java.lang.String getNameAlphaArabic()
	{
		return nameAlphaArabic;
	}

	public java.lang.String getNameAlphaEnglish()
	{
		return nameAlphaEnglish;
	}

	public java.lang.String getRegionNameArabic()
	{
		return regionNameArabic;
	}

	public java.lang.String getRegionNameEnglish()
	{
		return regionNameEnglish;
	}

	public java.lang.String getRoadNameArabic()
	{
		return roadNameArabic;
	}

	public java.lang.String getRoadNameEnglish()
	{
		return roadNameEnglish;
	}

	public java.lang.Integer getRoadNumber()
	{
		return roadNumber;
	}

	public java.lang.String getUsageTypeCode()
	{
		return usageTypeCode;
	}

	public void setAddressDateCreated(java.lang.String addressDateCreated)
	{
		this.addressDateCreated = addressDateCreated;
	}

	public void setAddressOwners(List<AddressOwnerDTO> addressOwners)
	{
		addressOwners = addressOwners;
	}

	public void setAreaCode(java.lang.Integer areaCode)
	{
		this.areaCode = areaCode;
	}

	public void setAreaNameArabic(java.lang.String areaNameArabic)
	{
		this.areaNameArabic = areaNameArabic;
	}

	public void setAreaNameEnglish(java.lang.String areaNameEnglish)
	{
		this.areaNameEnglish = areaNameEnglish;
	}

	public void setBlockNameArabic(java.lang.String blockNameArabic)
	{
		this.blockNameArabic = blockNameArabic;
	}

	public void setBlockNameEnglish(java.lang.String blockNameEnglish)
	{
		this.blockNameEnglish = blockNameEnglish;
	}

	public void setBlockNumber(java.lang.Integer blockNumber)
	{
		this.blockNumber = blockNumber;
	}

	public void setBuildingNameArabic(java.lang.String buildingNameArabic)
	{
		this.buildingNameArabic = buildingNameArabic;
	}

	public void setBuildingNameEnglish(java.lang.String buildingNameEnglish)
	{
		this.buildingNameEnglish = buildingNameEnglish;
	}

	public void setBuildingNumber(java.lang.Integer buildingNumber)
	{
		this.buildingNumber = buildingNumber;
	}

	public void setBuildingTypeCode(java.lang.String buildingTypeCode)
	{
		this.buildingTypeCode = buildingTypeCode;
	}

	public void setFlatNumber(java.lang.Integer flatNumber)
	{
		this.flatNumber = flatNumber;
	}

	public void setGovernorateNameArabic(java.lang.String governorateNameArabic)
	{
		this.governorateNameArabic = governorateNameArabic;
	}

	public void setGovernorateNameEnglish(java.lang.String governorateNameEnglish)
	{
		this.governorateNameEnglish = governorateNameEnglish;
	}

	public void setNameAlphaArabic(java.lang.String nameAlphaArabic)
	{
		this.nameAlphaArabic = nameAlphaArabic;
	}

	public void setNameAlphaEnglish(java.lang.String nameAlphaEnglish)
	{
		this.nameAlphaEnglish = nameAlphaEnglish;
	}

	public void setRegionNameArabic(java.lang.String regionNameArabic)
	{
		this.regionNameArabic = regionNameArabic;
	}

	public void setRegionNameEnglish(java.lang.String regionNameEnglish)
	{
		this.regionNameEnglish = regionNameEnglish;
	}

	public void setRoadNameArabic(java.lang.String roadNameArabic)
	{
		this.roadNameArabic = roadNameArabic;
	}

	public void setRoadNameEnglish(java.lang.String roadNameEnglish)
	{
		this.roadNameEnglish = roadNameEnglish;
	}

	public void setRoadNumber(java.lang.Integer roadNumber)
	{
		this.roadNumber = roadNumber;
	}

	public void setUsageTypeCode(java.lang.String usageTypeCode)
	{
		this.usageTypeCode = usageTypeCode;
	}

}
