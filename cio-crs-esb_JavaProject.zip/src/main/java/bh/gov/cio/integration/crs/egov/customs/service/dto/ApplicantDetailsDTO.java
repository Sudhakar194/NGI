package bh.gov.cio.integration.crs.egov.customs.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlType(name = "RetrieveApplicantDetails", propOrder =
{ 		"cprNumber",
		"firstArabicName","middleArabicName1","middleArabicName2","middleArabicName3","middleArabicName4","lastArabicName",
		"firstEnglishName","middleEnglishName1","middleEnglishName2","middleEnglishName3","middleEnglishName4","lastEnglishName",
		"nationality","occupationEnglish","occupationArabic","workPlace","workType","dob"})
public class ApplicantDetailsDTO {

	
	
	
	
	public ApplicantDetailsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String cprNumber;
	
	private String firstArabicName;
	private String middleArabicName1;
	private String middleArabicName2;
	private String middleArabicName3;
	private String middleArabicName4;
	private String lastArabicName;
	
	
	private String firstEnglishName;
	private String middleEnglishName1;
	private String middleEnglishName2;
	private String middleEnglishName3;
	private String middleEnglishName4;
	private String lastEnglishName;

	private String dob;
	
	/**
	 * 1 GCC
	 * 0 NON GCC
	 */
	private String nationality; 
	
	private String occupationEnglish;
	private String occupationArabic;
	
	/**
	 * IF GOVERNMENT HARD CODED VALUE - GOV
	 */
	private String workPlace;
	
	/**
	 * 1 OWNER OF A COMPANY
	 * 2 WORKING IN GOVERNMENTAIL SECTOR
	 * 3 UNEMPLOYED
	 */
	private String workType;


	@XmlElement(name = "cprNumber")
	public String getCprNumber() {
		return cprNumber;
	}

	public void setCprNumber(String cprNumber) {
		this.cprNumber = cprNumber;
	}

	@XmlElement(name = "firstArabicName")
	public String getFirstArabicName() {
		return firstArabicName;
	}

	public void setFirstArabicName(String firstArabicName) {
		this.firstArabicName = firstArabicName;
	}

	@XmlElement(name = "middleArabicName1")
	public String getMiddleArabicName1() {
		return middleArabicName1;
	}

	public void setMiddleArabicName1(String middleArabicName1) {
		this.middleArabicName1 = middleArabicName1;
	}

	@XmlElement(name = "middleArabicName2")
	public String getMiddleArabicName2() {
		return middleArabicName2;
	}

	public void setMiddleArabicName2(String middleArabicName2) {
		this.middleArabicName2 = middleArabicName2;
	}

	@XmlElement(name = "middleArabicName3")
	public String getMiddleArabicName3() {
		return middleArabicName3;
	}

	public void setMiddleArabicName3(String middleArabicName3) {
		this.middleArabicName3 = middleArabicName3;
	}

	@XmlElement(name = "lastArabicName")
	public String getLastArabicName() {
		return lastArabicName;
	}

	public void setLastArabicName(String lastArabicName) {
		this.lastArabicName = lastArabicName;
	}

	@XmlElement(name = "firstEnglishName")
	public String getFirstEnglishName() {
		return firstEnglishName;
	}

	public void setFirstEnglishName(String firstEnglishName) {
		this.firstEnglishName = firstEnglishName;
	}

	@XmlElement(name = "middleEnglishName1")
	public String getMiddleEnglishName1() {
		return middleEnglishName1;
	}

	
	public void setMiddleEnglishName1(String middleEnglishName1) {
		this.middleEnglishName1 = middleEnglishName1;
	}

	@XmlElement(name = "middleEnglishName2")
	public String getMiddleEnglishName2() {
		return middleEnglishName2;
	}
	
	public void setMiddleEnglishName2(String middleEnglishName2) {
		this.middleEnglishName2 = middleEnglishName2;
	}

	@XmlElement(name = "middleEnglishName3")
	public String getMiddleEnglishName3() {
		return middleEnglishName3;
	}

	public void setMiddleEnglishName3(String middleEnglishName3) {
		this.middleEnglishName3 = middleEnglishName3;
	}

	@XmlElement(name = "lastEnglishName")
	public String getLastEnglishName() {
		return lastEnglishName;
	}

	public void setLastEnglishName(String lastEnglishName) {
		this.lastEnglishName = lastEnglishName;
	}

	@XmlElement(name = "nationality")
	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	@XmlElement(name = "occupationEnglish")
	public String getOccupationEnglish() {
		return occupationEnglish;
	}

	public void setOccupationEnglish(String occupationEnglish) {
		this.occupationEnglish = occupationEnglish;
	}

	@XmlElement(name = "occupationArabic")
	public String getOccupationArabic() {
		return occupationArabic;
	}

	public void setOccupationArabic(String occupationArabic) {
		this.occupationArabic = occupationArabic;
	}

	@XmlElement(name = "workPlace")
	public String getWorkPlace() {
		return workPlace;
	}

	public void setWorkPlace(String workPlace) {
		this.workPlace = workPlace;
	}

	@XmlElement(name = "workType")
	public String getWorkType() {
		return workType;
	}

	public void setWorkType(String workType) {
		this.workType = workType;
	}


	@XmlElement(name = "middleArabicName4")
	public String getMiddleArabicName4() {
		return middleArabicName4;
	}

	public void setMiddleArabicName4(String middleArabicName4) {
		this.middleArabicName4 = middleArabicName4;
	}

	@XmlElement(name = "middleEnglishName4")
	public String getMiddleEnglishName4() {
		return middleEnglishName4;
	}

	public void setMiddleEnglishName4(String middleEnglishName4) {
		this.middleEnglishName4 = middleEnglishName4;
	}

	@XmlElement(name = "dob")
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}




	
	
	
	
	
	
	
}
