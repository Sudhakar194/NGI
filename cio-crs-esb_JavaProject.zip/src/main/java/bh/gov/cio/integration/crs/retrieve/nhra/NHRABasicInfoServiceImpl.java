package bh.gov.cio.integration.crs.retrieve.nhra;

import java.util.Date;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.WebServiceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.nhra.service.NHRABasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.nhra.service.dto.NHRABasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NHRABasicInfoService", targetNamespace = "http://service.nhra.retrieve.crs.integration.cio.gov.bh/")
public class NHRABasicInfoServiceImpl implements NHRABasicInfoServiceInterface, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(NHRABasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationService;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

    @Resource
    private WebServiceContext context;
    
	@Override
	@Secured({ "ROLE_getNHRABasicInfo" })
	@WebMethod(operationName = "getNHRABasicInfo")
	public NHRABasicInfoDTO getNHRABasicInfo(SecurityTagObject security, String idNumber, String nationalityCode,
			Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("getNHRABasicInfo(Integer, Integer, Date) - start");
		}

		if (nationalityCode == null || "".equals(nationalityCode.trim())) {
			nationalityCode = "499";
		}

		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, nationalityCode);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "001"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "002"));
		}
		if (!validationService.hasValidBlock(cprNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number","003"));
		}
		if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date","006"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		PersonBasicInfo pbi;
		boolean isExpired = false;
		boolean isDead = false;
		try {

			pbi = ps.getPersonBasicInfo(cprNumber);

		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("RetrieveEmploymentBasicDetails(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Retrieving Data",
					new ApplicationException("Error Retrieving Data From Backend", "004"));
		}

		if (isDead) {
			throw new ApplicationExceptionInfo("Person is Dead", new ApplicationException("Person is Dead", "005"));
		}

		NHRABasicInfoDTO nhraBasicInfo;

		try {
			Date cardExpiry = validationService.getCPRNumberExpiry(cprNumber);
			isExpired = cardExpiry.before(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (isExpired) {
			throw new ApplicationExceptionInfo("Person Smartcard Expired",
					new ApplicationException("Person Smartcard Expired", "007"));
		}

		if (!pbi.getIsActive().equalsIgnoreCase("T")) {
			throw new ApplicationExceptionInfo("CPR Number Not Active",
					new ApplicationException("CPR Number Not Active", "008"));
		}
		nhraBasicInfo = new NHRABasicInfoDTO(pbi.getArabicName(), pbi.getEnglishName());

		if (logger.isDebugEnabled()) {
			logger.debug("getNHRABasicInfo(Integer, Integer, Date) - end");
		}
		return nhraBasicInfo;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationService;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationService) {
		this.validationService = validationService;
	}
}
