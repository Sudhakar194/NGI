package bh.gov.cio.integration.crs.retrieve.address;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.util.exception.AddressLoadException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.retrieve.address.service.RoadSearchServiceInterface;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.RoadSearchInfoDTO;
import bh.gov.cio.integration.crs.retrieve.person.OrphanBasicInfoServiceImpl;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "AddressSearchService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
public class RoadSearchServiceImpl implements RoadSearchServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(OrphanBasicInfoServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Override
	@Secured(
	{ "ROLE_searchRoadInformationByName" })
	@WebMethod(operationName = "searchRoadInformationByName")
	public List<RoadSearchInfoDTO> searchRoadInformationByName(SecurityTagObject security, String roadName)
			throws ApplicationExceptionInfo
	{

		List<RoadSearchInfoDTO> returnRoadList = new ArrayList<RoadSearchInfoDTO>();

		try
		{

			List<Address> addresses = getCrsService().getAddressServiceRef().getRoadNumber(roadName);

			if (addresses.size() == 0)
			{
				throw new ApplicationExceptionInfo("road Not found", new ApplicationException("road Not found"));
			}

			if (addresses != null)
			{
				if (logger.isDebugEnabled())
				{
					logger.error("Address size List: " + addresses.size() + "  road name: " + roadName );
				}
				for (final Address address : addresses)
				{	
						returnRoadList.add(new RoadSearchInfoDTO(address.getRoadNumber(),address.getRoadNameArabic(),
								address.getRoadNameEnglish(),address.getBlockNumber(),address.getAreaNameArabic(),address.getAreaNameEnglish()));

				}

			}
		}

		catch (AddressLoadException e)
		{

			e.printStackTrace();
		}
		catch (bh.gov.cio.crs.util.exception.ApplicationException e)
		{
			e.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("searchRoadInformationByName(String) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("road Not found", new ApplicationException("road Not found"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("searchRoadInformationByName(String) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("road Not found", new ApplicationException("road Not found"));
		}
		if (logger.isDebugEnabled())
		{
			logger.debug("searchRoadInformationByName(String) - end");
		}

		return returnRoadList;
	}


	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}



}
