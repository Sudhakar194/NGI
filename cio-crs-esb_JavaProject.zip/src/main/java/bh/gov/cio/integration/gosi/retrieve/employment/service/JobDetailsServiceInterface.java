package bh.gov.cio.integration.gosi.retrieve.employment.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.gosi.retrieve.employment.service.dto.JobDetailsDTO;

@WebService(name = "JobDetailsService", targetNamespace = "http://bh.gov.cio.integration.gosi.retrieve.employment.service/")
public interface JobDetailsServiceInterface
{

	@WebResult(name = "JobInformation")
	@WebMethod(operationName = "getJobDetails")
	JobDetailsDTO getJobDetails(@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber);
}
