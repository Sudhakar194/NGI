package bh.gov.cio.integration.crs.retrieve.ewa;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.nas.AddressOwner;
import bh.gov.cio.crs.model.nas.Building;
import bh.gov.cio.crs.model.nas.BuildingSearchItems;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.EmploymentService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.ewa.service.EWABasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.ewa.service.dto.EWAServiceBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.ewa.service.dto.EWAServiceFlatListDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonEWABasicInfoService", targetNamespace = "http://service.ewa.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonEWABasicInfoService"
public class EWABasicInfoServiceImpl implements EWABasicInfoServiceInterface, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(EWABasicInfoServiceImpl.class);
	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getEWABasicInfo" })
	@WebMethod(operationName = "getEWABasicInfo")
	public EWAServiceBasicInfoDTO getPersonEWABasicInfo(SecurityTagObject security, String CountryCode, String idNumber)
			throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled())
			logger.debug("getPersonEWABasicInfo(Integer, IDType) - start");

		EWAServiceBasicInfoDTO ewaServiceBasicInfoDTO = null;
		PersonService ps = crsService.getPersonServiceRef();
		EmploymentService es = crsService.getEmploymentServiceRef();

		Integer cprNumber = 0;

		try {
			cprNumber = validationUtil.getGCCCpr(idNumber, CountryCode);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "001"));
		}

		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "002"));
		}
		boolean isExpired = false;
		try {
			Date cardExpiry = validationUtil.getCPRNumberExpiry(cprNumber);
			isExpired = cardExpiry.before(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			PersonBasicInfo pbi = ps.getPersonBasicInfo(cprNumber);
			PersonSummary psi = ps.getPersonSummary(cprNumber);
			String nationalityCode = pbi.getNationalityCode();

			ewaServiceBasicInfoDTO = new EWAServiceBasicInfoDTO(psi.getArabicFirstName(), psi.getArabicMiddleName1(),
					psi.getArabicMiddleName2(), psi.getArabicMiddleName3(), psi.getArabicMiddleName4(),
					psi.getArabicFamilyName(), psi.getEnglishFirstName(), psi.getEnglishMiddleName1(),
					psi.getEnglishMiddleName2(), psi.getEnglishMiddleName3(), psi.getEnglishMiddleName4(),
					psi.getEnglishFamilyName(),
					((validationUtil.isBahraini(nationalityCode) ? Nationality.Bahraini
							: (validationUtil.isGCC(nationalityCode) ? Nationality.GCC : Nationality.Other))),
					pbi.getGender() == "M" ? Gender.M : Gender.F, psi.isDead(), es.isDomesticWorker(cprNumber),
					pbi.getAge() >= 18, isExpired);
		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getPersonEWABasicInfo(Integer, IDType) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Employment Basic Details Not found",
					new ApplicationException(exception.getMessage(), "003"));
		}
		return ewaServiceBasicInfoDTO;
	}

	@Override
	@Secured({ "ROLE_getEWABasicInfo" })
	@WebMethod(operationName = "getOwnerFlatNumbers")
	public EWAServiceFlatListDTO getOwnerFlatNumbers(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "CountryCode") @XmlElement(required = true) String CountryCode,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "BuildingNumber") @XmlElement(required = true) Integer buildingNumber,
			@WebParam(name = "BuildingAlpha") @XmlElement(required = true) String buildingAlpha,
			@WebParam(name = "RoadNumber") @XmlElement(required = true) Integer roadNumber,
			@WebParam(name = "BlockNumber") @XmlElement(required = true) Integer blockNumber)
			throws ApplicationExceptionInfo {
		EWAServiceFlatListDTO result = new EWAServiceFlatListDTO();
		Integer cprNumber = 0;

		try {
			cprNumber = validationUtil.getGCCCpr(idNumber, CountryCode);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "001"));
		}

		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "002"));
		}
		boolean isExpired = false;
		try {
			Date cardExpiry = validationUtil.getCPRNumberExpiry(cprNumber);
			isExpired = cardExpiry.before(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		BuildingSearchItems bsi = new BuildingSearchItems(buildingNumber, roadNumber, blockNumber, buildingAlpha);
		ArrayList<Integer> flatNumbers = new ArrayList<Integer>();
		ArrayList<AddressOwner> addList = null;
		ArrayList<Building> bldgs = null;
		ArrayList<Address> addresses = null;
		// check if cpr is one of the owners
		boolean ownerFound = false;
		try {
			bldgs = (ArrayList<Building>) getCrsService().getAddressServiceRef().getBuildingDetails(bsi);
			for (Building building : bldgs) {
				addresses = (ArrayList<Address>) building.getAddresses();
				for (Address address : addresses) {
					addList = (ArrayList<AddressOwner>) getCrsService().getAddressServiceRef()
							.getAddressOwner(address.getAddressSn());

					logger.debug("Address Search Size: {}", addList.size());
					for (Iterator<AddressOwner> iterator = addList.iterator(); iterator.hasNext();) {
						AddressOwner addressOwner = (AddressOwner) iterator.next();
						logger.debug("Owner Number : {}", addressOwner.getAddressOwnerId());
						if (addressOwner.getAddressOwnerId().equals(cprNumber + "")) {
							ownerFound = true;
							break;
						}

					}
					logger.debug("Flat Number : {}", address.getFlatNumber());
					flatNumbers.add(address.getFlatNumber());
				}
			}

		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Address is Not correct",
					new ApplicationException("Address is Not correct", "003"));
		}

		if (!ownerFound)
			throw new ApplicationExceptionInfo("Owner CPR is Not Match",
					new ApplicationException("Owner CPR is Not Match", "004"));
		result.setFlatsNumber(flatNumbers);
		return result;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

}
