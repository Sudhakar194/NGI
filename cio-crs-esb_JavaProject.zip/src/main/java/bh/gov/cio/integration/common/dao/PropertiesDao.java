package bh.gov.cio.integration.common.dao;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class PropertiesDao
{
	/**
	 * Logger for this class
	 */
	private static final Logger					logger				= LoggerFactory.getLogger(PropertiesDao.class);

	public static final String					PROP_NAME			= "PROP_NAME";
	public static final String					PROP_VALUE			= "PROP_VALUE";
	public static final String					ENV_TYPE_ID			= "ENV_TYPE_ID";

	@Autowired
	private final NamedParameterJdbcTemplate	ESBNamedTemplate	= null;

	@SuppressWarnings(
	{ "unchecked", "rawtypes" })
	@Transactional(propagation = Propagation.SUPPORTS)
	public List<Map<String, Object>> getCurrentServerProperties()
			throws Exception, UnknownHostException,
			CannotGetJdbcConnectionException
	{
		final String serverIP = InetAddress.getLocalHost().getHostAddress();
		if (logger.isDebugEnabled())
			logger.debug("getCurrentServerProperties() - Server IP:" + serverIP);
		final SqlParameterSource params = new MapSqlParameterSource().addValue(
				"ip", serverIP);
		final List<Map<String, Object>> props = ESBNamedTemplate
				.query("SELECT PROP_NAME,PROP_VALUE FROM ESBADMIN.APP_PROP WHERE ENV_TYPE_ID =(select ENV_TYPE_ID from ESBADMIN.ENV_TYPE where IP = :ip)",
						params, new RowMapper()
						{
							@Override
							public Object mapRow(ResultSet rs, int currentIndex)
									throws SQLException
							{
								final HashMap item = new HashMap();
								final String prop_name = rs
										.getString(PROP_NAME);
								final String prop_value = rs
										.getString(PROP_VALUE);
								if (logger.isDebugEnabled())
									logger.debug("mapRow(ResultSet, int) - prop_name = "
											+ prop_name
											+ "  prop_value = "
											+ prop_value);
								item.put(prop_name, prop_value);
								return item;
							}
						});
		if (logger.isDebugEnabled())
			logger.debug("getCurrentServerProperties() - props" + props);
		if (props.size() == 0)
			throw new Exception("No Props Found");
		return props;
	}
}
