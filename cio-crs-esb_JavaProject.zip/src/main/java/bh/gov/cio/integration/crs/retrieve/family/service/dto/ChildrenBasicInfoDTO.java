package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import java.util.ArrayList;

public class ChildrenBasicInfoDTO {
	private ArrayList<ChildrenDetailDTO> childrenDetail;

	public ChildrenBasicInfoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ChildrenBasicInfoDTO(ArrayList<ChildrenDetailDTO> childrenDetail) {
		super();
		this.childrenDetail = childrenDetail;
	}

	public ArrayList<ChildrenDetailDTO> getChildrenDetail() {
		return childrenDetail;
	}

	public void setChildrenDetail(ArrayList<ChildrenDetailDTO> childrenDetail) {
		this.childrenDetail = childrenDetail;
	}

}
