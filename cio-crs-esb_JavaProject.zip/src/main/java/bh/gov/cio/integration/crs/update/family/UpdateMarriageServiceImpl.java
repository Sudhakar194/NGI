package bh.gov.cio.integration.crs.update.family;

import java.io.IOException;
import java.io.Writer;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import bh.gov.cio.crs.model.person.IndMarriageDivorce;
import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSearchInputs;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.util.exception.ApplicationException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.update.family.service.UpdateMarriageServiceInterface;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

@Controller
public class UpdateMarriageServiceImpl implements UpdateMarriageServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(UpdateMarriageServiceImpl.class);

	private String userLastUpdate = "MOJ";
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	@Autowired
	private ValidationServiceImpl validationUtil;

	@Override
	@RequestMapping(value = "/service/deleteMarriage.service", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@Secured({ "ROLE_deleteMarriage" })
	public @ResponseBody String deleteMarriage(@RequestParam(value = "husbandCPR", required = true) Integer husbandCPR,
			@RequestParam(value = "wifeCPR", required = true) Integer wifeCPR,
			@RequestParam(value = "marriageDate", required = true) String marriageDate)
			throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException {
		int isSuccess = -1;
		if (logger.isDebugEnabled()) {
			logger.debug("deleteMarriage(Integer, Integer, String) - Server IP:"
					+ InetAddress.getLocalHost().getHostAddress());
		}

		if (logger.isDebugEnabled()) {
			logger.debug("deleteMarriage(Integer husbandCPR = " + husbandCPR + ", Integer wifeCPR = " + wifeCPR
					+ ", String marriageDate = " + marriageDate + ")");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("deleteMarriage(Integer, Integer, String) - start");
		}

		if (((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0)))
				&& (validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0))) {
			isSuccess = 3;
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0)) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0)) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if (((validationUtil.isValidCpr(husbandCPR) == true) || (husbandCPR.equals(0)))
				&& ((validationUtil.isValidCpr(wifeCPR) == true) || (wifeCPR.equals(0)))) {
			getCrsService().getFamilyServiceRef().deleteMarriage(husbandCPR, wifeCPR,
					DateServiceImpl.formatDate(marriageDate));
			isSuccess = 0;
		}

		return isSuccess + "";

	}

	@Override
	@RequestMapping(value = "/service/deleteMarriageByID.service", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@Secured({ "ROLE_deleteMarriage" })
	public @ResponseBody String deleteMarriage(@RequestParam(value = "husbandID", required = true) String husbandID,
			@RequestParam(value = "husbandNationalityCode", required = true) String husbandNationalityCode,
			@RequestParam(value = "wifeID", required = true) String wifeID,
			@RequestParam(value = "wifeNationalityCode", required = true) String wifeNationalityCode,
			@RequestParam(value = "marriageDate", required = true) String marriageDate)
			throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException {
		int isSuccess = -1;
		if (logger.isDebugEnabled()) {
			logger.debug("deleteMarriageByID(Integer, Integer, String) - Server IP:"
					+ InetAddress.getLocalHost().getHostAddress());
		}
		Integer husbandCPR = -1, wifeCPR = -1;
		// if (husbandNationalityCode.equalsIgnoreCase("411") ||
		// husbandNationalityCode.equalsIgnoreCase("430")
		// || husbandNationalityCode.equalsIgnoreCase("436") ||
		// husbandNationalityCode.equalsIgnoreCase("440")
		// || husbandNationalityCode.equalsIgnoreCase("930") ||
		// husbandNationalityCode.equalsIgnoreCase("441")
		// || husbandNationalityCode.equalsIgnoreCase("940"))
		// {
		husbandCPR = validationUtil.getGCCCpr(husbandID, husbandNationalityCode);
		// }
		// else
		// {
		// try
		// {
		// husbandCPR = Integer.parseInt(husbandID);
		// }
		// catch (Exception exception)
		// {
		// exception.printStackTrace();
		// }
		// }
		// if (wifeNationalityCode.equalsIgnoreCase("411") ||
		// wifeNationalityCode.equalsIgnoreCase("430") ||
		// wifeNationalityCode.equalsIgnoreCase("436")
		// || wifeNationalityCode.equalsIgnoreCase("440") ||
		// wifeNationalityCode.equalsIgnoreCase("930")
		// || wifeNationalityCode.equalsIgnoreCase("441") ||
		// wifeNationalityCode.equalsIgnoreCase("940"))
		// {
		wifeCPR = validationUtil.getGCCCpr(wifeID, wifeNationalityCode);
		// }
		// else
		// {
		// try
		// {
		// wifeCPR = Integer.parseInt(wifeID);
		// }
		// catch (Exception exception)
		// {
		// exception.printStackTrace();
		// }
		// }
		if (logger.isDebugEnabled()) {
			logger.debug("deleteMarriageByID(Integer husbandCPR = " + husbandCPR + ", Integer wifeCPR = " + wifeCPR
					+ ", String marriageDate = " + marriageDate + ")");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("deleteMarriageByID(Integer, Integer, String) - start");
		}

		if (((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0)))
				&& (validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0))) {
			isSuccess = 3;
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && (!husbandCPR.equals(0)) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(wifeCPR) != true) && (!wifeCPR.equals(0)) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if (((validationUtil.isValidCpr(husbandCPR) == true) || (husbandCPR.equals(0)))
				&& ((validationUtil.isValidCpr(wifeCPR) == true) || (wifeCPR.equals(0)))) {
			getCrsService().getFamilyServiceRef().deleteMarriage(husbandCPR, wifeCPR,
					DateServiceImpl.formatDate(marriageDate));
			isSuccess = 0;
		}

		return isSuccess + "";

	}

	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@RequestMapping("/service/getMarriageDates.service")
	@ResponseBody
	@Secured({ "ROLE_getMarriageDates" })
	public String getMarriageDates(@RequestParam(value = "CPRNumber", required = true) Integer CPRNumber)
			throws ApplicationExceptionInfo, UnknownHostException, ApplicationException, BusinessException {
		int isSuccess = -1;
		String dates = "";
		if (logger.isDebugEnabled()) {
			logger.debug("getMarriageDates(Integer CPRNumber = " + CPRNumber);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getMarriageDates(Integer, Integer) - start");
		}

		if ((validationUtil.isValidCpr(CPRNumber) != true) && (!CPRNumber.equals(0))) {
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(CPRNumber) == true) || CPRNumber.equals(0)) {
			FamilyService familyService = getCrsService().getFamilyServiceRef();
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(CPRNumber);

			if (logger.isDebugEnabled()) {
				logger.debug("getMarriageDates(CPRNumber = " + CPRNumber + ") -  : hm = " + hm);
			}
			if (hm != null) {
				for (final Marriage marriageDivorce : hm) {
					final Marriage spouse = marriageDivorce;
					List<IndMarriageDivorce> ind = spouse.getIndMarriageDivorceList();
					if (ind != null) {
						for (final IndMarriageDivorce indMarriageDivorce : ind) {
							if (indMarriageDivorce.getActionType().equalsIgnoreCase("MARRIAGE")) {
								if (dates == "") {
									dates = indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								} else {
									dates = dates + ";" + indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								}

							}
						}
					}
				}

				isSuccess = 0;
			}

		}

		if (logger.isDebugEnabled()) {
			logger.debug("getMarriageDates(Integer, Integer) - end");
			logger.debug("getMarriageDates() -  : isSuccess = " + isSuccess);
		}
		return isSuccess != 0 ? isSuccess + "" : (dates != "" ? dates : "0");

	}

	@Override
	@RequestMapping("/service/getMarriageDatesByID.service")
	@ResponseBody
	@Secured({ "ROLE_getMarriageDates" })
	public String getMarriageDates(@RequestParam(value = "IDNumber", required = true) String IDNumber,
			@RequestParam(value = "nationalityCode", required = true) String nationalityCode)
			throws ApplicationExceptionInfo, UnknownHostException, ApplicationException, BusinessException {
		int isSuccess = -1;
		String dates = "";
		Integer CPRNumber = -1;
		// if (nationalityCode.equalsIgnoreCase("411") ||
		// nationalityCode.equalsIgnoreCase("430")
		// || nationalityCode.equalsIgnoreCase("436") ||
		// nationalityCode.equalsIgnoreCase("440")
		// || nationalityCode.equalsIgnoreCase("930") ||
		// nationalityCode.equalsIgnoreCase("441")
		// || nationalityCode.equalsIgnoreCase("940")) {
		CPRNumber = validationUtil.getGCCCpr(IDNumber, nationalityCode);
		// } else {
		// try {
		// CPRNumber = Integer.parseInt(IDNumber);
		// } catch (Exception exception) {
		// exception.printStackTrace();
		// }
		// }

		if (logger.isDebugEnabled()) {
			logger.debug("getMarriageDatesByID(Integer CPRNumber = " + CPRNumber);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("getMarriageDatesByID(Integer, Integer) - start");
		}

		if ((validationUtil.isValidCpr(CPRNumber) != true) && (!CPRNumber.equals(0))) {
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(CPRNumber) == true) || CPRNumber.equals(0)) {
			FamilyService familyService = getCrsService().getFamilyServiceRef();
			final List<Marriage> hm = familyService.getPersonMarriageDivorceList(CPRNumber);

			if (logger.isDebugEnabled()) {
				logger.debug("getMarriageDatesByID(CPRNumber = " + CPRNumber + ") -  : hm = " + hm);
			}
			if (hm != null) {
				for (final Marriage marriageDivorce : hm) {
					final Marriage spouse = marriageDivorce;
					List<IndMarriageDivorce> ind = spouse.getIndMarriageDivorceList();
					if (ind != null) {
						for (final IndMarriageDivorce indMarriageDivorce : ind) {
							if (indMarriageDivorce.getActionType().equalsIgnoreCase("MARRIAGE")) {
								if (dates == "") {
									dates = indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								} else {
									dates = dates + ";" + indMarriageDivorce.getPartnerCprNumber() + ","
											+ DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
								}

							}
						}
					}
				}

				isSuccess = 0;
			}

		}

		if (logger.isDebugEnabled()) {
			logger.debug("getMarriageDatesByID(Integer, Integer) - end");
			logger.debug("getMarriageDatesByID() -  : isSuccess = " + isSuccess);
		}
		return isSuccess != 0 ? isSuccess + "" : (dates != "" ? dates : "0");

	}

	public String getUserLastUpdate() {
		return userLastUpdate;
	}

	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@ExceptionHandler(Exception.class)
	// @ResponseStatus(value = HttpStatus.OK, reason = "Contact not found")
	@ResponseBody
	public void handleException(final Exception e, final HttpServletRequest request, Writer writer) throws IOException {
		logger.error("updateMarriage(Integer, Integer, String)", e);
		if (e.getMessage().equals("COUPLE_ALREADY_MARRIED")) {
			writer.write("0");
		} else {
			writer.write("9 " + e.getMessage());
		}
	}

	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	public void setUserLastUpdate(String userLastUpdate) {
		this.userLastUpdate = userLastUpdate;
	}

	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

	@Override
	@RequestMapping(value = "/service/updateMarriage.service", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@Secured({ "ROLE_updateMarriage" })
	public @ResponseBody String updateMarriage(@RequestParam(value = "husbandCPR", required = true) Integer husbandCPR,
			@RequestParam(value = "wifeCPR", required = true) Integer wifeCPR,
			@RequestParam(value = "marriageDate", required = true) String marriageDate)
			throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException {
		int isSuccess = -1;
		if (logger.isDebugEnabled()) {
			logger.debug("updateMarriage(Integer, Integer, String) - Server IP:"
					+ InetAddress.getLocalHost().getHostAddress());
		}

		if (logger.isDebugEnabled()) {
			logger.debug("updateMarriage(Integer husbandCPR = " + husbandCPR + ", Integer wifeCPR = " + wifeCPR
					+ ", String marriageDate = " + marriageDate + ")");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("updateMarriage(Integer, Integer, String) - start");
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && (validationUtil.isValidCpr(wifeCPR) != true)) {
			isSuccess = 3;
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(wifeCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if ((validationUtil.isValidCpr(husbandCPR) == true) && (validationUtil.isValidCpr(wifeCPR) == true)) {
			getCrsService().getFamilyServiceRef().registerMarriage(husbandCPR, wifeCPR,
					DateServiceImpl.getDateTimeFormatString(marriageDate), userLastUpdate);
			isSuccess = 0;
		}

		return isSuccess + "";

	}

	@Override
	@RequestMapping(value = "/service/updateMarriageByID.service", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@Secured({ "ROLE_updateMarriage" })
	public @ResponseBody String updateMarriage(@RequestParam(value = "husbandID", required = true) String husbandID,
			@RequestParam(value = "husbandNationalityCode", required = true) String husbandNationalityCode,
			@RequestParam(value = "wifeID", required = true) String wifeID,
			@RequestParam(value = "wifeNationalityCode", required = true) String wifeNationalityCode,
			@RequestParam(value = "marriageDate", required = true) String marriageDate)
			throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException {
		int isSuccess = -1;
		if (logger.isDebugEnabled()) {
			logger.debug("updateMarriageByID(Integer, Integer, String) - Server IP:"
					+ InetAddress.getLocalHost().getHostAddress());
		}
		Integer husbandCPR = -1, wifeCPR = -1;
		// if (husbandNationalityCode.equalsIgnoreCase("411") ||
		// husbandNationalityCode.equalsIgnoreCase("430")
		// || husbandNationalityCode.equalsIgnoreCase("436") ||
		// husbandNationalityCode.equalsIgnoreCase("440")
		// || husbandNationalityCode.equalsIgnoreCase("930") ||
		// husbandNationalityCode.equalsIgnoreCase("441")
		// || husbandNationalityCode.equalsIgnoreCase("940")) {
		husbandCPR = validationUtil.getGCCCpr(husbandID, husbandNationalityCode);
		// } else {
		// try {
		// husbandCPR = Integer.parseInt(husbandID);
		// } catch (Exception exception) {
		// exception.printStackTrace();
		// }
		// }
		// if (wifeNationalityCode.equalsIgnoreCase("411") ||
		// wifeNationalityCode.equalsIgnoreCase("430")
		// || wifeNationalityCode.equalsIgnoreCase("436") ||
		// wifeNationalityCode.equalsIgnoreCase("440")
		// || wifeNationalityCode.equalsIgnoreCase("930") ||
		// wifeNationalityCode.equalsIgnoreCase("441")
		// || wifeNationalityCode.equalsIgnoreCase("940")) {
		wifeCPR = validationUtil.getGCCCpr(wifeID, wifeNationalityCode);
		// } else {
		// try {
		// wifeCPR = Integer.parseInt(wifeID);
		// } catch (Exception exception) {
		// exception.printStackTrace();
		// }
		// }
		if (logger.isDebugEnabled()) {
			logger.debug("updateMarriageByID(Integer husbandCPR = " + husbandCPR + ", Integer wifeCPR = " + wifeCPR
					+ ", String marriageDate = " + marriageDate + ")");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("updateMarriageByID(Integer, Integer, String) - start");
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && (validationUtil.isValidCpr(wifeCPR) != true)) {
			isSuccess = 3;
		}

		if ((validationUtil.isValidCpr(husbandCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 1;
		}

		if ((validationUtil.isValidCpr(wifeCPR) != true) && isSuccess != 3) {
			// cpr
			// not
			// valid
			isSuccess = 2;
		}

		if ((validationUtil.isValidCpr(husbandCPR) == true) && (validationUtil.isValidCpr(wifeCPR) == true)) {
			getCrsService().getFamilyServiceRef().registerMarriage(husbandCPR, wifeCPR,
					DateServiceImpl.getDateTimeFormatString(marriageDate), userLastUpdate);
			isSuccess = 0;
		}

		return isSuccess + "";

	}

	@Override
	@RequestMapping(value = "/service/getCPRByName.service", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	@Secured({ "ROLE_getCPRByName" })
	public @ResponseBody String getCPRsByName(@RequestParam(value = "name", required = true) String citizenName)
			throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException {
		// logger.setLevel(Level.FATAL);
		if (logger.isDebugEnabled()) {
			logger.debug("getCPRsByName(String) - start");
			// logger.setLevel(Level.OFF);
		}

		List<String> CPRs = new ArrayList<String>();
		// String name = "%" + citizenName.replace(" ", "%") + "%";
		List<PersonBasicInfo> tempList = new ArrayList<PersonBasicInfo>();
		if (logger.isDebugEnabled()) {
			PersonSearchInputs psi = new PersonSearchInputs();
			// String search = new String(citizenName.getBytes("UTF-8"));
			// String str =
			// org.apache.commons.lang.StringEscapeUtils.unescapeJava(citizenName);

			String str = citizenName.split(" ")[0];
			str = str.replace("\\", "");
			String[] arr = str.split("u");
			String text = "";
			for (int i = 1; i < arr.length; i++) {
				int hexVal = Integer.parseInt(arr[i], 16);
				text += (char) hexVal;
			}

			// logger.debug("STR : " + text);
			// psi.setArabicFirstName(text);
			// tempList =
			// getCrsService().getPersonServiceRef().getPersonsMatching(psi);

			tempList = getCrsService().getPersonServiceRef().getPersonArEnName(text.replace(" ", "%"));
		}

		if (null == tempList || tempList.isEmpty()) {
			throw new ApplicationException("Citizen CPR Not Found");
		}
		for (Iterator<PersonBasicInfo> iterator = tempList.iterator(); iterator.hasNext();) {
			PersonBasicInfo personBasicInfo = (PersonBasicInfo) iterator.next();
			CPRs.add(personBasicInfo.getCprString());
		}

		String returnString = CPRs.toString();
		if (logger.isDebugEnabled()) {
			logger.debug("getCPRsByName(String) - end");
		}
		return returnString;

	}
}
