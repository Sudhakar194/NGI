package bh.gov.cio.integration.crs.retrieve.family.rco.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "cprNumber", "arabicName", "englishName", "maritalStatusCode", "employmentStatusCode",
		"age", "gender", "bahraini", "alive", "haveChildren" })
public class ChildrenRCODetailDTO {
	private Integer cprNumber;

	private String arabicName;
	private String englishName;
	private String maritalStatusCode;
	private String employmentStatusCode;
	private String age;
	private String gender;
	private boolean isBahraini;
	private boolean isAlive;
	private boolean haveChildren;

	public ChildrenRCODetailDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ChildrenRCODetailDTO(Integer cprNumber, String arabicName, String englishName, String maritalStatusCode,
			String employmentStatusCode, String age, String gender,
			boolean isBahraini, boolean isAlive, boolean haveChildren) {
		super();
		this.cprNumber = cprNumber != null ? cprNumber : 0;
		this.arabicName = arabicName != null ? arabicName : "";
		this.englishName = englishName != null ? englishName : "";
		this.maritalStatusCode = maritalStatusCode != null ? maritalStatusCode : "";
		this.employmentStatusCode = employmentStatusCode != null ? employmentStatusCode : "";
		this.age = age != null ? age : "";
		this.gender = gender != null ? gender : "";
		this.isBahraini = isBahraini;
		this.isAlive = isAlive;
		this.haveChildren = haveChildren;
	}

	@XmlElement(required = true)
	public String getArabicName() {
		return arabicName;
	}

	@XmlElement(required = true)
	public Integer getCprNumber() {
		return cprNumber;
	}

	@XmlElement(required = true)
	public String getAge() {
		return age;
	}

	@XmlElement(required = true)
	public String getEmploymentStatusCode() {
		return employmentStatusCode;
	}

	@XmlElement(required = true)
	public String getEnglishName() {
		return englishName;
	}

	@XmlElement(required = true)
	public String getGender() {
		return gender;
	}

	@XmlElement(required = true)
	public String getMaritalStatusCode() {
		return maritalStatusCode;
	}

	@XmlElement(required = true)
	public boolean isBahraini() {
		return isBahraini;
	}


	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public void setBahraini(boolean isBahraini) {
		this.isBahraini = isBahraini;
	}

	public void setCprNumber(Integer cprNumber) {
		this.cprNumber = cprNumber;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public void setEmploymentStatusCode(String employmentStatusCode) {
		this.employmentStatusCode = employmentStatusCode;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setMaritalStatusCode(String maritalStatusCode) {
		this.maritalStatusCode = maritalStatusCode;
	}

	public boolean isAlive() {
		return isAlive;
	}

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	public boolean isHaveChildren() {
		return haveChildren;
	}

	public void setHaveChildren(boolean haveChildren) {
		this.haveChildren = haveChildren;
	}

}
