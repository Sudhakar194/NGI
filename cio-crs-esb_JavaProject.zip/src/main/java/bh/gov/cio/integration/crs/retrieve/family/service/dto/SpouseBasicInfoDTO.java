package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder =
{ "spouseDetail" })
public class SpouseBasicInfoDTO
{
	private SpouseDetailDTO[]	spouseDetail;

	public SpouseBasicInfoDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public SpouseBasicInfoDTO(SpouseDetailDTO[] spouseDetail)
	{
		super();
		this.spouseDetail = spouseDetail;
	}

	@XmlElement(required = true)
	public SpouseDetailDTO[] getSpouseDetail()
	{
		return spouseDetail;
	}

	public void setSpouseDetail(SpouseDetailDTO[] spouseDetail)
	{
		this.spouseDetail = spouseDetail;
	}

}
