package bh.gov.cio.integration.crs.retrieve.person;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.GDNPRDocument;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.person.Smartcard;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.CSO018PersonBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.CSO018PersonBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CSO018PersonBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "CSO018PersonBasicInfoService"
public class CSO018PersonBasicInfoServiceImpl implements CSO018PersonBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(CSO018PersonBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Override
	@Secured(
	{ "ROLE_CSO018getPersonBasicInfo" })
	@WebMethod(operationName = "getCSO018PersonBasicInfo")
	public CSO018PersonBasicInfoDTO getCSO018PersonBasicInfo(SecurityTagObject security, String idNumber, String nationalityCode,
			String cardCountrycode, String dateOfBirth)
			throws ApplicationExceptionInfo
	{
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		CSO018PersonBasicInfoDTO personBasicInfoDTO = new CSO018PersonBasicInfoDTO();;
		
		personBasicInfoDTO.setReturnCode("0");
		
		Integer cprNumber = 0;
		
		if (logger.isDebugEnabled())
		{
			logger.debug("getCSO018PersonBasicInfo(String, String, String, String) - start");
		}
		
		if(cardCountrycode == null || cardCountrycode.equalsIgnoreCase("")){
			cardCountrycode = "499";
		}
		try{
			cprNumber = validationUtil.getGCCCpr(idNumber, nationalityCode);
		}catch(Exception e){
			// TODO: handle exception
			e.printStackTrace();
			throw new ApplicationExceptionInfo("Error Retrieving Student Information ...",
					new ApplicationException("GCC ID Validation General Exception.", "002"));
		}

//		Integer id = -1;
//		try {
//			id = getCrsService().getPersonServiceRef().getGccNationalSn(idNumber, cardCountrycode);
//			logger.debug("id Number"+id);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			logger.debug("NO GCC SN FOUND");
//		}
//
//		if(id == null || id < 0 ){
//		try{
//			
//			cprNumber = Integer.parseInt(idNumber);
//		}catch(Exception e){
//			 personBasicInfoDTO.setReturnCode("14");
//			 return personBasicInfoDTO;
//		}
//
//		
//		}else{
//			cprNumber = id;
//		}
				
				
//		 if (validationUtil.isMilitaryCpr(cprNumber))
//		 {
//			 personBasicInfoDTO.setReturnCode("14");
//			 return personBasicInfoDTO;
//		 }

		try
		{
			PersonSummary personSummeryInfo = null;
			
			try{
				
			 personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			
			}catch(Exception b2){
				logger.debug("person summary not found");
				 personBasicInfoDTO.setReturnCode("14");
				 return personBasicInfoDTO;
			}
			
			
			if (validationUtil.isDeletedCpr(cprNumber))
			{
				logger.debug("CPR Deleted");
				 personBasicInfoDTO.setReturnCode("14");
				 return personBasicInfoDTO;
			}
			
			final List<Smartcard> smartcards = getCrsService().getPersonServiceRef().getActivePersonSmartcards(cprNumber);
			
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499") || personSummeryInfo.getNationalityCountryCode()
					.equals("900")) ? true : false;
			final String actualNationality = (personSummeryInfo.getNationalityCountryCode().equals("900")) ? "499" : personSummeryInfo.getNationalityCountryCode();
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			
			
			String formatedDOB = sdf.format(personSummeryInfo.getDateOfBirth());
			
			
			if(nationalityCode != null && !nationalityCode.equals("")){
				if(!actualNationality.equalsIgnoreCase(nationalityCode)){
					//NATIONALITY MISMATCH
					personBasicInfoDTO.setReturnCode("15");
				}
			}
			
			if(dateOfBirth != null && !dateOfBirth.equals("")){
				
				if(!formatedDOB.equalsIgnoreCase(dateOfBirth)){
					if(personBasicInfoDTO.getReturnCode().equalsIgnoreCase("15"))
						personBasicInfoDTO.setReturnCode("17"); // NATIONALITY AND DOB MISMATCH
						else
							personBasicInfoDTO.setReturnCode("16"); // DOB MISMATCH
				}
			}
			
			
			personBasicInfoDTO.setCprNumber(idNumber);
			personBasicInfoDTO.setGender(personSummeryInfo.getGender().equalsIgnoreCase("M")?"1":"2");
			personBasicInfoDTO.setArabicFamilyName(personSummeryInfo.getArabicFamilyName());
			personBasicInfoDTO.setArabicMiddleName1(personSummeryInfo.getArabicMiddleName1());
			personBasicInfoDTO.setArabicMiddleName2(personSummeryInfo.getArabicMiddleName2());
			personBasicInfoDTO.setArabicMiddleName3(personSummeryInfo.getArabicMiddleName3());
			personBasicInfoDTO.setArabicMiddleName4(personSummeryInfo.getArabicMiddleName4());
			personBasicInfoDTO.setArabicFirstName(personSummeryInfo.getArabicFirstName());
			personBasicInfoDTO.setEnglishFamilyName(personSummeryInfo.getEnglishFamilyName());
			personBasicInfoDTO.setEnglishMiddleName1(personSummeryInfo.getEnglishMiddleName1());
			personBasicInfoDTO.setEnglishMiddleName2(personSummeryInfo.getEnglishMiddleName2());
			personBasicInfoDTO.setEnglishMiddleName3(personSummeryInfo.getEnglishMiddleName3());
			personBasicInfoDTO.setEnglishMiddleName4(personSummeryInfo.getEnglishMiddleName4());
			personBasicInfoDTO.setEnglishFirstName(personSummeryInfo.getEnglishFirstName());
			
			try{
				final GDNPRDocument document = getCrsService().getGDNPRServiceRef().getPersonLatestGDNPRDocument(cprNumber);
				personBasicInfoDTO.setPassportNumber(document.getDocumentNumber());
				
			}catch(Exception gdnprException){
					logger.debug("GDNPR Not Found");
			}
			
			
			List<Employment> employments = null;
		
			try {
				employments = getCrsService().getEmploymentServiceRef().getActiveEmployments(cprNumber);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			String isStudent = personSummeryInfo.getIsStudent();
			
			personBasicInfoDTO.setJobCode("00000");
			
			if(isStudent != null && isStudent.equalsIgnoreCase("T")){
				
				personBasicInfoDTO.setEmployerType("S");
				personBasicInfoDTO.setJobDescriptionEn("");
				personBasicInfoDTO.setJobDescriptionAr("");
				
			}else{// Employed
		
			if(employments !=null && !employments.isEmpty()){
				
				Integer employerNumber = employments.get(0).getEmployerNumber();

				if(employerNumber > 79999999 
						&& "U".equalsIgnoreCase(employments.get(0).getEmployerType().trim())){
					personBasicInfoDTO.setEmployerType("G");
					personBasicInfoDTO.setJobDescriptionEn("");
					personBasicInfoDTO.setJobDescriptionAr("");
				}else{
					personBasicInfoDTO.setEmployerType("P");
					personBasicInfoDTO.setJobDescriptionEn(employments.get(0).getOccupationEN());
					personBasicInfoDTO.setJobDescriptionAr(employments.get(0).getOccupationANM());
					personBasicInfoDTO.setEmployerNumber(employments.get(0).getEmployerNumber()+"");
//					personBasicInfoDTO.setEmployerNameEn(employments.get(0).getEmployerEN());
//					personBasicInfoDTO.setEmployerNameAr(employments.get(0).getEmployerAN());
					logger.debug(employments.get(0).getEmployerAN());
					logger.debug(employments.get(0).getEmployerEN());
				}
				
			}else{
			// UNEMPLOYED 
				personBasicInfoDTO.setEmployerType("");
				personBasicInfoDTO.setJobDescriptionEn("");
				personBasicInfoDTO.setJobDescriptionAr("");
			}
			
			}// end of Employed
			
			
			
			
			boolean isPersonActive = true; // dead or no residency
			
			if(personSummeryInfo.getIoStatusCode().equalsIgnoreCase("1") ||
					personSummeryInfo.getIoStatusCode().equalsIgnoreCase("3") ){
				isPersonActive = false;
			}
			
			
			personBasicInfoDTO.setIoStatus(isPersonActive?"0":"1");
			
			
			
			if(smartcards != null && !smartcards.isEmpty()){
				
				personBasicInfoDTO.setScIssueDate(sdf.format(smartcards.get(0).getPrintDate()));
				if(smartcards.get(0).getExpiryDate().after(new Date())){
					
					personBasicInfoDTO.setScExpiryDate("0");
				}else
					personBasicInfoDTO.setScExpiryDate("1");
					
				
			}else {
				personBasicInfoDTO.setScExpiryDate("1");
				
			}
			

			if (logger.isDebugEnabled())
			{
				logger.debug("getAllPersonBasicInfo(Integer, Integer, Date) - end");
			}
		}
		catch (final Exception exception)
		{
			
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getCSO018PersonBasicInfo(String, String, String, String) Error: " + exception.getMessage());
			}
			
			personBasicInfoDTO = new CSO018PersonBasicInfoDTO();
			 personBasicInfoDTO.setReturnCode("14");
			 return personBasicInfoDTO;
			 
			 
		}
		return personBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}


	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
