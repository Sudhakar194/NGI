package bh.gov.cio.integration.crs.nns.dto;

public class NotificationValidationInfoDTO {

	private String isRegistered;
	private String arabicName;
	private String englishName;
	private String primaryMobile;
	private String secondaryMobile;
	private String primaryEmail;
	private String primaryEmailStatus;
	private String secondaryEmail;
	private String secondaryEmailStatus;
	public NotificationValidationInfoDTO() {
		super();
	}
	public NotificationValidationInfoDTO(String isRegistered, String arabicName, String englishName,
			String primaryMobile, String secondaryMobile, String primaryEmail, String primaryEmailStatus,
			String secondaryEmail, String secondaryEmailStatus) {
		super();
		this.isRegistered = isRegistered;
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.primaryMobile = primaryMobile;
		this.secondaryMobile = secondaryMobile;
		this.primaryEmail = primaryEmail;
		this.primaryEmailStatus = primaryEmailStatus;
		this.secondaryEmail = secondaryEmail;
		this.secondaryEmailStatus = secondaryEmailStatus;
	}
	public String getIsRegistered() {
		return isRegistered;
	}
	public void setIsRegistered(String isRegistered) {
		this.isRegistered = isRegistered;
	}
	public String getArabicName() {
		return arabicName;
	}
	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}
	public String getEnglishName() {
		return englishName;
	}
	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}
	public String getPrimaryMobile() {
		return primaryMobile;
	}
	public void setPrimaryMobile(String primaryMobile) {
		this.primaryMobile = primaryMobile;
	}
	public String getSecondaryMobile() {
		return secondaryMobile;
	}
	public void setSecondaryMobile(String secondaryMobile) {
		this.secondaryMobile = secondaryMobile;
	}
	public String getPrimaryEmail() {
		return primaryEmail;
	}
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}
	public String getPrimaryEmailStatus() {
		return primaryEmailStatus;
	}
	public void setPrimaryEmailStatus(String primaryEmailStatus) {
		this.primaryEmailStatus = primaryEmailStatus;
	}
	public String getSecondaryEmail() {
		return secondaryEmail;
	}
	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}
	public String getSecondaryEmailStatus() {
		return secondaryEmailStatus;
	}
	public void setSecondaryEmailStatus(String secondaryEmailStatus) {
		this.secondaryEmailStatus = secondaryEmailStatus;
	}
}
