package bh.gov.cio.integration.crs.retrieve.mun.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.crs.retrieve.mun.service.dto.CRUnitAddressDTO;
import bh.gov.cio.integration.crs.retrieve.mun.service.dto.MUNServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "MUNBasicInfoService", targetNamespace = "http://service.MUN.retrieve.crs.integration.cio.gov.bh/")
public interface MUNBasicInfoServiceInterface extends CommonTypes
{
	@WebResult(name = "MUNBasicInformatoin")
	@WebMethod(operationName = "getPersonMUNBasicInfo")
	MUNServiceBasicInfoDTO getPersonMUNBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security,@WebParam(name = "CountryCode") @XmlElement(required = true)  String CountryCode ,@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber
			) throws ApplicationExceptionInfo;

	
	@WebResult(name = "CRUnitAddressInformation")
	@WebMethod(operationName = "getCRUnitAddressInfo")
	CRUnitAddressDTO getCRUnitAddressInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	header = true) SecurityTagObject security,@WebParam(name = "crUnitNumber") @XmlElement(required = true) Integer crUnitNumber
			) throws ApplicationExceptionInfo;
}
