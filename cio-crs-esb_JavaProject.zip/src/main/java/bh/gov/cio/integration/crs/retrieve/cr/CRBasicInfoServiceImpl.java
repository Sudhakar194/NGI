package bh.gov.cio.integration.crs.retrieve.cr;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.cr.CRDetails;
import bh.gov.cio.crs.model.unit.UnitActivity;
import bh.gov.cio.crs.service.UnitService;
import bh.gov.cio.crs.util.CRSUtils;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.gis.service.dto.CRBasicInfoWithAddressDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.CRBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRActivityInfoDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRAddressInfoDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CRBasicInfoService",
		targetNamespace = "http://service.cr.retrieve.crs.integration.cio.gov.bh/")//, serviceName = "CRBasicInfoService"
public class CRBasicInfoServiceImpl implements CRBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(CRBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@Override
	@Secured(
	{ "ROLE_getCRBasicInfo" })
	@WebMethod(operationName = "getCRBasicInfo")
	public CRServiceBasicInfoDTO getCRBasicInfo(SecurityTagObject security, Integer crNumber) throws ApplicationExceptionInfo
	{

		CRServiceBasicInfoDTO result = null;

		UnitService unitService = getCrsService().getUnitServiceRef();

		try
		{
			CRDetails crDetails = unitService.getCrBasicInfo(crNumber);
			if("F".equals(crDetails.getIsActive())){
				throw new ApplicationExceptionInfo("CR is canceled", new ApplicationException("CR is canceled"));
			}

			ArrayList<CRActivityInfoDTO> crActivityList = null;
			String operationEndDate = "";

			SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");

			if (crDetails.getLicenseExpiryDate() != null)
			{

				operationEndDate = df.format(CRSUtils.getDateFromTimestamp(crDetails.getLicenseExpiryDate()));
				if (logger.isDebugEnabled())
				{
					logger.debug("operationEndDate() -  operationEndDate = " + operationEndDate);
				}

			}
			List<UnitActivity> crActivities = unitService.getCrActivities(crNumber);

			int i = 0;

			if (logger.isDebugEnabled())
			{
				logger.debug("getCrActivities() -  activities owner size list = " + crActivities.size());
			}

			if (crActivities != null && crActivities.size() > 0)
			{
				crActivityList = new ArrayList<CRActivityInfoDTO>();
				for (final UnitActivity crActivity : crActivities)
				{
					crActivityList.add(
							i,
							new CRActivityInfoDTO(crActivity.getMainActivityCode(), crActivity.getMainActivityArNm(), crActivity
									.getMainActivityEnNm()));

					i++;
				}
			}

			if (crActivityList == null)
			{
				CRActivityInfoDTO crActivityInfoDTO = new CRActivityInfoDTO("", "", "");
				crActivityList = new ArrayList<CRActivityInfoDTO>();
				crActivityList.add(crActivityInfoDTO);
			}
			String roadNumber = (crDetails.getRoad() != null) ? crDetails.getRoad() + "" : null;
			String blockNumber = (crDetails.getBlock() != null) ? crDetails.getBlock() + "" : null;
			String poBox = (crDetails.getPoBox() != null) ? crDetails.getPoBox() + "" : null;
			String flatNumber = (crDetails.getFlat() != null) ? crDetails.getFlat() + "" : null;
			String buildingNumber = (crDetails.getBuilding() != null) ? crDetails.getBuilding() + "" : null;

			result = new CRServiceBasicInfoDTO(crDetails.getCrNumber(), crDetails.getCrArabicName(), crDetails.getCrEnglishName(), crDetails.getCompanyStatusCode(), crDetails
					.getMobile(), operationEndDate, crDetails.getEmail(), crDetails.getFax(), crDetails.getPhoneContact(), poBox, flatNumber, buildingNumber, crDetails
					.getAlpha(), roadNumber, blockNumber, crActivityList);

		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error(" Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Fetching CR Details", new ApplicationException(exception.getMessage()));
		}

		return result;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

	@Override
	@Secured(
	{ "ROLE_getCRAddressInfo" })
	@WebMethod(operationName = "getCRAddressInfo")
	public CRAddressInfoDTO getCRAddressInfo(SecurityTagObject security, Integer crNumber) throws ApplicationExceptionInfo
	{
		UnitService unitService = getCrsService().getUnitServiceRef();
		CRDetails crDetails;
		String roadNumber, blockNumber, alpha, flatNumber, buildingNumber;
		try
		{
			crDetails = unitService.getCrBasicInfo(crNumber);
			if("F".equals(crDetails.getIsActive())){
				//logger.debug("cr is canceled: " + crDetails.getIsActive());
				throw new ApplicationExceptionInfo("CR is canceled", new ApplicationException("CR is canceled"));
			}
			roadNumber = (crDetails.getRoad() != null) ? crDetails.getRoad() + "" : null;
			blockNumber = (crDetails.getBlock() != null) ? crDetails.getBlock() + "" : null;
			alpha = (crDetails.getAlpha() != null) ? crDetails.getAlpha() + "" : null;
			flatNumber = (crDetails.getFlat() != null) ? crDetails.getFlat() + "" : null;
			buildingNumber = (crDetails.getBuilding() != null) ? crDetails.getBuilding() + "" : null;
		}
		catch (bh.gov.cio.crs.util.exception.ApplicationException exception)
		{
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Problem Getting Results", new ApplicationException(exception.getMessage()));
		}
		catch (BusinessException exception)
		{
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Problem Getting Results", new ApplicationException(exception.getMessage()));
		}
		return new CRAddressInfoDTO(flatNumber, buildingNumber, alpha, roadNumber, blockNumber);
	}

}
