package bh.gov.cio.integration.crs.najim.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "WatclistDetails", propOrder = { "cprNumber", "statusCode", "statusMessage" })
public class WatchlistDTO {

	public WatchlistDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	private Integer cprNumber;

	private String statusCode;
	private String statusMessage;

	@XmlElement(name = "cprNumber")
	public Integer getCprNumber() {
		return cprNumber;
	}

	public void setCprNumber(Integer cprNumber) {
		this.cprNumber = cprNumber;
	}

	@XmlElement(name = "StatusCode")
	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	@XmlElement(name = "StatusMessage")
	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
}
