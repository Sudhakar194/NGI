package bh.gov.cio.integration.crs.retrieve.person.biometric;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.AuditDetails;
import bh.gov.cio.crs.util.CRSUtils;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.PersonBasicInfoServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.biometric.service.PersonBiometricPhotoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.biometric.service.dto.PersonBiometricPhotoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonBiometricPhotoService", targetNamespace = "http://service.biometric.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonBiometricPhotoService"
public class PersonBiometricPhotoServiceImpl implements PersonBiometricPhotoServiceInterface
{

	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

//	@Override
//	@Secured(
//	{ "ROLE_getPersonPhoto" })
//	@WebMethod(operationName = "getPersonPhoto")
//	public PersonBiometricPhotoDTO getPersonPhoto(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
//			throws ApplicationExceptionInfo
//	{
//
//		if (logger.isDebugEnabled())
//		{
//			logger.debug("getPersonPhoto(Integer, Integer, Date) - start");
//			logger.debug("getPersonPhoto(cprNumber = " + cprNumber + ", blockNumber = " + blockNumber + ", cardExpiryDate = " + cardExpiryDate + ")");
//		}
//
//		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
//		{
//			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
//		}
//		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
//		{
//			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
//		}
//		if (validationUtil.isMilitaryCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
//		}
//		if (validationUtil.isDeletedCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//		}
//		PersonBiometricPhotoDTO photoDTO = null;
//		try
//		{
//
//			photoDTO = new PersonBiometricPhotoDTO(cprNumber, getCrsService().getBiometricServiceRef().getPersonPhoto(cprNumber), "date");
//
//			if (logger.isDebugEnabled())
//			{
//				logger.debug("getPersonPhoto(Integer, Integer, Date) - end");
//			}
//		}
//		catch (final Exception exception)
//		{
//			if (logger.isDebugEnabled())
//			{
//				logger.error("getPersonPhoto(Integer, Integer, Date) Error: " + exception.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Person Photo Not found", new ApplicationException(exception.getMessage()));
//		}
//
//		return photoDTO;
//	}

	@Override
	@Secured(
	{ "ROLE_getPersonPhotoByCPR" })
	@WebMethod(operationName = "getPersonPhotoByCPR")
	public PersonBiometricPhotoDTO getPersonPhotoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{

		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonPhotoByCPR(Integer) - start");
			logger.debug("getPersonPhotoByCPR(cprNumber = " + cprNumber + ")");
		}
		if (validationUtil.isMilitaryCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		PersonBiometricPhotoDTO photoDTO = null;
		try
		{

			AuditDetails photoDetails = getCrsService().getBiometricServiceRef().getPersonBiometricAuditDetails(cprNumber);
			photoDTO = new PersonBiometricPhotoDTO(cprNumber, getCrsService().getBiometricServiceRef().getPersonPhoto(cprNumber),
					CRSUtils.getDateStringFromTimeStamp(photoDetails.getPhotoDate()));

			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonPhoto(Integer) - end");
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonPhoto(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Photo Not found", new ApplicationException(exception.getMessage()));
		}

		return photoDTO;
	}

//	@Override
//	@Secured(
//	{ "ROLE_getPersonSpecialPhotoByCPR" })
//	@WebMethod(operationName = "getPersonSpecialPhotoByCPR")
//	public PersonBiometricPhotoDTO getPersonSpecialPhotoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
//	{
//
//		if (logger.isDebugEnabled())
//		{
//			logger.debug("getPersonPhotoByCPR(Integer, Integer, Date) - start");
//			logger.debug("getPersonPhotoByCPR(cprNumber = " + cprNumber + ")");
//		}
//		if (validationUtil.isDeletedCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//		}
//		PersonBiometricPhotoDTO photoDTO = null;
//		try
//		{
//
//			AuditDetails photoDetails = getCrsService().getBiometricServiceRef().getPersonBiometricAuditDetails(cprNumber);
//			photoDTO = new PersonBiometricPhotoDTO(cprNumber, getCrsService().getBiometricServiceRef().getPersonPhoto(cprNumber),
//					CRSUtils.getDateStringFromTimeStamp(photoDetails.getPhotoDate()));
//
//			if (logger.isDebugEnabled())
//			{
//				logger.debug("getPersonPhoto(Integer, Integer, Date) - end");
//			}
//		}
//		catch (final Exception exception)
//		{
//			if (logger.isDebugEnabled())
//			{
//				logger.error("getPersonPhoto(Integer, Integer, Date) Error: " + exception.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Person Photo Not found", new ApplicationException(exception.getMessage()));
//		}
//
//		return photoDTO;
//	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
