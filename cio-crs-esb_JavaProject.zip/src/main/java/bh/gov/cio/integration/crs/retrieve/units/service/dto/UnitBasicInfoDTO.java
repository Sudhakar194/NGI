package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "UnitDetails", propOrder =
{ "unitNumber", "unitArabicName", "unitEnglishName", "unitActivity" })
public class UnitBasicInfoDTO
{
	private Integer unitNumber;
	private String unitArabicName;
	private String unitEnglishName;
	private List<UnitActivityDTO> unitActivity;
	private final String unitIsActiveStatus = "T";

	public UnitBasicInfoDTO()
	{
		super();

	}

	public UnitBasicInfoDTO(Integer unitNumber, String unitArabicName, String unitEnglishName, List<UnitActivityDTO> unitActivity)
	{
		super();
		this.unitNumber = unitNumber;
		this.unitArabicName = unitArabicName;
		this.unitEnglishName = unitEnglishName;
		this.unitActivity = unitActivity;
	}

	public List<UnitActivityDTO> getUnitActivity()
	{
		return unitActivity;
	}

	public String getUnitArabicName()
	{
		return unitArabicName;
	}

	public String getUnitEnglishName()
	{
		return unitEnglishName;
	}

	public String getUnitIsActiveStatus()
	{
		return unitIsActiveStatus;
	}

	public Integer getUnitNumber()
	{
		return unitNumber;
	}

	public void setUnitActivity(List<UnitActivityDTO> unitActivity)
	{
		this.unitActivity = unitActivity;
	}

	public void setUnitArabicName(String unitArabicName)
	{
		this.unitArabicName = unitArabicName;
	}

	public void setUnitEnglishName(String unitEnglishName)
	{
		this.unitEnglishName = unitEnglishName;
	}

	public void setUnitNumber(Integer unitNumber)
	{
		this.unitNumber = unitNumber;
	}

}
