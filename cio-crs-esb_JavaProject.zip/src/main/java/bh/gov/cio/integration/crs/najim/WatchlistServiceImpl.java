package bh.gov.cio.integration.crs.najim;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.service.PersonWatchListService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.najim.service.WatchlistServiceInterface;
import bh.gov.cio.integration.crs.najim.service.dto.WatchlistDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "WatchlistService", targetNamespace = "http://service.najim.crs.integration.cio.gov.bh/")
public class WatchlistServiceImpl implements WatchlistServiceInterface {

	private static final Logger	logger	= LoggerFactory.getLogger(WatchlistServiceImpl.class);
	public WatchlistServiceImpl() {
		super();
	}

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_AddWatchlist" })
	@WebMethod(operationName = "AddToWatchlist")
	public WatchlistDTO AddToWatchlist(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo {
		WatchlistDTO watchlistDTO = new WatchlistDTO();

		PersonWatchListService pws = null;

		logger.debug("AddToWatchlist -- cprNumber=" + cprNumber);

		try {
			pws = getCrsService().getWatchlistServiceRef();
			Integer ret = pws.addMOIWatchlist(cprNumber, "najimWL");
			if (ret != null && ret <= 0) {
				watchlistDTO.setCprNumber(cprNumber);
				watchlistDTO.setStatusCode("001");
				watchlistDTO.setStatusMessage("ERROR Enroll CPR in watchlist");
			} else {
				watchlistDTO.setCprNumber(cprNumber);
				watchlistDTO.setStatusCode("000");
				watchlistDTO.setStatusMessage("SUCCESS");
			}

		} catch (Exception e) {
			e.printStackTrace();
			watchlistDTO.setCprNumber(cprNumber);
			watchlistDTO.setStatusCode("001");
			watchlistDTO.setStatusMessage("ERROR Enroll CPR in watchlist");
		}
		return watchlistDTO;
	}

	@Override
	@Secured({ "ROLE_RemoveWatchlist" })
	@WebMethod(operationName = "RemoveFromWatchlist")
	public WatchlistDTO RemoveFromWatchlist(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		// TODO Auto-generated method stub

		WatchlistDTO watchlistDTO = new WatchlistDTO();

		PersonWatchListService pws = null;

		logger.debug("RemoveFromWatchlist -- cprNumber=" + cprNumber);

		try {
			pws = getCrsService().getWatchlistServiceRef();
			boolean ret = pws.deleteMOIWatchlist(cprNumber);
			if (ret) {
				watchlistDTO.setCprNumber(cprNumber);
				watchlistDTO.setStatusCode("000");
				watchlistDTO.setStatusMessage("SUCCESS");
			} else {
				watchlistDTO.setCprNumber(cprNumber);
				watchlistDTO.setStatusCode("001");
				watchlistDTO.setStatusMessage("ERROR Removing CPR from watchlist");
			}

		} catch (Exception e) {
			e.printStackTrace();
			watchlistDTO.setCprNumber(cprNumber);
			watchlistDTO.setStatusCode("001");
			watchlistDTO.setStatusMessage("ERROR Removing CPR from watchlist");
		}
		return watchlistDTO;
	}

}
