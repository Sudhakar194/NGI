package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "OrphanChildrensDetails", propOrder =
{ "arabicFullName", "englishFullName", "nationality", "dateOfBirth", "gender", "noOfOwnedProperties","LFPCode"})

public class OrphanChildrensDetailsDTO
{
	private java.lang.String	arabicFullName;
	private java.lang.String	englishFullName;
	private java.lang.String	nationality;
	private java.lang.String	dateOfBirth;
	private java.lang.String	gender;
	private java.lang.String	LFPCode;
	private java.lang.Integer	noOfOwnedProperties;
	public OrphanChildrensDetailsDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public OrphanChildrensDetailsDTO(String arabicFullName, String englishFullName, String nationality, String dateOfBirth, String gender, Integer noOfOwnedProperties,String LFPCode)
	{
		super();
		this.arabicFullName = arabicFullName!= null ? arabicFullName : "";
		this.englishFullName = englishFullName!= null ? englishFullName :"" ;
		this.nationality = nationality!= null ? nationality : "";
		this.dateOfBirth = dateOfBirth!= null ? dateOfBirth : "";
		this.gender = gender!= null ? gender : "";
		this.noOfOwnedProperties = noOfOwnedProperties!= null ? noOfOwnedProperties : 0;
		this.LFPCode=LFPCode != null ? LFPCode : "";
	}
	@XmlElement(name = "ArabicFullName")
	public java.lang.String getArabicFullName()
	{
		return arabicFullName;
	}
	@XmlElement(name = "EnglishFullName")
	public java.lang.String getEnglishFullName()
	{
		return englishFullName;
	}
	@XmlElement(name = "Nationality")
	public java.lang.String getNationality()
	{
		return nationality;
	}
	@XmlElement(name = "DateOfBirth")
	public java.lang.String getDateOfBirth()
	{
		return dateOfBirth;
	}
	@XmlElement(name = "Gender")
	public java.lang.String getGender()
	{
		return gender;
	}
	@XmlElement(name = "NoOfOwnedProperties")
	public java.lang.Integer getNoOfOwnedProperties()
	{
		return noOfOwnedProperties;
	}
	@XmlElement(name = "LFPCode")
	public java.lang.String getLFPCode()
	{
		return LFPCode;
	}
	public void setArabicFullName(java.lang.String arabicFullName)
	{
		this.arabicFullName = arabicFullName;
	}
	public void setEnglishFullName(java.lang.String englishFullName)
	{
		this.englishFullName = englishFullName;
	}
	public void setNationality(java.lang.String nationality)
	{
		this.nationality = nationality;
	}
	public void setDateOfBirth(java.lang.String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}
	public void setGender(java.lang.String gender)
	{
		this.gender = gender;
	}
	public void setNoOfOwnedProperties(java.lang.Integer noOfOwnedProperties)
	{
		this.noOfOwnedProperties = noOfOwnedProperties;
	}
	public void setLFPCode(java.lang.String lFPCode)
	{
		LFPCode = lFPCode;
	}
}
