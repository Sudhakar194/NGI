package bh.gov.cio.integration.common.dao;

import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository(value = "LogDao")
public class LogDao
{
	/**
	 * Logger for this class
	 */
	private static final Logger					logger				= LoggerFactory.getLogger(LogDao.class);

	@Autowired
	private final NamedParameterJdbcTemplate	ESBNamedTemplate	= null;

	@Transactional(propagation = Propagation.SUPPORTS)
	public int CreateLogRecord(String IN_OR_OUT, String MESSAGE_PAYLOAD, String REMARKS, String IS_ERROR_MESSAGE, String USERNAME, String APP_NAME,
			String WEBSERVICE_URL, String CLIENT_IP, String MESSAGE_ID, Integer CPR_NUMBER) throws Exception, UnknownHostException,
			CannotGetJdbcConnectionException
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("CreateLogRecord(String, String, String, String, String, Integer) - start");
		}
		if (REMARKS != null && REMARKS.length() > 5000)
			REMARKS = REMARKS.substring(0, 4999);

		Map<String, Object> parameters = new HashMap<String, Object>(6);
		parameters.put("IN_OR_OUT", IN_OR_OUT);
//		String cprstr = "0";
//		if(MESSAGE_PAYLOAD.contains("CPR_NUMBER")){
//			cprstr = MESSAGE_PAYLOAD.substring(MESSAGE_PAYLOAD.indexOf("CPR_NUMBER"), MESSAGE_PAYLOAD.indexOf("CPR_NUMBER") + 9);
//		}
//		if(MESSAGE_PAYLOAD.contains("CPR")){
//			cprstr = MESSAGE_PAYLOAD.substring(MESSAGE_PAYLOAD.indexOf("CPR"), MESSAGE_PAYLOAD.indexOf("CPR") + 9) ;
//		}
//		if(MESSAGE_PAYLOAD.contains("cprNumber")){
//			cprstr = MESSAGE_PAYLOAD.substring(MESSAGE_PAYLOAD.indexOf("cprNumber"), MESSAGE_PAYLOAD.indexOf("cprNumber") + 9) ;
//		}
//		if(MESSAGE_PAYLOAD.contains("idNumber")){
//			cprstr = MESSAGE_PAYLOAD.substring(MESSAGE_PAYLOAD.indexOf("idNumber"), MESSAGE_PAYLOAD.indexOf("idNumber") + 9) ;
//		}
//		if(MESSAGE_PAYLOAD.contains("CPRNumber")){
//			cprstr = MESSAGE_PAYLOAD.substring(MESSAGE_PAYLOAD.indexOf("CPRNumber"), MESSAGE_PAYLOAD.indexOf("CPRNumber") + 9) ;
//		}
//		if (MESSAGE_PAYLOAD != null && MESSAGE_PAYLOAD.length() > 5000)
//			MESSAGE_PAYLOAD = MESSAGE_PAYLOAD.substring(0, 4999);
		parameters.put("MESSAGE_PAYLOAD", "");//cprstr);
		CPR_NUMBER = 0;//Integer.parseInt(cprstr);
		parameters.put("CPR_NUMBER", CPR_NUMBER);
		parameters.put("REMARKS", "");
		parameters.put("IS_ERROR_MESSAGE", IS_ERROR_MESSAGE);
		parameters.put("USERNAME", USERNAME);
		parameters.put("APP_NAME", APP_NAME);
		parameters.put("WEBSERVICE_URL", WEBSERVICE_URL);
		parameters.put("CLIENT_IP", CLIENT_IP);
		parameters.put("MESSAGE_ID", MESSAGE_ID);

		ESBNamedTemplate
				.update("INSERT INTO ESBDB.SOAPLOG( IN_OR_OUT, MESSAGE_PAYLOAD, "
						+ "CREATION_DATE, REMARKS, IS_ERROR_MESSAGE, USERNAME, APP_NAME ,WEBSERVICE_URL ,CLIENT_IP,MESSAGE_ID,CPR_NUMBER) \r\n"
						+ "    VALUES( :IN_OR_OUT, :MESSAGE_PAYLOAD, CURRENT_TIMESTAMP, :REMARKS, :IS_ERROR_MESSAGE, :USERNAME, :APP_NAME , :WEBSERVICE_URL ,:CLIENT_IP , :MESSAGE_ID,:CPR_NUMBER)",
						parameters);

		if (logger.isDebugEnabled())
		{
			logger.debug("CreateLogRecord(String, String, String, String, String, Integer) - end");
		}
		return 0;
	}

}
