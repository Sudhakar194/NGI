package bh.gov.cio.integration.security;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.cxf.binding.soap.interceptor.SoapHeaderInterceptor;
import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.transport.Conduit;
import org.apache.cxf.ws.addressing.EndpointReferenceType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

/**
 * CXF Interceptor that provides HTTP Basic Authentication validation.
 * 
 * Based on the concepts outline here: http://chrisdail.com/2008/03/31/apache-cxf-with-http-basic-authentication
 * 
 * @author CDail
 */
public class BasicAuthAuthorizationInterceptor extends SoapHeaderInterceptor
{

	protected Logger			logger	= LoggerFactory.getLogger(getClass());

	/** Map of allowed users to this system with their corresponding passwords. */
	private Map<String, String>	users;

	private void close(Message outMessage) throws IOException
	{
		final OutputStream os = outMessage.getContent(OutputStream.class);
		os.flush();
		os.close();
	}

	private Conduit getConduit(Message inMessage) throws IOException
	{
		final Exchange exchange = inMessage.getExchange();
		final EndpointReferenceType target = exchange
				.get(EndpointReferenceType.class);
		final Conduit conduit = exchange.getDestination().getBackChannel(
				inMessage, null, target);
		exchange.setConduit(conduit);
		return conduit;
	}

	private Message getOutMessage(Message inMessage)
	{
		final Exchange exchange = inMessage.getExchange();
		Message outMessage = exchange.getOutMessage();
		if (outMessage == null)
		{
			final Endpoint endpoint = exchange.get(Endpoint.class);
			outMessage = endpoint.getBinding().createMessage();
			exchange.setOutMessage(outMessage);
		}
		outMessage.putAll(inMessage);
		return outMessage;
	}

	@Override
	public void handleMessage(Message message) throws Fault
	{
		if (logger.isDebugEnabled())
			logger.debug("handleMessage(Message) - start");

		// This is set by CXF
		final AuthorizationPolicy policy = message
				.get(AuthorizationPolicy.class);

		// If the policy is not set, the user did not specify credentials
		// A 401 is sent to the client to indicate that authentication is required
		if (policy == null)
		{
			if (logger.isDebugEnabled())
				logger.debug("User attempted to log in with no credentials");
			sendErrorResponse(message, HttpURLConnection.HTTP_UNAUTHORIZED);

			if (logger.isDebugEnabled())
				logger.debug("handleMessage(Message) - end");
			return;
		}

		if (logger.isDebugEnabled())
			logger.debug("Logging in use: " + policy.getUserName());

		// Verify the password
		final String realPassword = users.get(policy.getUserName());
		if (realPassword == null || !realPassword.equals(policy.getPassword()))
		{
			logger.warn("Invalid username or password for user: "
					+ policy.getUserName());
			sendErrorResponse(message, HttpURLConnection.HTTP_FORBIDDEN);
		}

		if (logger.isDebugEnabled())
			logger.debug("handleMessage(Message) - end");
	}

	private void sendErrorResponse(Message message, int responseCode)
	{
		final Message outMessage = getOutMessage(message);
		outMessage.put(Message.RESPONSE_CODE, responseCode);

		// Set the response headers
		final Map<String, List<String>> responseHeaders = (Map<String, List<String>>) message
				.get(Message.PROTOCOL_HEADERS);

		if (logger.isDebugEnabled())
			logger.debug("sendErrorResponse(int responseCode = " + responseCode
					+ ") -  : Map responseHeaders = " + responseHeaders);

		if (responseHeaders != null)
		{
			responseHeaders.put("WWW-Authenticate", Arrays.asList(new String[]
			{ "Basic realm=realm" }));
			responseHeaders.put("Content-length", Arrays.asList(new String[]
			{ "0" }));
		}
		message.getInterceptorChain().abort();
		try
		{
			getConduit(message).prepare(outMessage);
			close(outMessage);
		}
		catch (final IOException e)
		{
			logger.warn(e.getMessage(), e);
		}
	}

	@Required
	public void setUsers(Map<String, String> users)
	{
		this.users = users;
	}
}
