package bh.gov.cio.integration.crs.retrieve.nhi.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.nhi.service.dto.NHIBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NHIBasicInfoService", targetNamespace = "http://service.nhi.retrieve.crs.integration.cio.gov.bh/")
public interface NHIBasicInfoServiceInterface {

	@WebResult(name = "NHIBasicInfo")
	@WebMethod(operationName = "getNHIBasicInfo")
	NHIBasicInfoDTO getNHIBasicInfo(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String nationalityCode)
			throws ApplicationExceptionInfo;
}