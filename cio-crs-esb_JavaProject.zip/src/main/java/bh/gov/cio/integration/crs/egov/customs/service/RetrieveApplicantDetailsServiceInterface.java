package bh.gov.cio.integration.crs.egov.customs.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.customs.service.dto.ApplicantDetailsDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "RetrieveCustomsApplicantDetailsService", targetNamespace = "http://service.customs.egov.crs.integration.cio.gov.bh/")
public interface RetrieveApplicantDetailsServiceInterface {
	@WebResult(name = "ApplicantDetails")
	@WebMethod(operationName = "RetrieveCustomsApplicantDetails")
	ApplicantDetailsDTO RetrieveApplicantDetails(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "age") @XmlElement(required = true) Integer age) throws ApplicationExceptionInfo;
}
