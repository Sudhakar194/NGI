package bh.gov.cio.integration.crs.retrieve.address;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.LookupItem;
import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.nas.Building;
import bh.gov.cio.crs.model.nas.BuildingSearchItems;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.LookupService.Lookup;
import bh.gov.cio.crs.util.exception.AddressLoadException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.retrieve.address.service.CheckValidAddressServiceInterface;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.CheckActiveBuildingDTO;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.CheckActiveBuildingReturnDTO;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.CheckValidateAddressDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CheckValidAddressService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
public class CheckValidAddressServiceImpl implements CheckValidAddressServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(CheckValidAddressServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Override
	@Secured({ "ROLE_checkValidAddress" })
	@WebMethod(operationName = "checkValidAddress")
	public CheckValidateAddressDTO checkValidAddress(SecurityTagObject security, Integer flatNumber,
			Integer buildingNumber, String buildingAlpha, Integer roadNumber, Integer blockNumber)
			throws ApplicationExceptionInfo {

		CheckValidateAddressDTO checkValidateAddressDTO = new CheckValidateAddressDTO("001", "No Data Found", "");

		try {

			if (flatNumber == null || flatNumber.intValue() < 0)
				throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
			if (roadNumber == null || roadNumber.intValue() < 0)
				throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
			if (buildingNumber == null || buildingNumber.intValue() < 0)
				throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
			if (blockNumber == null || blockNumber.intValue() < 0)
				throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));

			Address address = getCrsService().getAddressServiceRef().validateAddressComponents(flatNumber,
					buildingNumber, buildingAlpha, roadNumber, blockNumber);
			if (address != null) {
				BuildingSearchItems bsi = new BuildingSearchItems(buildingNumber, roadNumber, blockNumber,
						buildingAlpha);
				Address addressDetails = getCrsService().getAddressServiceRef()
						.getAddressFieldsFromSn(address.getAddressSn());

				if (logger.isDebugEnabled()) {
					logger.error("flat " + addressDetails.getFlatNumber());
					logger.error("Address " + addressDetails);
					logger.error("Building " + addressDetails.getBuildingNumber());
					logger.error("BuildingAlpha " + addressDetails.getNameAlphaEnglish());
					logger.error("Road " + addressDetails.getRoadNumber());
					logger.error("Block " + addressDetails.getBlockNumber());
				}

				List<Building> bldgs = getCrsService().getAddressServiceRef().getBuildingDetails(bsi);
				for (Iterator<Building> iterator = bldgs.iterator(); iterator.hasNext();) {
					Building building = (Building) iterator.next();
					if (logger.isDebugEnabled()) {
						logger.error("Governorate " + building.getGovernorateCode());

						LookupItem li = new LookupItem(null, null, building.getGovernorate(), null, null, null);
						// getCrsService().getLookupServiceRef().getMatchLookupRecord(Lookup.CRS_GOVERNORATE,
						// li);

						List<LookupItem> governorates = getCrsService().getLookupServiceRef()
								.getMatchLookupRecord(Lookup.CRS_GOVERNORATE, li);
						String governorate = governorates.get(0).getEnglishDescription();
						checkValidateAddressDTO = new CheckValidateAddressDTO("000", "Success", governorate);
						logger.error("Governorate " + governorate);
					}
				}
			}
			// else {
			// throw new ApplicationExceptionInfo("Address Not found", new
			// ApplicationException("Address Not found"));
			//
			// }
		}

		catch (AddressLoadException e) {

			e.printStackTrace();
		} catch (bh.gov.cio.crs.util.exception.ApplicationException e) {
			e.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getAddressesInfoByBlockAndRoad(Integer, Integer) Error: " + e.getMessage());
			}
			// throw new ApplicationExceptionInfo("Address Not found", new
			// ApplicationException("Address Not found"));
		} catch (Exception e) {
			e.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getAddressesInfoByBlockAndRoad(Integer, Integer) Error: " + e.getMessage());
			}
			// throw new ApplicationExceptionInfo("Address Not found", new
			// ApplicationException("Address Not found"));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("getAddressesInfoByBlockAndRoad(Integer, Integer) - start");
		}

		return checkValidateAddressDTO;
	}

	@Override
	@Secured({ "ROLE_checkActiveBuildingList" })
	@WebMethod(operationName = "checkActiveBuildingList")
	public ArrayList<CheckActiveBuildingReturnDTO> checkActiveBuildingList(SecurityTagObject security,
			List<CheckActiveBuildingDTO> bldgList) throws ApplicationExceptionInfo {
		ArrayList<CheckActiveBuildingReturnDTO> checkActiveBuildingDTO = new ArrayList<CheckActiveBuildingReturnDTO>();
		try {
			AddressService as = getCrsService().getAddressServiceRef();
			List<Building> crsBldgList = new ArrayList<Building>();
			for (CheckActiveBuildingDTO checkBuildingDTO : bldgList) {
				Building bld = new Building();
				bld.setBuildingNumber(Integer.parseInt(checkBuildingDTO.getBuildingNumber()));
				bld.setBuildingAlpha(checkBuildingDTO.getBuildingAlphaEnglish());
				bld.setBlockNumber(Integer.parseInt(checkBuildingDTO.getBlockNumber()));
				bld.setRoadNumber(Integer.parseInt(checkBuildingDTO.getRoadNumber()));
				crsBldgList.add(bld);
			}
		
			List<Building> bldgs = as.getIsBuildingActive(crsBldgList);

			for (Iterator<Building> iterator = bldgs.iterator(); iterator.hasNext();) {
				Building building = (Building) iterator.next();
				checkActiveBuildingDTO.add(
						new CheckActiveBuildingReturnDTO(building.getBuildingNumber() + "", building.getBuildingAlpha(),
								building.getRoadNumber() + "", building.getBlockNumber() + "", building.getIsActive()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return checkActiveBuildingDTO;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

}
