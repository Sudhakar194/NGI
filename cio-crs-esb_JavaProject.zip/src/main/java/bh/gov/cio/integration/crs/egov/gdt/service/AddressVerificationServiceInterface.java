package bh.gov.cio.integration.crs.egov.gdt.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.gdt.service.dto.AddressVerificationDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "AddressVerificationService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public interface AddressVerificationServiceInterface {
	
		@WebResult(name = "AddressVerification")
		@WebMethod(operationName = "validateAddress")
		AddressVerificationDTO validateAddress(
				@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
				@WebParam(name = "flatNumber") @XmlElement(required = true) Integer flatNumber,
				@WebParam(name = "buildingNumber") @XmlElement(required = true) Integer buildingNumber,
				@WebParam(name = "buildingAlpha") @XmlElement(required = true) String buildingAlpha,
				@WebParam(name = "roadNumber") @XmlElement(required = true) Integer roadNumber,
				@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber) throws ApplicationExceptionInfo;

	
	
}
