package bh.gov.cio.integration.crs.retrieve.disability.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.disability.service.dto.DisabilityServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonDisabilityBasicInfoService", targetNamespace = "http://service.disability.retrieve.crs.integration.cio.gov.bh/")
public interface PersonDisabilityBasicInfoServiceInterface
{

	@WebResult(name = "DisabilityBasicInformatoin")
	@WebMethod(operationName = "getAllPersonDisabilityBasicInfo")
	DisabilityServiceBasicInfoDTO[] getAllPersonDisabilityBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber, @WebParam(
			name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

//	@WebResult(name = "DisabilityBasicInformatoin")
//	@WebMethod(operationName = "getPersonDisabilityBasicInfo")
//	DisabilityServiceBasicInfoDTO[] getPersonDisabilityBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
//			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber, @WebParam(
//			name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

}
