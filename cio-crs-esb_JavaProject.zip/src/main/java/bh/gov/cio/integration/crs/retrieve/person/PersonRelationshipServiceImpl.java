package bh.gov.cio.integration.crs.retrieve.person;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Family;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ErrorMessages;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonRelationshipServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonRelationshipService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonRelationshipService"
public class PersonRelationshipServiceImpl implements PersonRelationshipServiceInterface, ErrorMessages {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonRelationshipServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

//	@Override
//	@Secured({ "ROLE_getPersonRelationship" })
//	@WebMethod(operationName = "getPersonRelationship")
//	public String getPersonRelationship(SecurityTagObject security, Integer cprNumber, Integer relatedCprNumber)
//			throws ApplicationExceptionInfo {
//		// TODO Auto-generated method stub
//
//		if (logger.isDebugEnabled()) {
//			logger.debug("getPersonRelationship(Integer, Integer) - start");
//			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ")");
//		}
//
//		if (validationUtil.isMilitaryCpr(cprNumber))
//			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
//		if (validationUtil.isDeletedCpr(cprNumber))
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//
//		if (validationUtil.isMilitaryCpr(relatedCprNumber))
//			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
//		if (validationUtil.isDeletedCpr(relatedCprNumber))
//			throw new ApplicationExceptionInfo("Related CPR Number Deleted",
//					new ApplicationException("Related CPR Number Deleted"));
//
//		try {
//
//			Family family = crsService.getFamilyServiceRef().getFamilyDetails(cprNumber);
//
//			if (family != null) {
//
//				if (family.getSpouseCprNumber() != null) {
//
//					if (family.getSpouseCprNumber().equals(relatedCprNumber))
//						return "SPOUSE";
//
//				}
//
//				if (family.getFatherCprNumber() != null) {
//
//					if (family.getFatherCprNumber().equals(relatedCprNumber))
//						return "FATHER";
//
//					Family FatherMotherFather = crsService.getFamilyServiceRef()
//							.getFamilyDetails(family.getFatherCprNumber());
//
//					if (FatherMotherFather != null && FatherMotherFather.getFatherCprNumber() != null
//							&& FatherMotherFather.getFatherCprNumber().equals(relatedCprNumber))
//						return "GRANDFATHER";
//
//					if (FatherMotherFather != null && FatherMotherFather.getMotherCprNumber() != null
//							&& FatherMotherFather.getMotherCprNumber().equals(relatedCprNumber))
//						return "GRANDMOTHER";
//
//					List<PersonSummary> fatherSibilings = crsService.getFamilyServiceRef()
//							.getPersonSiblings(family.getFatherCprNumber());
//
//					if (fatherSibilings.isEmpty())
//						logger.debug("Father has no sibilings");
//
//					for (PersonSummary fatherSibiling : fatherSibilings) {
//						if (fatherSibiling.getCprNumber().equals(relatedCprNumber))
//							return "UNCLE/AUNT";
//					}
//
//				}
//
//				if (family.getMotherCprNumber() != null) {
//
//					if (family.getMotherCprNumber().equals(relatedCprNumber))
//						return "MOTHER";
//
//					Family MotherMotherFather = crsService.getFamilyServiceRef()
//							.getFamilyDetails(family.getMotherCprNumber());
//
//					if (MotherMotherFather != null && MotherMotherFather.getFatherCprNumber() != null
//							&& MotherMotherFather.getFatherCprNumber().equals(relatedCprNumber))
//						return "GRANDFATHER";
//
//					if (MotherMotherFather != null && MotherMotherFather.getMotherCprNumber() != null
//							&& MotherMotherFather.getMotherCprNumber().equals(relatedCprNumber))
//						return "GRANDMOTHER";
//
//					List<PersonSummary> motherSibilings = crsService.getFamilyServiceRef()
//							.getPersonSiblings(family.getMotherCprNumber());
//					for (PersonSummary motherSibiling : motherSibilings) {
//						if (motherSibiling.getCprNumber().equals(relatedCprNumber))
//							return "UNCLE/AUNT";
//					}
//
//				}
//
//			}
//
//			List<PersonSummary> sibilings = crsService.getFamilyServiceRef().getPersonSiblings(cprNumber);
//
//			for (PersonSummary sibiling : sibilings) {
//
//				if (sibiling.getCprNumber().equals(relatedCprNumber))
//					return "SIBILING";
//				else {
//
//					//
//
//					HashMap<Integer, List<PersonSummary>> nephewNieces = crsService.getFamilyServiceRef()
//							.getPersonChildrenBySpouse(sibiling.getCprNumber());
//
//					Iterator Iter = nephewNieces.entrySet().iterator();
//					while (Iter.hasNext()) {
//						Map.Entry p = (Map.Entry) Iter.next();
//						if (p.getValue() != null) {
//							List<PersonSummary> nephewNieceList = (List<PersonSummary>) p.getValue();
//							for (PersonSummary nephewNiece : nephewNieceList) {
//								if (nephewNiece.getCprNumber().equals(relatedCprNumber)) {
//									return "NEWPHEW/NIECE";
//								}
//							}
//						}
//						Iter.remove(); // avoids a
//										// ConcurrentModificationException
//					}
//
//					//
//				}
//			}
//
//			List<Integer> spouses = new ArrayList<Integer>();
//
//			try {
//
//				spouses = crsService.getFamilyServiceRef().getPersonActiveSpouses(cprNumber);
//
//				if (!spouses.isEmpty() && spouses.contains(relatedCprNumber))
//					return "SPOUSE";
//
//			} catch (Exception ex) {
//				logger.debug("getPersonRelationship(Integer, Integer) - CPR = " + cprNumber + " HAS NO ACTIVE SPOUSE");
//			}
//
//			HashMap<Integer, List<PersonSummary>> children = crsService.getFamilyServiceRef()
//					.getPersonChildrenBySpouse(cprNumber);
//
//			Iterator it = children.entrySet().iterator();
//			while (it.hasNext()) {
//				Map.Entry pair = (Map.Entry) it.next();
//				if (pair.getValue() != null) {
//					List<PersonSummary> childernList = (List<PersonSummary>) pair.getValue();
//					for (PersonSummary personSummary : childernList) {
//						if (personSummary.getCprNumber().equals(relatedCprNumber)) {
//							return "SON/DAUGTHER";
//						} else {
//							HashMap<Integer, List<PersonSummary>> grandchildren = crsService.getFamilyServiceRef()
//									.getPersonChildrenBySpouse(personSummary.getCprNumber());
//
//							Iterator it2 = grandchildren.entrySet().iterator();
//							while (it2.hasNext()) {
//								Map.Entry pair2 = (Map.Entry) it2.next();
//								if (pair2.getValue() != null) {
//									List<PersonSummary> childernList2 = (List<PersonSummary>) pair2.getValue();
//									for (PersonSummary personSummary2 : childernList2) {
//										if (personSummary2.getCprNumber().equals(relatedCprNumber)) {
//											return "GRAND SON/GRAND DAUGTHER";
//										}
//									}
//								}
//								it2.remove(); // avoids a
//												// ConcurrentModificationException
//							}
//
//						}
//					}
//				}
//				it.remove(); // avoids a ConcurrentModificationException
//			}
//
//		} catch (Exception exception) {
//			// TODO: handle exception
//
//			exception.printStackTrace();
//
//			if (logger.isDebugEnabled())
//				logger.error("getPersonRelationship(Integer, Integer) Error: " + exception.getMessage());
//			throw new ApplicationExceptionInfo("Person Details Not found",
//					new ApplicationException(exception.getMessage()));
//		}
//
//		return "NO RELATION";
//	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

	@Override
	@Secured({ "ROLE_checkRelationship" })
	@WebMethod(operationName = "checkRelationship")
	public boolean checkRelationship(SecurityTagObject security, Integer cprNumber, Integer relatedCprNumber)
			throws ApplicationExceptionInfo {
		boolean isRelated = false;

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonRelationship(Integer, Integer) - start");
			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ")");
		}

		if (!validationUtil.isDeletedCpr(cprNumber) && !validationUtil.isDeletedCpr(relatedCprNumber)
				&& !validationUtil.isMilitaryCpr(cprNumber) && !validationUtil.isMilitaryCpr(relatedCprNumber)) {
			try {
				Family family = crsService.getFamilyServiceRef().getFamilyDetails(cprNumber);

				if (family.getFatherCprNumber() != null) {
					if (family.getFatherCprNumber().equals(relatedCprNumber))
						isRelated = true;
				}

				if (family.getMotherCprNumber() != null) {

					if (family.getMotherCprNumber().equals(relatedCprNumber))
						isRelated = true;
				}

				List<PersonSummary> sibilings = crsService.getFamilyServiceRef().getPersonSiblings(cprNumber);

				for (PersonSummary sibiling : sibilings) {

					if (sibiling.getCprNumber().equals(relatedCprNumber))
						isRelated = true;
				}

				HashMap<Integer, List<PersonSummary>> children = crsService.getFamilyServiceRef()
						.getPersonChildrenBySpouse(cprNumber);

				Iterator<Map.Entry<Integer, List<PersonSummary>>> it = children.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<Integer, List<PersonSummary>> pair = (Map.Entry<Integer, List<PersonSummary>>) it.next();
					if (pair.getValue() != null) {
						List<PersonSummary> childernList = (List<PersonSummary>) pair.getValue();
						for (PersonSummary personSummary : childernList) {
							if (personSummary.getCprNumber().equals(relatedCprNumber)) {
								isRelated = true;
							}
						}
					}
					it.remove(); // avoids a ConcurrentModificationException
				}

			} catch (Exception exception) {
				exception.printStackTrace();

				if (logger.isDebugEnabled())
					logger.error("getPersonRelationship(Integer, Integer) Error: " + exception.getMessage());
				throw new ApplicationExceptionInfo(ERROR_GENERAL,
						new ApplicationException(ERROR_GENERAL, ERROR_GENERAL_CODE));
			}
		}
		return isRelated;
	}

	@Override
	@Secured({ "ROLE_checkRelationshipForDeathCertificate" })
	@WebMethod(operationName = "checkRelationshipForDeathCertificate")
	public boolean checkRelationshipForDeathCertificate(SecurityTagObject security, Integer cprNumber, Integer relatedCprNumber)
			throws ApplicationExceptionInfo {
		boolean isRelated = false;

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonRelationship(Integer, Integer) - start");
			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ")");
		}

		if (!validationUtil.isDeletedCpr(cprNumber) && !validationUtil.isDeletedCpr(relatedCprNumber)
				&& !validationUtil.isMilitaryCpr(cprNumber) && !validationUtil.isMilitaryCpr(relatedCprNumber)) {
			try {
				Family family = crsService.getFamilyServiceRef().getFamilyDetails(cprNumber);

				if (family.getFatherCprNumber() != null) {
					if (family.getFatherCprNumber().equals(relatedCprNumber))
						isRelated = true;
				}

				if (family.getMotherCprNumber() != null) {

					if (family.getMotherCprNumber().equals(relatedCprNumber))
						isRelated = true;
				}
				
				List<Integer> spouses = new ArrayList<Integer>();
				try {
					spouses = crsService.getFamilyServiceRef().getPersonActiveSpouses(cprNumber);
					if (!spouses.isEmpty() && spouses.contains(relatedCprNumber))
						isRelated = true;

				} catch (Exception ex) {
					logger.debug(
							"getPersonRelationship(Integer, Integer) - CPR = " + cprNumber + " HAS NO ACTIVE SPOUSE");
				}

				HashMap<Integer, List<PersonSummary>> children = crsService.getFamilyServiceRef()
						.getPersonChildrenBySpouse(cprNumber);

				Iterator<Map.Entry<Integer, List<PersonSummary>>> it = children.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<Integer, List<PersonSummary>> pair = (Map.Entry<Integer, List<PersonSummary>>) it.next();
					if (pair.getValue() != null) {
						List<PersonSummary> childernList = (List<PersonSummary>) pair.getValue();
						for (PersonSummary personSummary : childernList) {
							if (personSummary.getCprNumber().equals(relatedCprNumber)) {
								isRelated = true;
							}
						}
					}
					it.remove(); // avoids a ConcurrentModificationException
				}

			} catch (Exception exception) {
				exception.printStackTrace();

				if (logger.isDebugEnabled())
					logger.error("getPersonRelationship(Integer, Integer) Error: " + exception.getMessage());
				throw new ApplicationExceptionInfo(ERROR_GENERAL,
						new ApplicationException(ERROR_GENERAL, ERROR_GENERAL_CODE));
			}
		}
		return isRelated;
	}

	@Override
	@Secured({ "ROLE_checkParentsRelationship" })
	@WebMethod(operationName = "checkParentsRelationship")
	public boolean checkParentsRelationship(SecurityTagObject security, Integer cprNumber, Integer fatherCPRNumber,
			Integer motherCPRNumber) throws ApplicationExceptionInfo {
		boolean isFather = false;
		boolean isMother = false;

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonRelationship(Integer, Integer) - start");
			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ")");
		}

		if (!validationUtil.isDeletedCpr(cprNumber) && !validationUtil.isDeletedCpr(fatherCPRNumber)
				&& !validationUtil.isDeletedCpr(motherCPRNumber) && !validationUtil.isMilitaryCpr(cprNumber)
				&& !validationUtil.isMilitaryCpr(fatherCPRNumber) && !validationUtil.isMilitaryCpr(motherCPRNumber)) {
			try {
				Family family = crsService.getFamilyServiceRef().getFamilyDetails(cprNumber);

				if (family.getFatherCprNumber() != null) {
					if (family.getFatherCprNumber().equals(fatherCPRNumber))
						isFather = true;
				}

				if (family.getMotherCprNumber() != null) {

					if (family.getMotherCprNumber().equals(motherCPRNumber))
						isMother = true;
				}
			} catch (Exception exception) {
				exception.printStackTrace();

				if (logger.isDebugEnabled())
					logger.error("getPersonRelationship(Integer, Integer) Error: " + exception.getMessage());
				throw new ApplicationExceptionInfo(ERROR_GENERAL,
						new ApplicationException(ERROR_GENERAL, ERROR_GENERAL_CODE));
			}
		}
		return (isFather && isMother);
	}
}
