package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PaidMOHFees", propOrder =
{ "payFees", "discounted",  "paymentReason"})
public class PaidMOHFeesDTO
{
	private java.lang.Boolean payFees;
	private java.lang.Boolean discounted;
	private String paymentReason;

	public PaidMOHFeesDTO()
	{
		super();

	}

	public PaidMOHFeesDTO(Boolean payFees, Boolean discounted, String paymentReason)
	{
		super();
		this.payFees = payFees;
		this.discounted = discounted;
		this.paymentReason = paymentReason;
	}

	@XmlElement(name = "Discounted", required = true)
	public java.lang.Boolean getDiscounted()
	{
		return discounted;
	}

	@XmlElement(name = "PayFees", required = true)
	public java.lang.Boolean getPayFees()
	{
		return payFees;
	}
	
	@XmlElement(name = "PaymentReason", required = true)
	public String getPaymentReason() {
		return paymentReason;
	}

	public void setPaymentReason(String paymentReason) {
		this.paymentReason = paymentReason;
	}

	public void setDiscounted(java.lang.Boolean discounted)
	{
		this.discounted = discounted;
	}

	public void setPayFees(java.lang.Boolean payFees)
	{
		this.payFees = payFees;
	}

}
