package bh.gov.cio.integration.crs.retrieve.person;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.Family;
import bh.gov.cio.crs.model.person.IndMarriageDivorce;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.person.ResidencyPermit;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.IsPaidMOHFeesServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PaidMOHFeesDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsPaidMOHFeesService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "IsPaidMOHFeesService"
public class IsPaidMOHFeesServiceImpl implements IsPaidMOHFeesServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(IsPaidMOHFeesServiceImpl.class);
	
	/**
	 * PAYMENTS
	 * 	01	BAHRAINI/GCC
	 *  02	GOVERNMENT EMPLOYEE
	 *  03	MARRIED TO BAHRAINI
	 *  04	WIDOW OF BAHRAINI
	 *  05	MOTHER IS BAHRAINI
	 *  06	NON BAHRAINI WITH GOV EMPLOYEE PARENT
	 */

	final static String PAYMENT_BAHRAINI_GCC = "01";
	final static String PAYMENT_GOV_EMPLOYEE = "02";
	final static String PAYMENT_BAHRAINI_SPOUSE = "03";
	final static String PAYMENT_WIDOW_OF_BAHRAINI = "04";
	final static String PAYMENT_BAHRAINI_PARENT = "05";
	final static String PAYMENT_NON_BAHRAINI_GOV_PARENT = "06";
	

	
	final static String PAYMENT_NO_REASON = "00";
	final static String PAYMENT_RESIDENCY_EXPIRED = "91";
	final static String PAYMENT_NO_PERSON = "92";
	
	
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Autowired
	private ValidationServiceImpl validationUtil;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getIsPaidMOHFees" })
	@WebMethod(operationName = "getIsPaidMOHFees")
	public PaidMOHFeesDTO getIsPaidMOHFees(SecurityTagObject security, String GCCID, String CountryCode)
			throws ApplicationExceptionInfo {
		PaidMOHFeesDTO paidMOHFeesDTO = new PaidMOHFeesDTO();
		paidMOHFeesDTO.setPayFees(true);
		paidMOHFeesDTO.setDiscounted(false);
		paidMOHFeesDTO.setPaymentReason(PAYMENT_NO_REASON);
		int employerNumber = 0;
		if (logger.isDebugEnabled()) {
			logger.debug("getIsPaidMOHFees(Integer) - start");
		}

		try {
			// Integer gccSn = null;
			Integer cprNumber = 0;
			// if (CountryCode != null && !CountryCode.trim().equals("")){
			// gccSn =
			// getCrsService().getPersonServiceRef().getGccNationalSn(GCCID,
			// CountryCode);
			// }
			//
			// if(gccSn != null){
			// cprNumber = gccSn;
			// }else{
			//
			// try{
			// cprNumber = Integer.parseInt(GCCID);
			// }catch(Exception e){
			//
			// paidMOHFeesDTO.setPaymentReason(PAYMENT_NO_PERSON);
			// return paidMOHFeesDTO;
			// }
			//
			//
			// }
				
				try{
				cprNumber = validationUtil.getGCCCpr(GCCID, CountryCode);
				}catch(Exception e){
					
					paidMOHFeesDTO.setPaymentReason(PAYMENT_NO_PERSON);
					return paidMOHFeesDTO;
				}
				
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final List<Employment> personEmployement = getCrsService().getEmploymentServiceRef()
					.getActiveEmployments(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final Integer age = personBasicInfo.getAge();
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499")
					|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;

			if (logger.isDebugEnabled()) {
				logger.debug("isBahraini: " + isBahraini + " IS GCC:" + isGCC);
			}

			/*
			 * 
			 * if Bahraini and from GCC then MOH service will be free
			 */
			if (isBahraini || isGCC) {
				paidMOHFeesDTO.setPayFees(false);
				paidMOHFeesDTO.setPaymentReason(PAYMENT_BAHRAINI_GCC); // BAHRAINI/GCC
				if (logger.isDebugEnabled()) {
					logger.debug("paidMOHFeesDTO.getPayFees: " + paidMOHFeesDTO.getPayFees() + "");
				}

			}

			/*
			 * 
			 * if not Bahraini or GCC
			 */

			else {
				if (logger.isDebugEnabled()) {
					logger.debug(" Non Bahraini  ");
				}

				paidMOHFeesDTO.setPayFees(true);

				
				/*
				 * check if the foreigner working at government sectors
				 */
				if ((personEmployement != null) && (!personEmployement.isEmpty())) {
					int i = 0;
					for (final Employment employment2 : personEmployement) {
						final Employment employment = employment2;
						employerNumber = employment.getEmployerNumber();

						if (logger.isDebugEnabled()) {
							logger.debug("EmployerNumber= " + employment.getEmployerNumber() + " - Type= "
									+ employment.getEmployerType());
						}

						logger.debug("Employer type  "+employment.getEmployerType());
						
						if (employerNumber > 80000000 && employerNumber <= 80999999
								&& employment.getEmployerType().equals("U")) {
							paidMOHFeesDTO.setPaymentReason(PAYMENT_GOV_EMPLOYEE);
							paidMOHFeesDTO.setPayFees(false); // GOVERNMENT
																// EMPLOYEE
						}

						// i++;
					}
				}// end if the foreigner working at government sectors

				
				
				/*
				 * 
				 * check if spouse of Bahraini
				 */
				Integer spouseCPR = familyService.getPersonPrimarySpouse(cprNumber);
				if (spouseCPR != null) {
					if (logger.isDebugEnabled()) {
						logger.debug("spouseCPR= " + spouseCPR + "");
					}

					PersonSummary spousePersonSummeryInfo = getCrsService().getPersonServiceRef()
							.getPersonSummary(spouseCPR);
					boolean spouseIsBahraini = (spousePersonSummeryInfo.getNationalityCountryCode().equals("499")
							|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;

					if (logger.isDebugEnabled()) {
						logger.debug("spouseIsBahraini = " + spouseIsBahraini + "");
					}

					if (logger.isDebugEnabled()) {
						logger.debug(
								"spouseMaritalStatusCode = " + spousePersonSummeryInfo.getMaritalStatusCode() + "");
					}

					if (spouseIsBahraini && spousePersonSummeryInfo.getMaritalStatusCode().equals("002")) {
						paidMOHFeesDTO.setPaymentReason(PAYMENT_BAHRAINI_SPOUSE); // MARRIED
																					// TO
																					// BAHRAINI
						paidMOHFeesDTO.setPayFees(false);
					}

					/* Check if she is widow of Bahraini */

					if (paidMOHFeesDTO.getPayFees() && spouseIsBahraini
							&& personSummeryInfo.getMaritalStatusCode().equals("004")) {
						paidMOHFeesDTO.setPaymentReason(PAYMENT_WIDOW_OF_BAHRAINI); // WIDOW
																					// OF
																					// BAHRAINI
						paidMOHFeesDTO.setPayFees(false);
					}
				}else{
					try{
						IndMarriageDivorce marriageDivorce = familyService.getPersonLastActionDetails(cprNumber);
						
						if(marriageDivorce != null && marriageDivorce.getActionType().equalsIgnoreCase("MARRIAGE")){
							
							final PersonSummary spouseSummeryInfo = getCrsService().getPersonServiceRef()
									.getPersonSummary(marriageDivorce.getPartnerCprNumber());
							
							if (logger.isDebugEnabled()) {
								logger.debug(
										"getIsPaidMOHFees - No Primary Spouse and getPersonLastActionDetails not null");
								logger.debug("getIsPaidMOHFees - Spouse CPR " + spouseSummeryInfo.getCprNumber() + " - "
										+ marriageDivorce.getActionType());
							}

							boolean spouseIsBahraini = (spouseSummeryInfo.getNationalityCountryCode().equals("499")
									|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;

							if (paidMOHFeesDTO.getPayFees() && spouseIsBahraini
									&& personSummeryInfo.getMaritalStatusCode().equals("004")) {
								paidMOHFeesDTO.setPaymentReason(PAYMENT_WIDOW_OF_BAHRAINI); // WIDOW
																							// OF
																							// BAHRAINI
								paidMOHFeesDTO.setPayFees(false);
							}
						}
						
					}catch(Exception e){
						logger.debug("getIsPaidMOHFees - "+e.getMessage());
					}
				}

				/* check if the non Bahraini is son / daughter Bahraini mother */
				// Integer familyDetails =
				Family family = null;
				try {
					family = familyService.getPersonFatherMother(cprNumber);
				} catch (Exception e) {
					logger.debug("Family Exception : " + e.getMessage());
				}

				if (family != null) {
					
					// MOTHER CHECK
					Integer citizenMotherCPR = family.getMotherCprNumber();

					if (citizenMotherCPR != null) {
						PersonSummary motherPersonSummeryInfo = getCrsService().getPersonServiceRef()
								.getPersonSummary(citizenMotherCPR);
						boolean motherIsBahraini = motherPersonSummeryInfo.isBahraini();
						final List<Employment> personMotherEmployement = getCrsService().getEmploymentServiceRef()
								.getActiveEmployments(citizenMotherCPR);
						
						if (logger.isDebugEnabled()) {
							logger.debug("motherIsBahraini = " + motherIsBahraini + "");
						}

						if (motherIsBahraini) {
							paidMOHFeesDTO.setPaymentReason(PAYMENT_BAHRAINI_PARENT); // MOTHER
																						// IS
																						// BAHRAINI
							paidMOHFeesDTO.setPayFees(false);
						}
						
						for (final Employment employment2 : personMotherEmployement) {
							final Employment employment = employment2;
							employerNumber = employment.getEmployerNumber();

							if (logger.isDebugEnabled()) {
								logger.debug("EmployerNumber= " + employment.getEmployerNumber() + " - Type= "
										+ employment.getEmployerType());
							}

							logger.debug("Employer type  "+employment.getEmployerType());
							
							if (employerNumber > 80000000 && employerNumber <= 80999999
									&& employment.getEmployerType().equals("U") && age <= 18) {
								paidMOHFeesDTO.setPaymentReason(PAYMENT_NON_BAHRAINI_GOV_PARENT);
								paidMOHFeesDTO.setPayFees(false); // GOVERNMENT
																	// EMPLOYEE
							}

						}
						
					}
					
					
					//FATHER CHECK
					
					Integer citizenFatherCPR = family.getFatherCprNumber();

					if (citizenFatherCPR != null) {
						PersonSummary persoFatherSummeryInfo = getCrsService().getPersonServiceRef()
								.getPersonSummary(citizenFatherCPR);
						boolean FatherIsBahraini = persoFatherSummeryInfo.isBahraini();
						final List<Employment> persoFatherEmployement = getCrsService().getEmploymentServiceRef()
								.getActiveEmployments(citizenFatherCPR);
						
						if (logger.isDebugEnabled()) {
							logger.debug("motherIsBahraini = " + FatherIsBahraini + "");
						}

						if (FatherIsBahraini) {
							paidMOHFeesDTO.setPaymentReason(PAYMENT_BAHRAINI_PARENT); // MOTHER
																						// IS
																						// BAHRAINI
							paidMOHFeesDTO.setPayFees(false);
						}
						
						for (final Employment employment2 : persoFatherEmployement) {
							final Employment employment = employment2;
							employerNumber = employment.getEmployerNumber();

							if (logger.isDebugEnabled()) {
								logger.debug("EmployerNumber= " + employment.getEmployerNumber() + " - Type= "
										+ employment.getEmployerType());
							}

							logger.debug("Employer type  "+employment.getEmployerType());
							
							if (employerNumber > 80000000 && employerNumber <= 80999999
									&& employment.getEmployerType().equals("U") && age <= 18) {
								paidMOHFeesDTO.setPaymentReason(PAYMENT_NON_BAHRAINI_GOV_PARENT);
								paidMOHFeesDTO.setPayFees(false); // GOVERNMENT
																	// EMPLOYEE
							}

							// i++;
						}
						
					}
					
					
				}
				
				
				
				

				/*
				 * check if the foreigner has valid Residency permit
				 */
				
				ResidencyPermit personResidencyPermit = getCrsService().getGDNPRServiceRef()
						.getResidencyPermit(cprNumber);
				if(personResidencyPermit != null && !paidMOHFeesDTO.getPayFees()){
					
					if (personResidencyPermit.getExpiryDate() == null
							|| personResidencyPermit.getExpiryDate().before(new Date())) {
						
						paidMOHFeesDTO.setPaymentReason(PAYMENT_RESIDENCY_EXPIRED);
						paidMOHFeesDTO.setPayFees(true); //RESIDENCY_EXPIRED
						
					}
					
				}

			}// end if non Bahraini

	
			
			///////////////////////////////////////////
			
			
			/////////////////////////////////////////////
			
			
			
			
			
			/*
			 * 
			 * 
			 * 
			 * Check if he/she working at MOH to get discount for private rooms
			 */

			/*
			 * 1- IF MOH Employee
			 */

			if (logger.isDebugEnabled()) {
				logger.debug("**********cheking if person get discount for private rooms********** ");
			}
			if ((personEmployement != null) && (!personEmployement.isEmpty())) {
				int i = 0;
				for (final Employment employment2 : personEmployement) {
					final Employment employment = employment2;
					employerNumber = employment.getEmployerNumber();

					if (logger.isDebugEnabled()) {
						logger.debug("EmployerNumber= " + employment.getEmployerNumber() + "");
					}

					if (employerNumber >= 80220000 && employerNumber <= 80229999 && employerNumber != 80225900
							&& employerNumber != 80226200) {
						if (logger.isDebugEnabled()) {
							logger.debug("1- MOH Employee");
						}

						paidMOHFeesDTO.setDiscounted(true);

					}
					// i++;
				}
			}// 1- End IF MOH Employee

			else {
				/*
				 * 2- IF wife/husband working at MOH
				 */

				Integer spouseCPR = familyService.getPersonPrimarySpouse(cprNumber);

				if (spouseCPR != null) {

					final List<Employment> spouseEmployementDetails = getCrsService().getEmploymentServiceRef()
							.getActiveEmployments(spouseCPR);

					if ((spouseEmployementDetails != null) && (!spouseEmployementDetails.isEmpty())) {
						int i = 0;
						for (final Employment employment2 : spouseEmployementDetails) {
							final Employment employment = employment2;
							employerNumber = employment.getEmployerNumber();

							if (logger.isDebugEnabled()) {
								logger.debug("EmployerNumber= " + employment.getEmployerNumber() + "");
							}

							if (employerNumber >= 80220000 && employerNumber <= 80229999 && employerNumber != 80225900
									&& employerNumber != 80226200) {
								if (logger.isDebugEnabled()) {
									logger.debug("2- IF wife/husband working at MOH");
								}

								paidMOHFeesDTO.setDiscounted(true);
							}
							// i++;
						}
					}
				}// 2- End IF wife/husband working at MOH

				/*
				 * 3- IF person is son/daughter of MOH employee parent
				 */
				Family familyDetails = null;
				try {
					familyDetails = familyService.getPersonFatherMother(cprNumber);
				} catch (Exception e) {
					logger.debug("Family Exception : " + e.getMessage());
				}
				if (familyDetails != null) {

					Integer personMotherCPR = familyDetails.getMotherCprNumber();
					Integer personFatherCPR = familyDetails.getFatherCprNumber();

					if (personMotherCPR != null) {
						final List<Employment> motherEmployementDetails = getCrsService().getEmploymentServiceRef()
								.getActiveEmployments(personMotherCPR);
						if ((motherEmployementDetails != null) && (!motherEmployementDetails.isEmpty())) {

							for (final Employment employment2 : motherEmployementDetails) {
								final Employment employment = employment2;
								employerNumber = employment.getEmployerNumber();

								if (logger.isDebugEnabled()) {
									logger.debug("EmployerNumber= " + employment.getEmployerNumber() + "");
								}

								if (employerNumber >= 80220000 && employerNumber <= 80229999
										&& employerNumber != 80225900 && employerNumber != 80226200) {
									if (logger.isDebugEnabled()) {
										logger.debug("3- his/her mother is MOH employee");
									}
									paidMOHFeesDTO.setDiscounted(true);
								}

							}
						}
					}// End IF person is his/her mother is MOH employee

					if (personFatherCPR != null) {
						final List<Employment> fatherEmployementDetails = getCrsService().getEmploymentServiceRef()
								.getActiveEmployments(personFatherCPR);
						if ((fatherEmployementDetails != null) && (!fatherEmployementDetails.isEmpty())) {

							for (final Employment employment2 : fatherEmployementDetails) {
								final Employment employment = employment2;
								employerNumber = employment.getEmployerNumber();

								if (logger.isDebugEnabled()) {
									logger.debug("EmployerNumber= " + employment.getEmployerNumber() + "");
								}

								if (employerNumber >= 80220000 && employerNumber <= 80229999
										&& employerNumber != 80225900 && employerNumber != 80226200) {
									if (logger.isDebugEnabled()) {
										logger.debug("3- his/her father is MOH employee");
									}

									paidMOHFeesDTO.setDiscounted(true);
								}

							}
						}
					}// End IF his/her father is MOH employee
				}
				/*
				 * 4- IF person is parent of MOH employee
				 */

				final HashMap<Integer, List<PersonSummary>> hm = familyService.getPersonChildrenBySpouse(cprNumber);

				if (logger.isDebugEnabled()) {
					logger.debug("getPersonDetails() -  No Of Wives = " + hm);
				}

				if (hm != null) {
					final Collection<List<PersonSummary>> wivesList = hm.values();

					for (final List<PersonSummary> list : wivesList) {
						final List<PersonSummary> childrenList = list;
						for (final PersonSummary personSummary : childrenList) {
							final PersonSummary childrenSummary = personSummary;
							try {
								final List<Employment> personEmployementDetails = getCrsService()
										.getEmploymentServiceRef().getActiveEmployments(childrenSummary.getCprNumber());

								if ((personEmployementDetails != null) && (!personEmployementDetails.isEmpty())) {

									for (final Employment employment2 : personEmployementDetails) {
										final Employment employment = employment2;
										employerNumber = employment.getEmployerNumber();

										if (logger.isDebugEnabled()) {
											logger.debug("EmployerNumber for the son or daughter= "
													+ employment.getEmployerNumber() + "");
										}

										if (employerNumber >= 80220000 && employerNumber <= 80229999
												&& employerNumber != 80225900 && employerNumber != 80226200) {
											/*
											 * check if the parent live in same
											 * address
											 */
											try {
												final List<Address> personAddresses = getCrsService()
														.getAddressServiceRef()
														.getPersonAddressByCpr(childrenSummary.getCprNumber());

												logger.debug("Son or daughter CPR number: "
														+ childrenSummary.getCprNumber());
												List<Address> allAddressOccupants = null;
												Address currentAddress = null;

												if (personAddresses != null) {
													currentAddress = personAddresses.get(personAddresses.size() - 1);
													logger.debug("personAddresses size is :" + personAddresses.size());
													allAddressOccupants = getCrsService().getAddressServiceRef()
															.getOccupantsByAddress(currentAddress.getFlatNumber(),
																	currentAddress.getBuildingNumber(),
																	currentAddress.getNameAlphaEnglish(),
																	currentAddress.getRoadNumber(),
															currentAddress.getBlockNumber());

													if ((allAddressOccupants != null)
															&& (!allAddressOccupants.isEmpty())) {
														logger.debug("allAddressOccupants.size() is :"
																+ allAddressOccupants.size());

														for (final Address allAddOccupants : allAddressOccupants) {

															if (logger.isDebugEnabled()) {
																logger.debug("AddressOccupantNumber= "
																		+ allAddOccupants.getCprNumber() + "");
															}
															if (cprNumber.equals(allAddOccupants.getCprNumber())) {
																if (logger.isDebugEnabled()) {
																	logger.debug(
																			"4- IF person is parent of MOH employee");
																}

																paidMOHFeesDTO.setDiscounted(true);

															}

														}

													}

												} // checking if parent live
													// with
													// MOH Employee

											}

											catch (Exception e) {
												logger.debug("Address Exception : " + e.getMessage());
											}

										}

									}
								}
							} catch (Exception e) {
								logger.debug("He has no children ");

							}// 4- End IF person is parent of MOH employee

						}

					}
				}// end if the person not working
					// "daughter,son,wife,husband or parents of MOH employee"

			}
		} catch (Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {

				logger.error("getIsPaidMOHFees(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person CPR not found",
					new ApplicationException(exception.getMessage()));
		}

		paidMOHFeesDTO.setPaymentReason(null); // remove when implemented
		
		return paidMOHFeesDTO;
	}

	public IsPaidMOHFeesServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
}
