package bh.gov.cio.integration.crs.retrieve.cr;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.cr.CRDetails;
import bh.gov.cio.crs.model.unit.UnitActivity;
import bh.gov.cio.crs.model.unit.UnitEntity;
import bh.gov.cio.crs.service.UnitService;
import bh.gov.cio.crs.util.CRSUtils;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.cr.service.CRSummaryInfoSeviceInterface;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRActivityTypeInfoDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CROwnerInfoDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRSummaryInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CRSummaryInfoService", targetNamespace = "http://service.cr.retrieve.crs.integration.cio.gov.bh/")
public class CRSummaryInfoServiceImpl implements CRSummaryInfoSeviceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(CRSummaryInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getCRSummaryInfo" })
	@WebMethod(operationName = "getCRSummaryInfo")
	public CRSummaryInfoDTO getCRSummaryInfo(SecurityTagObject security, Integer crNumber) throws ApplicationExceptionInfo
	{
		CRSummaryInfoDTO result = null;

		final UnitService unitService = crsService.getUnitServiceRef();
		try
		{
			CRDetails crDetails = unitService.getCrBasicInfo(crNumber);
			if("F".equals(crDetails.getIsActive())){
				//logger.debug("cr is canceled: " + crDetails.getIsActive());
				throw new ApplicationExceptionInfo("CR is canceled", new ApplicationException("CR is canceled"));
			}

			String licenseExpiryDate = "";
			String operationStartDate = "";
			String operationEndDate = "";

			SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");

			if (crDetails.getLicenseExpiryDate() != null)
			{

				licenseExpiryDate = df.format(CRSUtils.getDateFromTimestamp(crDetails.getLicenseExpiryDate()));

			}

			if (crDetails.getOperationStartDate() != null)
			{

				operationStartDate = df.format(CRSUtils.getDateFromTimestamp(crDetails.getOperationStartDate()));

			}

			if (crDetails.getOperationEndDate() != null)
			{

				operationEndDate = df.format(CRSUtils.getDateFromTimestamp(crDetails.getOperationEndDate()));

			}

			List<UnitActivity> crActivities = unitService.getCrActivities(crNumber);

			ArrayList<CRActivityTypeInfoDTO> crActivityList = null;

			int i = 0;

			if (logger.isDebugEnabled())
			{
				logger.debug("getCrActivities() -  activities owner size list = " + crActivities.size());
			}

			if (crActivities != null && crActivities.size() > 0)
			{
				crActivityList = new ArrayList<CRActivityTypeInfoDTO>();
				for (final UnitActivity crActivity : crActivities)
				{
					crActivityList.add(
							i,
							new CRActivityTypeInfoDTO(crActivity.getMainActivityCode(), crActivity.getMainActivityArNm(), crActivity
									.getMainActivityEnNm(), crActivity.getLocalActivityCode(), crActivity.getNationaliActivityCode()));

					if (logger.isDebugEnabled())
					{
						logger.debug("MainActivityCode() = " + crActivity.getMainActivityCode() + "MainActivityEnNm= "
								+ crActivity.getMainActivityEnNm());
					}

					i++;
				}
			}

			List<UnitEntity> crOwners = unitService.getCrBasicInfo(crNumber).getOwnersList();
			ArrayList<CROwnerInfoDTO> crOwnerList = null;
			i = 0;

			if (logger.isDebugEnabled())
			{
				logger.debug("getOwnersList() -  cr Owners  size list = " + crOwners.size());
			}

			if (crOwners != null && crOwners.size() > 0)
			{
				crOwnerList = new ArrayList<CROwnerInfoDTO>();
				for (final UnitEntity crOwner : crOwners)
				{
					crOwnerList.add(
							i,
							new CROwnerInfoDTO(crOwner.getEntityNumber(), crOwner.getEntityType(), crOwner.getEntityName(), crOwner
									.getEntityEnglishName()));

					i++;
				}
			}

			result = new CRSummaryInfoDTO(crDetails.getCrNumber(), crDetails.getCrArabicName(), crDetails.getCrEnglishName(),
					crDetails.getCompanyStatusCode(), licenseExpiryDate, crDetails.getCountryArNm(), crDetails.getCountryEnNm(), operationEndDate,
					operationStartDate, crDetails.getCrLegalStatusCode(), crDetails.getLegalArName(), crDetails.getLegalEnName(),
					crDetails.getCrSectorCode(), crDetails.getSectorArName(), crDetails.getSectorEnName(), crDetails.getAuthorizedCapital(),
					crDetails.getPaidCapital(), crDetails.getIssuedCapital(), crActivityList, crOwnerList);

		}

		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error(" Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Fetching CR Details", new ApplicationException(exception.getMessage()));

		}

		return result;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
