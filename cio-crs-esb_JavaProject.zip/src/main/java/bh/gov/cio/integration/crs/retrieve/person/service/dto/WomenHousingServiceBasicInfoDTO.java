package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "HousingApplicantDetails", propOrder =
{ "applicantCprNumber", "applicantFullArabicName", "applicantFullEnglishName", "applicantGender", "applicantMaritalStatus", "applicantNoOfChildren",
		"governorateNameArabic", "governorateNameEnglish", "dateOfHousingApplication", "typeOfHousingApplication", "categoryOfHousingApplication",
		"statusOfHousingApplication" })
public class WomenHousingServiceBasicInfoDTO
{

	private Integer applicantCprNumber;
	private String applicantFullArabicName;
	private String applicantFullEnglishName;
	private String applicantGender;
	private String applicantMaritalStatus;
	private Integer applicantNoOfChildren;
	private String governorateNameArabic;
	private String governorateNameEnglish;
	private String dateOfHousingApplication;
	private String typeOfHousingApplication;
	private String categoryOfHousingApplication;
	private String statusOfHousingApplication;

	public WomenHousingServiceBasicInfoDTO()
	{
		super();
	}

	public WomenHousingServiceBasicInfoDTO(Integer applicantCprNumber, String applicantFullArabicName, String applicantFullEnglishName,
			String applicantGender, String applicantMaritalStatus, Integer applicantNoOfChildren, String governorateNameArabic,
			String governorateNameEnglish)
	{
		super();
		this.applicantCprNumber = applicantCprNumber;
		this.applicantFullArabicName = applicantFullArabicName;
		this.applicantFullEnglishName = applicantFullEnglishName;
		this.applicantGender = applicantGender;
		this.applicantMaritalStatus = applicantMaritalStatus;
		this.applicantNoOfChildren = applicantNoOfChildren;
		this.governorateNameArabic = governorateNameArabic;
		this.governorateNameEnglish = governorateNameEnglish;
	}

	@XmlElement(name = "ApplicantCprNumber")
	public Integer getApplicantCprNumber()
	{
		return applicantCprNumber;
	}

	@XmlElement(name = "ApplicantFullArabicName")
	public String getApplicantFullArabicName()
	{
		return applicantFullArabicName;
	}

	@XmlElement(name = "ApplicantFullEnglishName")
	public String getApplicantFullEnglishName()
	{
		return applicantFullEnglishName;
	}

	@XmlElement(name = "ApplicantGender")
	public String getApplicantGender()
	{
		return applicantGender;
	}

	@XmlElement(name = "ApplicantMaritalStatus")
	public String getApplicantMaritalStatus()
	{
		return applicantMaritalStatus;
	}

	@XmlElement(name = "ApplicantNoOfChildren")
	public Integer getApplicantNoOfChildren()
	{
		return applicantNoOfChildren;
	}

	@XmlElement(name = "CategoryOfHousingApplication")
	public String getCategoryOfHousingApplication()
	{
		return categoryOfHousingApplication;
	}

	@XmlElement(name = "DateOfHousingApplication")
	public String getDateOfHousingApplication()
	{
		return dateOfHousingApplication;
	}

	@XmlElement(name = "GovernorateNameArabic")
	public String getGovernorateNameArabic()
	{
		return governorateNameArabic;
	}

	@XmlElement(name = "GovernorateNameEnglish")
	public String getGovernorateNameEnglish()
	{
		return governorateNameEnglish;
	}

	@XmlElement(name = "StatusOfHousingApplication")
	public String getStatusOfHousingApplication()
	{
		return statusOfHousingApplication;
	}

	@XmlElement(name = "TypeOfHousingApplication")
	public String getTypeOfHousingApplication()
	{
		return typeOfHousingApplication;
	}

	public void setApplicantCprNumber(Integer applicantCprNumber)
	{
		this.applicantCprNumber = applicantCprNumber;
	}

	public void setApplicantFullArabicName(String applicantFullArabicName)
	{
		this.applicantFullArabicName = applicantFullArabicName;
	}

	public void setApplicantFullEnglishName(String applicantFullEnglishName)
	{
		this.applicantFullEnglishName = applicantFullEnglishName;
	}

	public void setApplicantGender(String applicantGender)
	{
		this.applicantGender = applicantGender;
	}

	public void setApplicantMaritalStatus(String applicantMaritalStatus)
	{
		this.applicantMaritalStatus = applicantMaritalStatus;
	}

	public void setApplicantNoOfChildren(Integer applicantNoOfChildren)
	{
		this.applicantNoOfChildren = applicantNoOfChildren;
	}

	public void setCategoryOfHousingApplication(String categoryOfHousingApplication)
	{
		this.categoryOfHousingApplication = categoryOfHousingApplication;
	}

	public void setDateOfHousingApplication(String dateOfHousingApplication)
	{
		this.dateOfHousingApplication = dateOfHousingApplication;
	}

	public void setGovernorateNameArabic(String governorateNameArabic)
	{
		this.governorateNameArabic = governorateNameArabic;
	}

	public void setGovernorateNameEnglish(String governorateNameEnglish)
	{
		this.governorateNameEnglish = governorateNameEnglish;
	}

	public void setStatusOfHousingApplication(String statusOfHousingApplication)
	{
		this.statusOfHousingApplication = statusOfHousingApplication;
	}

	public void setTypeOfHousingApplication(String typeOfHousingApplication)
	{
		this.typeOfHousingApplication = typeOfHousingApplication;
	}

}
