package bh.gov.cio.integration.crs.retrieve.family.service.dto;

public class FamilyBasicSpecialInfoDTO
{
	private String	maritalStatusCode;
	private String	partenerCprNumber;
	private String	marriageDivorceIndicator;
	private String	marriageDivorceDate;
	private String	partenerFullName;

	public FamilyBasicSpecialInfoDTO()
	{
		super();
	}

	public FamilyBasicSpecialInfoDTO(String maritalStatusCode,
			String partenerCprNumber, String marriageDivorceIndicator,
			String marriageDivorceDate, String partenerFullName)
	{
		super();
		this.maritalStatusCode = maritalStatusCode;
		this.partenerCprNumber = partenerCprNumber;
		this.marriageDivorceIndicator = marriageDivorceIndicator;
		this.marriageDivorceDate = marriageDivorceDate;
		this.partenerFullName = partenerFullName;
	}

	public String getMaritalStatusCode()
	{
		return maritalStatusCode;
	}

	public String getMarriageDivorceDate()
	{
		return marriageDivorceDate;
	}

	public String getMarriageDivorceIndicator()
	{
		return marriageDivorceIndicator;
	}

	public String getPartenerCprNumber()
	{
		return partenerCprNumber;
	}

	public String getPartenerFullName()
	{
		return partenerFullName;
	}

	public void setMaritalStatusCode(String maritalStatusCode)
	{
		this.maritalStatusCode = maritalStatusCode;
	}

	public void setMarriageDivorceDate(String marriageDivorceDate)
	{
		this.marriageDivorceDate = marriageDivorceDate;
	}

	public void setMarriageDivorceIndicator(String marriageDivorceIndicator)
	{
		this.marriageDivorceIndicator = marriageDivorceIndicator;
	}

	public void setPartenerCprNumber(String partenerCprNumber)
	{
		this.partenerCprNumber = partenerCprNumber;
	}

	public void setPartenerFullName(String partenerFullName)
	{
		this.partenerFullName = partenerFullName;
	}

}
