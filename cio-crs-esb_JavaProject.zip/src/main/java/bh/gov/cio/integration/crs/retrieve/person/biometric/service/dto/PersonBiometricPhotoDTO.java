package bh.gov.cio.integration.crs.retrieve.person.biometric.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonBiometricPhoto", propOrder =
{ "cprNumber", "personPhoto", "photoDate" })
public class PersonBiometricPhotoDTO
{

	private Integer cprNumber;
	private byte[] personPhoto;
	private String photoDate;

	public PersonBiometricPhotoDTO()
	{
		super();

	}

	public PersonBiometricPhotoDTO(Integer cprNumber, byte[] personPhoto, String photoDate)
	{
		super();
		this.cprNumber = cprNumber;
		this.personPhoto = personPhoto;
		this.photoDate = photoDate;
	}

	public PersonBiometricPhotoDTO(String cprNumber)
	{

	}

	@XmlElement(name = "CprNumber")
	public Integer getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(name = "PersonPhoto")
	public byte[] getPersonPhoto()
	{
		return personPhoto;
	}

	@XmlElement(name = "PhotoDate")
	public String getPhotoDate()
	{
		return photoDate;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setPersonPhoto(byte[] personPhoto)
	{
		this.personPhoto = personPhoto;
	}

	public void setPhotoDate(String photoDate)
	{
		this.photoDate = photoDate;
	}

}
