package bh.gov.cio.integration.crs.retrieve.person.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.CSO018PersonBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CSO018PersonBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface CSO018PersonBasicInfoServiceInterface
{
	@WebResult(name = "CSO018PersonBasicInformation")
	@WebMethod(operationName = "getPersonBasicInfo")
	CSO018PersonBasicInfoDTO getCSO018PersonBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "nationalityCode") @XmlElement(required = true) String nationalityCode,
			@WebParam(name = "cardCountryCode") @XmlElement(required = true) String cardCountryCode,
			@WebParam(name = "dateOfBirth") @XmlElement(required = true) String dateOfBirth) throws ApplicationExceptionInfo;

}
