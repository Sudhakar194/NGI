package bh.gov.cio.integration.crs.retrieve.family.rco.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.FatherInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.FatherMotherInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.MotherInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.NextOfKinInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "RCOService", targetNamespace = "http://rco.service.family.retrieve.crs.integration.cio.gov.bh/")
public interface RCOServiceInterface {
//	@WebMethod(operationName = "getMotherInfo")
//	MotherInfoDTO getMotherInfo(
//			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "MotherCPRNumber") @XmlElement(required = true) Integer motherCPRNumber) throws ApplicationExceptionInfo;
//
//	@WebMethod(operationName = "getFatherInfo")
//	FatherInfoDTO getFatherInfo(
//			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "FatherCPRNumber") @XmlElement(required = true) Integer fatherCPRNumber) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getNextOfKinInfo")
	NextOfKinInfoDTO getNextOfKinInfo(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "NextOfKinCPRNumber") @XmlElement(required = true) Integer nextOfKinCPRNumber) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getFatherMotherRelatedInfo")
	FatherMotherInfoDTO getFatherMotherRelatedInfo(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "FatherCPRNumber") @XmlElement(required = true) Integer fatherCPRNumber,
			@WebParam(name = "MotherCPRNumber") @XmlElement(required = true) Integer motherCPRNumber) throws ApplicationExceptionInfo;
}
