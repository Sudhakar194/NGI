package bh.gov.cio.integration.crs.retrieve.person.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.PolytechnicPersonInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PolytechnicPersonInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface PolytechnicPersonInfoServiceInterface
{
	@WebResult(name = "PolytechnicPersonInfo")
	@WebMethod(operationName = "getPersonInfoByCPR")
	PolytechnicPersonInfoDTO getPersonInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;
}
