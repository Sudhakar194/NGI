package bh.gov.cio.integration.crs.retrieve.person;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonNameInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServiceNameInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonNameInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonNameInfoService"
public class PersonNameInfoServiceImpl implements PersonNameInfoServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonNameInfoServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	@Autowired
	private PropertyServiceImpl propImpl;
	@Autowired
	private ValidationServiceImpl validationService;

	@Override
	@Secured({ "ROLE_getPersonNameInfoByEKey" })
	@WebMethod(operationName = "getPersonNameInfoByEKey")
	public PersonServiceNameInfoDTO getPersonNameInfoByEKey(SecurityTagObject security, String eKeyIDNumber,
			String cardCountry, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp)
			throws ApplicationExceptionInfo {
		PersonServiceNameInfoDTO personNameInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNameInfo(Integer, Integer, Date) - start");
		}

		if (!checkeKeyResponse(eKeyIDNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp)) {
			throw new ApplicationExceptionInfo("Error in retrieving data...",
					new ApplicationException("Authentication Failed.", "001"));
		}

		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(eKeyIDNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}

		try {
			personNameInfoDTO = getPersonNameInfoByCPR(security, cprNumber);
		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getPersonNameInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personNameInfoDTO;
	}

	@Override
	@Secured({ "ROLE_getPersonNameInfo" })
	@WebMethod(operationName = "getPersonNameInfo")
	public PersonServiceNameInfoDTO getPersonNameInfo(SecurityTagObject security, Integer cprNumber,
			Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo {
		PersonServiceNameInfoDTO personNameInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNameInfo(Integer, Integer, Date) - start");
		}

		if (!validationService.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));

		if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		try {

			personNameInfoDTO = getPersonNameInfoByCPR(security, cprNumber);
		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getPersonNameInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personNameInfoDTO;
	}

	@Override
	@Secured({ "ROLE_getPersonNameInfoByCPR" })
	@WebMethod(operationName = "getPersonNameInfoByCPR")
	public PersonServiceNameInfoDTO getPersonNameInfoByCPR(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		PersonServiceNameInfoDTO personNameInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNameInfoByCPR(Integer) - start");
		}
		// if (validationService.isMilitaryCpr(cprNumber))
		// throw new ApplicationExceptionInfo("UNAUTHORIZED", new
		// ApplicationException("UNAUTHORIZED"));
//		if (validationService.isDeletedCpr(cprNumber))
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted", "014"));
		try {
			personNameInfoDTO = getAllPersonNameInfoByCPR(security, cprNumber);
		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getPersonNameInfoByCPR(Integer) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException("Person Basic Details Not found","001"));
		}
		return personNameInfoDTO;
	}

	@Override
	@Secured({ "ROLE_getAllPersonNameInfoByCPR" })
	@WebMethod(operationName = "getAllPersonNameInfoByCPR")
	public PersonServiceNameInfoDTO getAllPersonNameInfoByCPR(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		PersonServiceNameInfoDTO personNameInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getAllPersonNameInfoByCPR(Integer) - start");
		}
		if (validationService.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted", "014"));
		try {
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			String arabicFullname = (StringUtils.hasText(personSummeryInfo.getArabicFirstName())
					? personSummeryInfo.getArabicFirstName().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getArabicMiddleName1())
							? personSummeryInfo.getArabicMiddleName1().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getArabicMiddleName2())
							? personSummeryInfo.getArabicMiddleName2().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getArabicMiddleName3())
							? personSummeryInfo.getArabicMiddleName3().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getArabicMiddleName4())
							? personSummeryInfo.getArabicMiddleName4().trim() : " ")
					+ (StringUtils.hasText(personSummeryInfo.getArabicFamilyName())
							? personSummeryInfo.getArabicFamilyName().trim() : " ");

			String englishFullname = (StringUtils.hasText(personSummeryInfo.getEnglishFirstName())
					? personSummeryInfo.getEnglishFirstName().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getEnglishMiddleName1())
							? personSummeryInfo.getEnglishMiddleName1().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getEnglishMiddleName2())
							? personSummeryInfo.getEnglishMiddleName2().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getEnglishMiddleName3())
							? personSummeryInfo.getEnglishMiddleName3().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getEnglishMiddleName4())
							? personSummeryInfo.getEnglishMiddleName4().trim() + " " : "")
					+ (StringUtils.hasText(personSummeryInfo.getEnglishFamilyName())
							? personSummeryInfo.getEnglishFamilyName().trim() : "");

			personNameInfoDTO = new PersonServiceNameInfoDTO(personBasicInfo.getPersonDisplayName(), arabicFullname,
					personSummeryInfo.getArabicFirstName(), personSummeryInfo.getArabicMiddleName1(),
					personSummeryInfo.getArabicMiddleName2(), personSummeryInfo.getArabicMiddleName3(),
					personSummeryInfo.getArabicMiddleName4(), personSummeryInfo.getArabicFamilyName(), englishFullname,
					personSummeryInfo.getEnglishFirstName(), personSummeryInfo.getEnglishMiddleName1(),
					personSummeryInfo.getEnglishMiddleName2(), personSummeryInfo.getEnglishMiddleName3(),
					personSummeryInfo.getEnglishMiddleName4(), personSummeryInfo.getEnglishFamilyName());

			if (logger.isDebugEnabled())
				logger.debug("getAllPersonNameInfoByCPR(Integer, Integer, Date) - end");
		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getAllPersonNameInfoByCPR(Integer) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException("Person Basic Details Not found","001"));
		}
		return personNameInfoDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getvalidationService() {
		return validationService;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setvalidationService(ValidationServiceImpl validationService) {
		this.validationService = validationService;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	private boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID,
			String eKeyTimestamp) {
		ValidateToken eKey = crsService.geteKeyServiceRef();
		String accessPassword = propImpl.geteGOVeKeyPassword();
		String response = null;
		CryptoUtil cryptoUtil = new CryptoUtil();
		try {
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber),
					cryptoUtil.encrypt(eKeyServiceID), cryptoUtil.encrypt(eKeyTokenID),
					cryptoUtil.encrypt(eKeyTimestamp));

			response = cryptoUtil.decrypt(response);

			logger.debug("eKey Response:" + response);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));

	}

}
