package bh.gov.cio.integration.crs.retrieve.cr.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "CRActivityDetails", propOrder =
{ "activityTypeCode", "activityTypeArNm", "activityTypeEnNm", "crActivityTypeLcode", "crActivityTypeNcode" })
public class CRActivityTypeInfoDTO
{
	private String activityTypeCode;
	private String activityTypeArNm;
	private String activityTypeEnNm;
	private String crActivityTypeLcode;
	private String crActivityTypeNcode;

	public CRActivityTypeInfoDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public CRActivityTypeInfoDTO(String activityTypeCode, String activityTypeArNm, String activityTypeEnNm, String crActivityTypeLcode,
			String crActivityTypeNcode)
	{
		super();
		this.activityTypeCode = activityTypeCode;
		this.activityTypeArNm = activityTypeArNm;
		this.activityTypeEnNm = activityTypeEnNm;
		this.crActivityTypeLcode = crActivityTypeLcode;
		this.crActivityTypeNcode = crActivityTypeNcode;
	}

	@XmlElement(name = "ActivityTypeArabicName", required = true)
	public String getActivityTypeArNm()
	{
		return activityTypeArNm;
	}

	@XmlElement(name = "ActivityTypeCode", required = true)
	public String getActivityTypeCode()
	{
		return activityTypeCode;
	}

	@XmlElement(name = "ActivityTypeEnglishName", required = true)
	public String getActivityTypeEnNm()
	{
		return activityTypeEnNm;
	}

	@XmlElement(name = "LocaActivityTypeCode", required = true)
	public String getCrActivityTypeLcode()
	{
		return crActivityTypeLcode;
	}

	@XmlElement(name = "InternationalActivityTypeCode", required = true)
	public String getCrActivityTypeNcode()
	{
		return crActivityTypeNcode;
	}

	public void setActivityTypeArNm(String activityTypeArNm)
	{
		this.activityTypeArNm = activityTypeArNm;
	}

	public void setActivityTypeCode(String activityTypeCode)
	{
		this.activityTypeCode = activityTypeCode;
	}

	public void setActivityTypeEnNm(String activityTypeEnNm)
	{
		this.activityTypeEnNm = activityTypeEnNm;
	}

	public void setCrActivityTypeLcode(String crActivityTypeLcode)
	{
		this.crActivityTypeLcode = crActivityTypeLcode;
	}

	public void setCrActivityTypeNcode(String crActivityTypeNcode)
	{
		this.crActivityTypeNcode = crActivityTypeNcode;
	}

}
