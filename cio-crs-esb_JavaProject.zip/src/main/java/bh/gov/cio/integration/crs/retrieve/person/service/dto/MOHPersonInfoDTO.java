package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;

@XmlType(name = "PersonInfo", propOrder =
{ "arabicName", "englishName", "ageGroup" })
public class MOHPersonInfoDTO implements CommonTypes
{
	private String arabicName;
	private String englishName;
	private AgeGroup ageGroup;

	public MOHPersonInfoDTO()
	{
		super();
	}

	public MOHPersonInfoDTO(String arabicName, String englishName, AgeGroup ageGroup) {
		super();
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.ageGroup = ageGroup;
	}

	@XmlElement(name = "ArabicName", required = true)
	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	@XmlElement(name = "EnglishName", required = true)
	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	@XmlElement(name = "AgeGroup", required = true)
	public AgeGroup getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(AgeGroup ageGroup) {
		this.ageGroup = ageGroup;
	}
}
