package bh.gov.cio.integration.crs.retrieve.person.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonOwnedCRDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonOwnedCRService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface PersonOwnedCRServiceInterface
{

//	@WebResult(name = "PersonOwnedCRInformation")
//	@WebMethod(operationName = "getPersonOwnedCR")
//	PersonOwnedCRDTO[] getPersonOwnedCR(@WebParam(mode = WebParam.Mode.IN, name = "Security",
//	header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
//			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "PersonOwnedCRInformation")
	@WebMethod(operationName = "getPersonOwnedCRByCPR")
	PersonOwnedCRDTO[] getPersonOwnedCRByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber)
			throws ApplicationExceptionInfo;
}
