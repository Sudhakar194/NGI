package bh.gov.cio.integration.security;

import javax.xml.bind.annotation.XmlType;

//@XmlAccessorType(XmlAccessType.FIELD)
//@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name = "Password")
public final class PasswordTokenTagObject
{
	// @XmlElement(
	// name = "Password",
	// namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
	// required = true)
	// String password;
	// @XmlValue
	// String passwordType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText";
	//
	// @XmlAttribute(name = "Type", required = true)
	// public String getPasswordType()
	// {
	// return "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText";
	// }

	public PasswordTokenTagObject()
	{
		super();
		// setPasswordType("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
	}

	// public void setPasswordType(String passwordType)
	// {
	// this.passwordType = passwordType;
	// }

}
