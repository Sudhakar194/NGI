package bh.gov.cio.integration.crs.egov.gdt;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.gdt.service.ValidateBasicPersonInfoServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;



@WebService(name = "ValidateBasicPersonInfoService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public class ValidateBasicPersonInfoServiceImpl implements ValidateBasicPersonInfoServiceInterface{

	
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(ValidateBasicPersonInfoServiceImpl.class);
	
	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}
	
	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
	
	
	@Override
	@Secured(
	{ "ROLE_ValidateBasicPersonInfo" })
	@WebMethod(operationName = "validateBasicPersonInfo")
	public Boolean validatePersonBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("validatePersonBasicInfo(Integer, Integer, Date) - start");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
	
		
		
		
		return true;
	}
	
	
	
}
