package bh.gov.cio.integration.crs.nns.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "idsOnlyList", propOrder = { "idNumber", "cardCountryCode", "idType" })
public class IdOnlyInputParamDTO {
	private String idNumber;

	private String cardCountryCode;

	private String idType;

	public IdOnlyInputParamDTO() {
		super();
	}

	public IdOnlyInputParamDTO(String idNumber, String cardCountryCode, String idType) {
		super();
		this.idNumber = idNumber;
		this.cardCountryCode = cardCountryCode;
		this.idType = idType;
	}

	@XmlElement(name = "IdNumber", required = true)
	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	@XmlElement(name = "CardCountryCode", required = true)
	public String getCardCountryCode() {
		return cardCountryCode;
	}

	public void setCardCountryCode(String cardCountryCode) {
		this.cardCountryCode = cardCountryCode;
	}

	@XmlElement(name = "IdType", required = true)
	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}
}
