package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonServiceNameInfo", propOrder =
{ "personDisplayName","arabicFullName", "arabicFirstName", "arabicMiddleName1",
		"arabicMiddleName2", "arabicMiddleName3", "arabicMiddleName4",
		"arabicFamilyName", "englishFullName", "englishFirstName",
		"englishMiddleName1", "englishMiddleName2", "englishMiddleName3",
		"englishMiddleName4", "englishFamilyName"})
public class PersonServiceNameInfoDTO
{
	private String	personDisplayName;
	private java.lang.String	arabicFullName;
	private java.lang.String	arabicFirstName;
	private java.lang.String	arabicMiddleName1;
	private java.lang.String	arabicMiddleName2;
	private java.lang.String	arabicMiddleName3;
	private java.lang.String	arabicMiddleName4;
	private java.lang.String	arabicFamilyName;
	private java.lang.String	englishFullName;
	private java.lang.String	englishFirstName;
	private java.lang.String	englishMiddleName1;
	private java.lang.String	englishMiddleName2;
	private java.lang.String	englishMiddleName3;
	private java.lang.String	englishMiddleName4;
	private java.lang.String	englishFamilyName;

	public PersonServiceNameInfoDTO()
	{
		super();
	}

	public PersonServiceNameInfoDTO(String personDisplayName, String arabicFullName, String arabicFirstName, String arabicMiddleName1, String arabicMiddleName2, String arabicMiddleName3,
			String arabicMiddleName4, String arabicFamilyName, String englishFullName, String englishFirstName, String englishMiddleName1, String englishMiddleName2, String englishMiddleName3,
			String englishMiddleName4, String englishFamilyName)
	{
		super();
		if (personDisplayName!= null)  this.personDisplayName = personDisplayName; else this.personDisplayName = "";
		if (arabicFullName!= null) this.arabicFullName = arabicFullName;else this.arabicFullName = "";
		if (arabicFirstName!= null) this.arabicFirstName = arabicFirstName;else this.arabicFirstName = "";
		if (arabicMiddleName1!= null) this.arabicMiddleName1 = arabicMiddleName1;else this.arabicMiddleName1 = "";
		if (arabicMiddleName2!= null) this.arabicMiddleName2 = arabicMiddleName2;else this.arabicMiddleName2 = "";
		if (arabicMiddleName3!= null) this.arabicMiddleName3 = arabicMiddleName3;else this.arabicMiddleName3 = "";
		if (arabicMiddleName4!= null) this.arabicMiddleName4 = arabicMiddleName4;else this.arabicMiddleName4 = "";
		if (arabicFamilyName!= null) this.arabicFamilyName = arabicFamilyName;else this.arabicFamilyName = "";
		if (englishFullName!= null) this.englishFullName = englishFullName;else this.englishFullName = "";
		if (englishFirstName!= null) this.englishFirstName = englishFirstName;else this.englishFirstName = "";
		if (englishMiddleName1!= null) this.englishMiddleName1 = englishMiddleName1;else this.englishMiddleName1 = "";
		if (englishMiddleName2!= null) this.englishMiddleName2 = englishMiddleName2;else this.englishMiddleName2 = "";
		if (englishMiddleName3!= null) this.englishMiddleName3 = englishMiddleName3;else this.englishMiddleName3 = "";
		if (englishMiddleName4!= null) this.englishMiddleName4 = englishMiddleName4;else this.englishMiddleName4 = "";
		if (englishFamilyName!= null) this.englishFamilyName = englishFamilyName;else this.englishFamilyName = "";
	}

	@XmlElement(name = "PersonDisplayName", required = true)
	public String getPersonDisplayName()
	{
		return personDisplayName;
	}

	public void setPersonDisplayName(String personDisplayName)
	{
		this.personDisplayName = personDisplayName;
	}
	@XmlElement(name = "ArabicFamilyName", required = true)
	public java.lang.String getArabicFamilyName()
	{
		return arabicFamilyName;
	}

	@XmlElement(name = "ArabicFirstName", required = true)
	public java.lang.String getArabicFirstName()
	{
		return arabicFirstName;
	}

	@XmlElement(name = "ArabicFullName", required = true)
	public java.lang.String getArabicFullName()
	{
		return arabicFullName;
	}

	@XmlElement(name = "ArabicMiddleName1", required = true)
	public java.lang.String getArabicMiddleName1()
	{
		return arabicMiddleName1;
	}

	@XmlElement(name = "ArabicMiddleName2", required = true)
	public java.lang.String getArabicMiddleName2()
	{
		return arabicMiddleName2;
	}

	@XmlElement(name = "ArabicMiddleName3", required = true)
	public java.lang.String getArabicMiddleName3()
	{
		return arabicMiddleName3;
	}

	@XmlElement(name = "ArabicMiddleName4", required = true)
	public java.lang.String getArabicMiddleName4()
	{
		return arabicMiddleName4;
	}
	@XmlElement(name = "EnglishFamilyName", required = true)
	public java.lang.String getEnglishFamilyName()
	{
		return englishFamilyName;
	}

	@XmlElement(name = "EnglishFirstName", required = true)
	public java.lang.String getEnglishFirstName()
	{
		return englishFirstName;
	}

	@XmlElement(name = "EnglishFullName", required = true)
	public java.lang.String getEnglishFullName()
	{
		return englishFullName;
	}

	@XmlElement(name = "EnglishMiddleName1", required = true)
	public java.lang.String getEnglishMiddleName1()
	{
		return englishMiddleName1;
	}

	@XmlElement(name = "EnglishMiddleName2", required = true)
	public java.lang.String getEnglishMiddleName2()
	{
		return englishMiddleName2;
	}

	@XmlElement(name = "EnglishMiddleName3", required = true)
	public java.lang.String getEnglishMiddleName3()
	{
		return englishMiddleName3;
	}

	@XmlElement(name = "EnglishMiddleName4", required = true)
	public java.lang.String getEnglishMiddleName4()
	{
		return englishMiddleName4;
	}

}
