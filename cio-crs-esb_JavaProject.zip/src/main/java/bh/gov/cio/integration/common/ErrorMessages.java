package bh.gov.cio.integration.common;

public interface ErrorMessages {

	final String ERROR_CPR_NOT_FOUND = "CPR Number: '?' Not Valid";
	final String ERROR_CPR_NOT_FOUND_CODE = "001";

	final String ERROR_DELETED_CPR = "CPR Number: '?' Is Deleted";
	final String ERROR_DELETED_CPR_CODE = "002";

	final String ERROR_RESTRICTED_CPR = "UNAUTHORIZED";
	final String ERROR_RESTRICTED_CPR_CODE = "003";

	final String ERROR_GENERAL = "General Error Occured";
	final String ERROR_GENERAL_CODE = "004";
}
