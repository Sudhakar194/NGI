/**
 * SubmitPostalTrackingCodeRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package MOTService.com.ngi;

public class SubmitPostalTrackingCodeRequest  implements java.io.Serializable {
    private java.lang.String postalCharges;

    private java.lang.String postalTrackingCode;

    private MOTService.com.ngi.ConsigneeDetails consigneeDetails;

    private MOTService.com.ngi.SenderDetails senderDetails;

    public SubmitPostalTrackingCodeRequest() {
    }

    public SubmitPostalTrackingCodeRequest(
           java.lang.String postalCharges,
           java.lang.String postalTrackingCode,
           MOTService.com.ngi.ConsigneeDetails consigneeDetails,
           MOTService.com.ngi.SenderDetails senderDetails) {
           this.postalCharges = postalCharges;
           this.postalTrackingCode = postalTrackingCode;
           this.consigneeDetails = consigneeDetails;
           this.senderDetails = senderDetails;
    }


    /**
     * Gets the postalCharges value for this SubmitPostalTrackingCodeRequest.
     * 
     * @return postalCharges
     */
    public java.lang.String getPostalCharges() {
        return postalCharges;
    }


    /**
     * Sets the postalCharges value for this SubmitPostalTrackingCodeRequest.
     * 
     * @param postalCharges
     */
    public void setPostalCharges(java.lang.String postalCharges) {
        this.postalCharges = postalCharges;
    }


    /**
     * Gets the postalTrackingCode value for this SubmitPostalTrackingCodeRequest.
     * 
     * @return postalTrackingCode
     */
    public java.lang.String getPostalTrackingCode() {
        return postalTrackingCode;
    }


    /**
     * Sets the postalTrackingCode value for this SubmitPostalTrackingCodeRequest.
     * 
     * @param postalTrackingCode
     */
    public void setPostalTrackingCode(java.lang.String postalTrackingCode) {
        this.postalTrackingCode = postalTrackingCode;
    }


    /**
     * Gets the consigneeDetails value for this SubmitPostalTrackingCodeRequest.
     * 
     * @return consigneeDetails
     */
    public MOTService.com.ngi.ConsigneeDetails getConsigneeDetails() {
        return consigneeDetails;
    }


    /**
     * Sets the consigneeDetails value for this SubmitPostalTrackingCodeRequest.
     * 
     * @param consigneeDetails
     */
    public void setConsigneeDetails(MOTService.com.ngi.ConsigneeDetails consigneeDetails) {
        this.consigneeDetails = consigneeDetails;
    }


    /**
     * Gets the senderDetails value for this SubmitPostalTrackingCodeRequest.
     * 
     * @return senderDetails
     */
    public MOTService.com.ngi.SenderDetails getSenderDetails() {
        return senderDetails;
    }


    /**
     * Sets the senderDetails value for this SubmitPostalTrackingCodeRequest.
     * 
     * @param senderDetails
     */
    public void setSenderDetails(MOTService.com.ngi.SenderDetails senderDetails) {
        this.senderDetails = senderDetails;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SubmitPostalTrackingCodeRequest)) return false;
        SubmitPostalTrackingCodeRequest other = (SubmitPostalTrackingCodeRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.postalCharges==null && other.getPostalCharges()==null) || 
             (this.postalCharges!=null &&
              this.postalCharges.equals(other.getPostalCharges()))) &&
            ((this.postalTrackingCode==null && other.getPostalTrackingCode()==null) || 
             (this.postalTrackingCode!=null &&
              this.postalTrackingCode.equals(other.getPostalTrackingCode()))) &&
            ((this.consigneeDetails==null && other.getConsigneeDetails()==null) || 
             (this.consigneeDetails!=null &&
              this.consigneeDetails.equals(other.getConsigneeDetails()))) &&
            ((this.senderDetails==null && other.getSenderDetails()==null) || 
             (this.senderDetails!=null &&
              this.senderDetails.equals(other.getSenderDetails())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPostalCharges() != null) {
            _hashCode += getPostalCharges().hashCode();
        }
        if (getPostalTrackingCode() != null) {
            _hashCode += getPostalTrackingCode().hashCode();
        }
        if (getConsigneeDetails() != null) {
            _hashCode += getConsigneeDetails().hashCode();
        }
        if (getSenderDetails() != null) {
            _hashCode += getSenderDetails().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SubmitPostalTrackingCodeRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://MOTService/com/ngi", "SubmitPostalTrackingCodeRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postalCharges");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PostalCharges"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postalTrackingCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PostalTrackingCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("consigneeDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ConsigneeDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://MOTService/com/ngi", "ConsigneeDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SenderDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://MOTService/com/ngi", "SenderDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
