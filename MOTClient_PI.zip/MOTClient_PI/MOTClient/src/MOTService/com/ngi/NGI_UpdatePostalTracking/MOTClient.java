package MOTService.com.ngi.NGI_UpdatePostalTracking;

import java.rmi.RemoteException;

import MOTService.com.ngi.SubmitPostalTrackingCodeRequest;

public class MOTClient {

	private static SubmitPostalTrackingCodeRequest submitPostalTrackingCodeRequest;
	private static MOTService.com.ngi.NGI_UpdatePostalTracking.SubmitPostalTrackingCodeRequest submitPostalTrackingCodeParameters;

	public static void main(String[] args) {
		
		String endPoint = "http://localhost:7803/NGI_BatchUpdateMOT"; 
		
		NGI_UpdatePostalTrackingProxy proxy = new NGI_UpdatePostalTrackingProxy(endPoint);
		
		try {	
			submitPostalTrackingCodeRequest = new SubmitPostalTrackingCodeRequest();
			submitPostalTrackingCodeParameters = new MOTService.com.ngi.NGI_UpdatePostalTracking.SubmitPostalTrackingCodeRequest();
			submitPostalTrackingCodeParameters.setSubmitPostalTrackingCodeRequest(submitPostalTrackingCodeRequest);
			proxy.batchUpdateMOT(submitPostalTrackingCodeParameters);			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
