/**
 * NGI_UpdatePostalTracking.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package MOTService.com.ngi.NGI_UpdatePostalTracking;

public interface NGI_UpdatePostalTracking extends java.rmi.Remote {
    public MOTService.com.ngi.NGI_UpdatePostalTracking.SubmitPostalTrackingCodeResponse batchUpdateMOT(MOTService.com.ngi.NGI_UpdatePostalTracking.SubmitPostalTrackingCodeRequest submitPostalTrackingCodeParameters) throws java.rmi.RemoteException;
}
