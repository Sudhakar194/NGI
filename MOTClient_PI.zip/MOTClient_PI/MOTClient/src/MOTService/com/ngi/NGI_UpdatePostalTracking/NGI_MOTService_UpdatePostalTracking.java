/**
 * NGI_MOTService_UpdatePostalTracking.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package MOTService.com.ngi.NGI_UpdatePostalTracking;

public interface NGI_MOTService_UpdatePostalTracking extends javax.xml.rpc.Service {
    public java.lang.String getNGI_MOTServiceInterfaceHttpPortAddress();

    public MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking getNGI_MOTServiceInterfaceHttpPort() throws javax.xml.rpc.ServiceException;

    public MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking getNGI_MOTServiceInterfaceHttpPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
