package MOTService.com.ngi.NGI_UpdatePostalTracking;

public class NGI_UpdatePostalTrackingProxy implements MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking {
  private String _endpoint = null;
  private MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking nGI_UpdatePostalTracking = null;
  
  public NGI_UpdatePostalTrackingProxy() {
    _initNGI_UpdatePostalTrackingProxy();
  }
  
  public NGI_UpdatePostalTrackingProxy(String endpoint) {
    _endpoint = endpoint;
    _initNGI_UpdatePostalTrackingProxy();
  }
  
  private void _initNGI_UpdatePostalTrackingProxy() {
    try {
      nGI_UpdatePostalTracking = (new MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_MOTService_UpdatePostalTrackingLocator()).getNGI_MOTServiceInterfaceHttpPort();
      if (nGI_UpdatePostalTracking != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)nGI_UpdatePostalTracking)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)nGI_UpdatePostalTracking)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (nGI_UpdatePostalTracking != null)
      ((javax.xml.rpc.Stub)nGI_UpdatePostalTracking)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking getNGI_UpdatePostalTracking() {
    if (nGI_UpdatePostalTracking == null)
      _initNGI_UpdatePostalTrackingProxy();
    return nGI_UpdatePostalTracking;
  }
  
  public MOTService.com.ngi.NGI_UpdatePostalTracking.SubmitPostalTrackingCodeResponse batchUpdateMOT(MOTService.com.ngi.NGI_UpdatePostalTracking.SubmitPostalTrackingCodeRequest submitPostalTrackingCodeParameters) throws java.rmi.RemoteException{
    if (nGI_UpdatePostalTracking == null)
      _initNGI_UpdatePostalTrackingProxy();
    return nGI_UpdatePostalTracking.batchUpdateMOT(submitPostalTrackingCodeParameters);
  }
  
  
}