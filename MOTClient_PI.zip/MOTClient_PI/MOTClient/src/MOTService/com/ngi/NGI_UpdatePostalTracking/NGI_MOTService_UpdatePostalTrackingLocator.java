/**
 * NGI_MOTService_UpdatePostalTrackingLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package MOTService.com.ngi.NGI_UpdatePostalTracking;

public class NGI_MOTService_UpdatePostalTrackingLocator extends org.apache.axis.client.Service implements MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_MOTService_UpdatePostalTracking {

    public NGI_MOTService_UpdatePostalTrackingLocator() {
    }


    public NGI_MOTService_UpdatePostalTrackingLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public NGI_MOTService_UpdatePostalTrackingLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for NGI_MOTServiceInterfaceHttpPort
    private java.lang.String NGI_MOTServiceInterfaceHttpPort_address = "http://10.71.67.72:7804/NGI_BatchUpdateMOT";

    public java.lang.String getNGI_MOTServiceInterfaceHttpPortAddress() {
        return NGI_MOTServiceInterfaceHttpPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String NGI_MOTServiceInterfaceHttpPortWSDDServiceName = "NGI_MOTServiceInterfaceHttpPort";

    public java.lang.String getNGI_MOTServiceInterfaceHttpPortWSDDServiceName() {
        return NGI_MOTServiceInterfaceHttpPortWSDDServiceName;
    }

    public void setNGI_MOTServiceInterfaceHttpPortWSDDServiceName(java.lang.String name) {
        NGI_MOTServiceInterfaceHttpPortWSDDServiceName = name;
    }

    public MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking getNGI_MOTServiceInterfaceHttpPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(NGI_MOTServiceInterfaceHttpPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getNGI_MOTServiceInterfaceHttpPort(endpoint);
    }

    public MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking getNGI_MOTServiceInterfaceHttpPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_MOTService_UpdatePostalTrackingStub _stub = new MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_MOTService_UpdatePostalTrackingStub(portAddress, this);
            _stub.setPortName(getNGI_MOTServiceInterfaceHttpPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setNGI_MOTServiceInterfaceHttpPortEndpointAddress(java.lang.String address) {
        NGI_MOTServiceInterfaceHttpPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_UpdatePostalTracking.class.isAssignableFrom(serviceEndpointInterface)) {
                MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_MOTService_UpdatePostalTrackingStub _stub = new MOTService.com.ngi.NGI_UpdatePostalTracking.NGI_MOTService_UpdatePostalTrackingStub(new java.net.URL(NGI_MOTServiceInterfaceHttpPort_address), this);
                _stub.setPortName(getNGI_MOTServiceInterfaceHttpPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("NGI_MOTServiceInterfaceHttpPort".equals(inputPortName)) {
            return getNGI_MOTServiceInterfaceHttpPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://MOTService/com/ngi/NGI_UpdatePostalTracking", "NGI_MOTService_UpdatePostalTracking");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://MOTService/com/ngi/NGI_UpdatePostalTracking", "NGI_MOTServiceInterfaceHttpPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("NGI_MOTServiceInterfaceHttpPort".equals(portName)) {
            setNGI_MOTServiceInterfaceHttpPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
