/**
 * ConsigneeDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package MOTService.com.ngi;

public class ConsigneeDetails  implements java.io.Serializable {
    private java.lang.String address;

    private java.lang.String name;

    private java.lang.String POBoxNumber;

    private java.lang.String telephoneNo;

    public ConsigneeDetails() {
    }

    public ConsigneeDetails(
           java.lang.String address,
           java.lang.String name,
           java.lang.String POBoxNumber,
           java.lang.String telephoneNo) {
           this.address = address;
           this.name = name;
           this.POBoxNumber = POBoxNumber;
           this.telephoneNo = telephoneNo;
    }


    /**
     * Gets the address value for this ConsigneeDetails.
     * 
     * @return address
     */
    public java.lang.String getAddress() {
        return address;
    }


    /**
     * Sets the address value for this ConsigneeDetails.
     * 
     * @param address
     */
    public void setAddress(java.lang.String address) {
        this.address = address;
    }


    /**
     * Gets the name value for this ConsigneeDetails.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ConsigneeDetails.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the POBoxNumber value for this ConsigneeDetails.
     * 
     * @return POBoxNumber
     */
    public java.lang.String getPOBoxNumber() {
        return POBoxNumber;
    }


    /**
     * Sets the POBoxNumber value for this ConsigneeDetails.
     * 
     * @param POBoxNumber
     */
    public void setPOBoxNumber(java.lang.String POBoxNumber) {
        this.POBoxNumber = POBoxNumber;
    }


    /**
     * Gets the telephoneNo value for this ConsigneeDetails.
     * 
     * @return telephoneNo
     */
    public java.lang.String getTelephoneNo() {
        return telephoneNo;
    }


    /**
     * Sets the telephoneNo value for this ConsigneeDetails.
     * 
     * @param telephoneNo
     */
    public void setTelephoneNo(java.lang.String telephoneNo) {
        this.telephoneNo = telephoneNo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsigneeDetails)) return false;
        ConsigneeDetails other = (ConsigneeDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.address==null && other.getAddress()==null) || 
             (this.address!=null &&
              this.address.equals(other.getAddress()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.POBoxNumber==null && other.getPOBoxNumber()==null) || 
             (this.POBoxNumber!=null &&
              this.POBoxNumber.equals(other.getPOBoxNumber()))) &&
            ((this.telephoneNo==null && other.getTelephoneNo()==null) || 
             (this.telephoneNo!=null &&
              this.telephoneNo.equals(other.getTelephoneNo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAddress() != null) {
            _hashCode += getAddress().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPOBoxNumber() != null) {
            _hashCode += getPOBoxNumber().hashCode();
        }
        if (getTelephoneNo() != null) {
            _hashCode += getTelephoneNo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsigneeDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://MOTService/com/ngi", "ConsigneeDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("address");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POBoxNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "POBoxNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telephoneNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TelephoneNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
