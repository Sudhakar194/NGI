import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { FavNotificationPage } from '../pages/fav-notification/fav-notification';
import { MinstrylistPage } from '../pages/minstrylist/minstrylist';
import { TabsPage } from '../pages/tabs/tabs';
import { HomePage } from '../pages/home/home';
import { SidemenuPage } from '../pages/sidemenu/sidemenu';
import { OptionsPage } from '../pages/options/options';

import { AboutappPage } from '../pages/aboutapp/aboutapp';
import { AllownotificationsPage } from '../pages/allownotifications/allownotifications';
import { ChangepasswordPage } from '../pages/changepassword/changepassword';
import { UpdatecontactdetailsPage } from '../pages/updatecontactdetails/updatecontactdetails';
import { NewnotificationsPage } from '../pages/newnotifications/newnotifications';


import { PopupcardPage } from '../pages/popupcard/popupcard';

import { NotificationPage } from '../pages/notification/notification';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { File } from '@ionic-native/file';

import { Push } from '@ionic-native/push';
import { CallserverProvider } from '../providers/callserver/callserver';


//import { HttpClientModule  } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { GlobalProvider } from '../providers/global/global';
import { FileParserProvider } from '../providers/file-parser/file-parser';


@NgModule({

  declarations: [
    MyApp,
    FavNotificationPage,
    MinstrylistPage,
    TabsPage,
    PopupcardPage,
    NotificationPage,
    HomePage,
    SidemenuPage,
    OptionsPage,
    AboutappPage,
    AllownotificationsPage,
    ChangepasswordPage,
    UpdatecontactdetailsPage,
    NewnotificationsPage
  ],


  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp)
  ],


  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    FavNotificationPage,
    MinstrylistPage,
    TabsPage,
    PopupcardPage,
    NotificationPage,
    HomePage,
    SidemenuPage,
    OptionsPage,
    AboutappPage,
    AllownotificationsPage,
    ChangepasswordPage,
    UpdatecontactdetailsPage,
    NewnotificationsPage
  ],


  providers: [
    StatusBar,
    SplashScreen,
    Push,
    CallserverProvider,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    GlobalProvider,
    File,
    FileParserProvider
  ]


})



export class AppModule {}
