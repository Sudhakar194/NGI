import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';



/**



not using 



*/





@Component({
  selector: 'page-popupcard',
  templateUrl: 'popupcard.html',
})
export class PopupcardPage {

item: any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
     console.log('PopupcardPage#constructor '+ this.navParams.get('item').code);
     this.item = this.navParams.get('item');

  }

  
}
