import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import {FormControl, FormGroup, Validators} from '@angular/forms';

import { GlobalProvider } from './../../providers/global/global';


@Component({
  selector: 'page-changepassword',
  templateUrl: 'changepassword.html',
})


export class ChangepasswordPage {

  password: string ;
  confirmpassword: string ;

  // form groups for validations only 
  changePassword: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public g: GlobalProvider) {
  }

  // load the form validation and lookups 
  ngOnInit() {
       this.changePassword = new FormGroup({
         idnumber: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]),
         password: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
         confirmpassword: new FormControl('',[Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
        
       });

  }//ngOnInit


    // header - localeChange
      changeLanguage(){
         this.g.gchangeLanguage();
      }




}
