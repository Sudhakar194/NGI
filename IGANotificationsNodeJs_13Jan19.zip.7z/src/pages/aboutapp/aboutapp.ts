import { Component } from '@angular/core';

import { GlobalProvider } from './../../providers/global/global';


@Component({
  selector: 'page-aboutapp',
  templateUrl: 'aboutapp.html',
})


export class AboutappPage {

  constructor(public g: GlobalProvider) {
  }


  // header - localeChange
  changeLanguage(){
     this.g.gchangeLanguage();
  }



}
