import { Component } from '@angular/core';
import { GlobalProvider } from './../../providers/global/global';


@Component({
  selector: 'page-allownotifications',
  templateUrl: 'allownotifications.html',
})
export class AllownotificationsPage {

  constructor( public g: GlobalProvider) {
  }

  allowNotifications(){


  }


  // header - localeChange
      changeLanguage(){
         this.g.gchangeLanguage();
      }

 
}
