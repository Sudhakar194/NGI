import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { GlobalProvider } from './../../providers/global/global';

import {FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'page-updatecontactdetails',
  templateUrl: 'updatecontactdetails.html',
})


export class UpdatecontactdetailsPage {

// form groups for validations only 
    updatecontactdetailsForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public g: GlobalProvider) {
  }



  // load the form validation and lookups 
  ngOnInit() {
      let EMAILPATTERN = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;     

       this.updatecontactdetailsForm = new FormGroup({        
         emailid: new FormControl('',[Validators.required, Validators.pattern(EMAILPATTERN)]),
         mobile: new FormControl('',[Validators.required]),
       });

  }//ngOnInit



  // header - localeChange
      changeLanguage(){
         this.g.gchangeLanguage();
      }




}
