import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';

import { GlobalProvider } from './../../providers/global/global';

import { TabsPage } from '../../pages/tabs/tabs';
import { HomePage } from '../../pages/home/home';
import { AboutappPage } from '../../pages/aboutapp/aboutapp';
import { AllownotificationsPage } from '../../pages/allownotifications/allownotifications';
import { ChangepasswordPage } from '../../pages/changepassword/changepassword';
import { UpdatecontactdetailsPage } from '../../pages/updatecontactdetails/updatecontactdetails';
import { NewnotificationsPage } from '../../pages/newnotifications/newnotifications';



@Component({
  selector: 'page-sidemenu',
  templateUrl: 'sidemenu.html',
})

export class SidemenuPage {

	//	rootPage: any = TabsPage;

		constructor(public navCtrl: NavController, public navParams: NavParams,public g: GlobalProvider, public platform: Platform) {
		    // used for an example of ngFor and navigation
      
       g.rootPage = TabsPage;

		}
        
         callAction(action: string) {            
              if (action === 'home'){
                 this.g.rootPage = TabsPage;              
              }else if (action === 'logout'){
                 this.g.rootPage = HomePage;
              }else if (action === 'chanepassword'){
                  this.g.rootPage = ChangepasswordPage;                
              }else if (action === 'allownotifications' ){ 
                  this.g.rootPage = AllownotificationsPage;                
              }else if (action === 'aboutapp'){ 
                  this.g.rootPage = AboutappPage;                
              }else if (action === 'updatedetails'){ 
                  this.g.rootPage = UpdatecontactdetailsPage;                
              } else if (action === 'NewnotificationsPage'){ 
                  this.g.rootPage = NewnotificationsPage;
                
              }





         }


}
