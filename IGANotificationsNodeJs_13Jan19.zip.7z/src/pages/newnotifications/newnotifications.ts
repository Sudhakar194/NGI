import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { GlobalProvider } from './../../providers/global/global';


@Component({
  selector: 'page-newnotifications',
  templateUrl: 'newnotifications.html',
})
export class NewnotificationsPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public g: GlobalProvider) {


  
  }

   // header - localeChange
      changeLanguage(){
         this.g.gchangeLanguage();
      }



extractMessage(item){
          console.log('NotificationPage#extractMessage ' + item.hideMessage);
          if (item.hideMessage) {
              item.hideMessage = false;
          }else{
              item.hideMessage = true;
          }
    }



}
